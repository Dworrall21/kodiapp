# -*- coding: utf-8 -*-
"""Xbox Content Gate - rating-based PIN gate for Kodi playback.

Monitors Player.OnPlay events, checks the content rating, and prompts
for a passcode when content exceeds the configured rating threshold.
Supports session PIN (one item) and extended PIN (8-hour unlock).
"""
from __future__ import unicode_literals

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "script.xbox.contentgate"
ADDON_VERSION = "1.0.0"

# Rating levels matching settings enum order
RATING_LEVELS = {
    "Off": 0,
    "G": 1,
    "PG": 2,
    "PG-13": 3,
    "R": 4,
    "NC-17": 5,
    "XXX": 6,
}

# TV ratings mapped to equivalent MPAA levels
TV_RATING_MAP = {
    "TV-Y": 1,      # All Children → G
    "TV-Y7": 2,     # Older Children → PG
    "TV-G": 2,      # General → PG
    "TV-PG": 3,     # Parental Guidance → PG-13
    "TV-14": 4,     # Parents Strongly Cautioned → R
    "TV-MA": 5,     # Mature Audience → NC-17
    "MA": 5,        # Mature Audience shorthand
    "MA15+": 5,     # Australian
    "R18+": 5,      # Australian
    "R-18": 5,
    "X18+": 6,      # Adult
    "R-Rated": 4,
    "Rated R": 4,
}

# Reverse lookup
RATING_NAMES = {v: k for k, v in RATING_LEVELS.items()}


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def get_setting(name, default=""):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        value = addon.getSetting(name)
        return value if value not in (None, "") else default
    except Exception:
        return default


def set_setting(name, value):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        addon.setSetting(name, str(value))
    except Exception as exc:
        log("Failed to set setting %s: %s" % (name, exc), xbmc.LOGWARNING)


def int_setting(name, default=0):
    try:
        return int(get_setting(name, str(default)))
    except Exception:
        return default


def bool_setting(name, default=False):
    return get_setting(name, "true" if default else "false").lower() in ("1", "true", "yes", "on")


def get_rating_from_metadata():
    """Try to extract the content rating (MPAA) from Kodi's current playback metadata.

    Returns a rating level name string (e.g. "R", "PG-13") or empty string.
    """
    # Try multiple InfoLabel sources
    labels_to_try = [
        "ListItem.MPAARating",
        "VideoPlayer.Rating",
        "Player.Filenameandpath",
        "VideoPlayer.Content",
        "ListItem.Rating",
    ]
    for label in labels_to_try:
        value = xbmc.getInfoLabel(label)
        if value:
            log("InfoLabel %s = %s" % (label, value))
    rating = xbmc.getInfoLabel("ListItem.MPAARating")
    if rating:
        # Normalise: "Rated R" -> "R", "PG-13" -> "PG-13", etc.
        rating = rating.replace("Rated ", "").strip()
        for known in RATING_LEVELS:
            if known.lower() in rating.lower():
                return known
        # Try to find any known rating substring
        for known in sorted(RATING_LEVELS, key=len, reverse=True):
            if known.lower() in rating.lower() or rating.lower() in known.lower():
                return known
    return rating


def get_playing_file():
    """Get the currently playing file path."""
    try:
        return xbmc.getInfoLabel("Player.Filenameandpath")
    except Exception:
        return ""


def get_playing_addon():
    """Try to identify which addon initiated playback from the file path."""
    path = get_playing_file()
    if path.startswith("plugin://"):
        parts = path.replace("plugin://", "").split("/")
        if parts:
            return parts[0]
    return ""


def is_gated_addon(addon_id):
    """Check if the given addon ID is in the gated list."""
    raw = get_setting("gated_addons", "plugin.video.redlight")
    gated = [a.strip() for a in raw.split(",") if a.strip()]
    return addon_id in gated


def rating_level(name):
    """Convert a rating name to a numeric level."""
    if not name:
        return 0
    name = name.strip()
    # Check MPAA ratings first
    if name in RATING_LEVELS:
        return RATING_LEVELS[name]
    # Check TV ratings
    if name in TV_RATING_MAP:
        return TV_RATING_MAP[name]
    # Fuzzy match against both maps
    for known, level in list(RATING_LEVELS.items()) + list(TV_RATING_MAP.items()):
        if known.lower().replace("-", "").replace(" ", "") in name.lower().replace("-", "").replace(" ", ""):
            return level
    # Log unrecognized ratings for debugging
    log("Unrecognized rating: '%s' — defaulting to 0" % name, xbmc.LOGWARNING)
    return 0


def is_unlocked_extended():
    """Check if the 8-hour extended unlock is still active."""
    raw = get_setting("unlocked_until", "")
    if not raw:
        return False
    try:
        until = float(raw)
        return time.time() < until
    except Exception:
        return False


def is_unlocked_session(file_path):
    """Check if this specific file was unlocked via session PIN."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
        return file_path in unlocked if isinstance(unlocked, list) else False
    except Exception:
        return False


def mark_session_unlocked(file_path):
    """Record a session unlock for this file."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
    except Exception:
        unlocked = []
    if not isinstance(unlocked, list):
        unlocked = []
    if file_path and file_path not in unlocked:
        unlocked.append(file_path)
    # Keep max 50 entries to prevent unbounded growth
    if len(unlocked) > 50:
        unlocked = unlocked[-50:]
    set_setting("session_unlocked", json.dumps(unlocked))
    log("Session unlocked: %s" % file_path)


def mark_extended_unlocked(hours=8):
    """Set extended unlock timer."""
    until = time.time() + (hours * 3600)
    set_setting("unlocked_until", str(until))
    log("Extended unlocked until %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(until)))


def clear_unlock_state():
    """Clear all unlock states."""
    set_setting("unlocked_until", "")
    set_setting("session_unlocked", "[]")
    log("All unlock states cleared")


def show_pin_dialog(rating_name, content_title):
    """Show PIN entry dialog and return the result.

    Returns "session", "extended", or None (cancelled).
    """
    session_pin = get_setting("session_pin", "1234")
    extended_pin = get_setting("extended_pin", "5678")

    # Build the dialog message with rating info and content title
    title = content_title or "Unknown content"
    msg = "[COLOR yellow]Content Gate[/COLOR]\n\n"
    msg += "Content: [B]%s[/B]\n" % title
    msg += "Rating:  [B]%s[/B]\n\n" % (rating_name or "Unknown")
    msg += "This content requires a passcode.\n\n"
    msg += "[COLOR FF58A6FF]Enter Session PIN[/COLOR]  — unlock just this item\n"
    msg += "[COLOR FF58A6FF]Enter Extended PIN[/COLOR] — unlock for 8 hours\n"
    msg += "[COLOR FF8B949E][Cancel] to stop playback[/COLOR]"

    dialog = xbmcgui.Dialog()
    # Use numeric input for PIN entry
    pin = dialog.numeric(0, msg, "", True)
    if not pin:
        # User cancelled
        return None

    if pin == session_pin:
        return "session"
    elif pin == extended_pin:
        return "extended"
    else:
        dialog.notification(ADDON_ID, "Incorrect passcode", xbmcgui.NOTIFICATION_ERROR, 3000)
        return show_pin_dialog(rating_name, content_title)  # Retry


STORE_FILE = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID), "store.json")

# Manual ratings database path (stored on Xbox)
RATINGS_DB_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID), "ratings.json")

# Default manual ratings (pre-populated on first run)
DEFAULT_RATINGS = {
    "BoJack Horseman": "TV-MA", "The Simpsons": "TV-PG",
    "Family Guy": "TV-14", "South Park": "TV-MA",
    "Rick and Morty": "TV-14", "Breaking Bad": "TV-MA",
    "Game of Thrones": "TV-MA", "The Office": "TV-PG",
    "Stranger Things": "TV-14", "Squid Game": "TV-MA",
    "The Boys": "TV-MA", "Invincible": "TV-MA",
    "Arcane": "TV-14", "Cyberpunk Edgerunners": "TV-MA",
    "Love Death Robots": "TV-MA", "Deadpool": "R",
    "Deadpool & Wolverine": "R", "The Matrix": "R",
    "Pulp Fiction": "R", "The Dark Knight": "PG-13",
    "It's Always Sunny in Philadelphia": "TV-MA",
}

TV_RATING_MAP = {
    "TV-Y": 1, "TV-Y7": 2, "TV-G": 2, "TV-PG": 3,
    "TV-14": 4, "TV-MA": 5, "MA": 5,
    "R": 4, "PG-13": 3, "PG": 2, "G": 1, "NC-17": 5, "XXX": 6,
}

# CDN URL patterns for detecting which addon initiated playback
GATED_CDN_PATTERNS = {
    "plugin.video.redlight": ["wnam.tb-cdn.io", "tb-cdn.io", "torbox"],
    "plugin.video.povfork": ["wnam.tb-cdn.io", "tb-cdn.io"],
    "plugin.video.helix": ["wnam.tb-cdn.io", "tb-cdn.io"],
}


def get_store():
    try:
        with open(STORE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_store(data):
    try:
        d = os.path.dirname(STORE_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(STORE_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


# --- Manual ratings DB (stored on Xbox) ---

def _load_ratings_db():
    try:
        if xbmcvfs.exists(RATINGS_DB_PATH):
            with open(RATINGS_DB_PATH, "r") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    # First run — initialize with defaults
    _save_ratings_db(DEFAULT_RATINGS)
    return dict(DEFAULT_RATINGS)


def _save_ratings_db(data):
    try:
        d = os.path.dirname(RATINGS_DB_PATH)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(RATINGS_DB_PATH, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
    except Exception as exc:
        log("Failed to save ratings DB: %s" % exc, xbmc.LOGWARNING)


def get_manual_ratings():
    """Return all manual rating overrides (for management API)."""
    return _load_ratings_db()


def set_manual_rating(title, rating):
    """Add or update a manual rating override."""
    if not title or not title.strip():
        return False, "Title is required"
    rating = rating.strip().upper()
    if rating not in TV_RATING_MAP:
        return False, "Invalid rating"
    db = _load_ratings_db()
    db[title.strip()] = rating
    _save_ratings_db(db)
    return True, None


def remove_manual_rating(title):
    """Remove a manual rating override."""
    db = _load_ratings_db()
    if title.strip() in db:
        del db[title.strip()]
        _save_ratings_db(db)
        return True, None
    return False, "Title not found"


def resolve_rating_local(title, media_type="auto"):
    """Resolve a rating using local DB then TMDB, all from within Kodi.

    Priority:
    1. Manual override DB (on Xbox)
    2. TMDB API call (from Kodi, key from Red Light settings)
    3. None
    """
    if not title:
        return {"rating": None, "source": None, "level": 0}

    title_clean = title.strip()

    # 1. Manual override DB (exact → case-insensitive → partial)
    db = _load_ratings_db()
    for db_title, db_rating in db.items():
        if db_title.lower() == title_clean.lower() or \
           db_title.lower() in title_clean.lower() or \
           title_clean.lower() in db_title.lower():
            level = TV_RATING_MAP.get(db_rating, 0)
            return {"rating": db_rating, "source": "manual", "level": level}

    # 2. TMDB API from within Kodi
    try:
        tmdb_key = None
        # Try Red Light addon settings first
        try:
            rl_addon = xbmcaddon.Addon("plugin.video.redlight")
            tmdb_key = rl_addon.getSetting("tmdb_api_key") or rl_addon.getSetting("tmdb.key") or ""
            if tmdb_key:
                log("TMDB key from Red Light settings")
        except Exception:
            pass
        # Try Helix as fallback
        if not tmdb_key:
            try:
                h_addon = xbmcaddon.Addon("plugin.video.helix")
                tmdb_key = h_addon.getSetting("tmdb.api_key") or ""
                if tmdb_key:
                    log("TMDB key from Helix settings")
            except Exception:
                pass
        if tmdb_key:
            result = _lookup_tmdb(title_clean, media_type, tmdb_key)
            if result and result.get("rating"):
                return result
    except Exception as exc:
        log("TMDB lookup failed: %s" % exc, xbmc.LOGWARNING)

    return {"rating": None, "source": None, "level": 0}


def _lookup_tmdb(title, media_type, api_key):
    """Look up a title on TMDB and return US certification rating."""
    import urllib.request
    import urllib.parse
    import json as _json

    types_to_try = []
    if media_type == "movie":
        types_to_try = ["movie"]
    elif media_type == "tv":
        types_to_try = ["tv"]
    else:
        types_to_try = ["movie", "tv"]

    for search_type in types_to_try:
        try:
            search_url = (
                "https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s&language=en-US"
                % (search_type, api_key, urllib.parse.quote(title))
            )
            req = urllib.request.Request(search_url, headers={"User-Agent": "XboxContentGate/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                search_data = _json.loads(resp.read())
            results = search_data.get("results", [])
            if not results:
                continue
            tmdb_id = results[0]["id"]
            if search_type == "movie":
                cert_url = "https://api.themoviedb.org/3/movie/%s/release_dates?api_key=%s" % (tmdb_id, api_key)
            else:
                cert_url = "https://api.themoviedb.org/3/tv/%s/content_ratings?api_key=%s" % (tmdb_id, api_key)
            req = urllib.request.Request(cert_url, headers={"User-Agent": "XboxContentGate/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                cert_data = _json.loads(resp.read())
            rating = None
            if search_type == "movie":
                for rd in cert_data.get("results", []):
                    if rd.get("iso_3166_1") == "US":
                        for release in rd.get("release_dates", []):
                            cert = release.get("certification", "")
                            if cert:
                                rating = cert
                                break
                    if rating:
                        break
            else:
                for result in cert_data.get("results", []):
                    if result.get("iso_3166_1") == "US":
                        rating = result.get("rating", "")
                        break
            if rating:
                level = TV_RATING_MAP.get(rating, 0)
                return {"rating": rating, "source": "tmdb", "level": level, "tmdb_title": results[0].get("title") or results[0].get("name", "")}
        except Exception:
            pass
    return None


def lookup_rating_from_proxy(title, media_type="auto"):
    """Fallback: call laptop proxy. Only used if local TMDB fails."""
    import urllib.request
    import json as _json
    import urllib.parse
    config = get_store().get("proxy", {})
    proxy_host = config.get("host", "10.0.0.4")
    proxy_port = config.get("port", 8080)
    url = "http://%s:%s/api/contentgate/lookup-rating?title=%s&type=%s" % (
        proxy_host, proxy_port, urllib.parse.quote(title), urllib.parse.quote(media_type))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "XboxContentGate/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        return data
    except Exception:
        return None


def handle_gate_check():
    """Main gate logic - check if current playback needs a PIN."""
    if not bool_setting("enabled", True):
        return

    threshold = int_setting("rating_threshold", 3)  # Default: PG-13
    if threshold == 0:  # Off
        return

    file_path = get_playing_file()
    if not file_path:
        log("No file path, skipping gate")
        return

    # Check extended unlock first (8-hour)
    if is_unlocked_extended():
        log("Extended unlock active, allowing playback")
        return

    # Check if we already unlocked this item (session)
    if is_unlocked_session(file_path):
        log("Session unlock active for this item, allowing playback")
        return

    # Get content info
    rating = get_rating_from_metadata()
    addon_id = get_playing_addon()
    content_title = xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("Player.Title") or ""
    media_type = xbmc.getInfoLabel("ListItem.DBType") or "auto"

    level = rating_level(rating)
    log("Playing: %s | Kodi metadata rating: '%s' (level %s) | Addon: '%s' | File: %s" % (
        content_title, rating, level, addon_id, file_path[:80]))

    # Always try full rating resolver (manual DB + TMDB) — overrides Kodi's guess
    if content_title:
        try:
            local_result = resolve_rating_local(content_title, media_type)
            if local_result and local_result.get("rating"):
                new_rating = local_result["rating"]
                new_level = local_result.get("level", 0)
                log("Rating resolved: %s → %s (level %s, source: %s) vs Kodi: %s (level %s)" % (
                    content_title, new_rating, new_level, local_result.get("source", "unknown"),
                    rating, level))
                rating = new_rating
                level = new_level
        except Exception as exc:
            log("Local rating resolver failed: %s" % exc, xbmc.LOGWARNING)
            # Fallback to proxy lookup
            try:
                proxy_result = lookup_rating_from_proxy(content_title, media_type)
                if proxy_result and proxy_result.get("rating"):
                    rating = proxy_result["rating"]
                    level = proxy_result.get("level", 0)
            except Exception as exc2:
                log("Proxy fallback also failed: %s" % exc2, xbmc.LOGWARNING)

    # Also try to detect the addon from the file URL pattern
    if not addon_id:
        for known_addon, patterns in GATED_CDN_PATTERNS.items():
            for pat in patterns:
                if pat in file_path.lower():
                    addon_id = known_addon
                    log("Addon detected from file URL pattern: %s" % addon_id)
                    break
            if addon_id:
                break

    # Check if we should gate this
    should_gate = False

    # Check if the addon is gated
    if addon_id and is_gated_addon(addon_id):
        should_gate = True
        log("Addon %s is in gated list" % addon_id)

    # Check if rating exceeds threshold
    if level >= threshold:
        should_gate = True
        log("Rating level %s >= threshold %s" % (level, threshold))

    if not should_gate:
        log("No gate trigger, allowing playback")
        return

    # Gate triggered - pause and prompt
    player = xbmc.Player()
    was_playing = player.isPlaying()
    if was_playing:
        player.pause()

    result = None
    try:
        result = show_pin_dialog(rating or RATING_NAMES.get(level, "Unknown"), content_title)

        if result == "session":
            mark_session_unlocked(file_path)
            xbmcgui.Dialog().notification(ADDON_ID, "Session unlocked - playing now", xbmcgui.NOTIFICATION_INFO, 2000)
        elif result == "extended":
            mark_extended_unlocked()
            xbmcgui.Dialog().notification(ADDON_ID, "Unlocked for 8 hours", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            # Cancelled - stop playback
            log("Gate denied, stopping playback")
            if was_playing:
                try:
                    player.stop()
                except Exception:
                    pass
            return
    finally:
        # Resume if we paused and unlock was granted
        if result and was_playing:
            try:
                player.play()
            except Exception:
                pass


class ContentGateMonitor(xbmc.Monitor):
    """Monitors Kodi for playback events and applies content gating."""

    def __init__(self):
        super(ContentGateMonitor, self).__init__()
        self._cleanup_old_session_unlocks()

    def _cleanup_old_session_unlocks(self):
        """Clear session unlocks from previous Kodi sessions."""
        raw = get_setting("session_unlocked", "[]")
        try:
            unlocked = json.loads(raw)
            if isinstance(unlocked, list) and len(unlocked) > 50:
                set_setting("session_unlocked", json.dumps(unlocked[-50:]))
        except Exception:
            pass


def run_service():
    """Main service entry point."""
    log("Content Gate service started v%s" % ADDON_VERSION)
    monitor = ContentGateMonitor()
    last_checked_file = ""
    check_count = 0

    # Initial check if already playing
    xbmc.sleep(2000)
    if xbmc.Player().isPlaying():
        file_path = get_playing_file()
        if file_path:
            log("Already playing on startup: %s" % file_path[:80])
            last_checked_file = file_path
            handle_gate_check()

    # Polling loop - checks playback every second
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

        check_count += 1
        player = xbmc.Player()
        is_playing = player.isPlaying()

        if is_playing:
            file_path = get_playing_file()
            # Only check when file changes (new playback)
            if file_path and file_path != last_checked_file:
                last_checked_file = file_path
                log("New playback detected: %s" % file_path[:80])
                handle_gate_check()
        else:
            last_checked_file = ""

        # Periodic logging every 30 seconds
        if check_count % 30 == 0:
            log("Polling: playing=%s, last=%s" % (is_playing, last_checked_file[:60] if last_checked_file else "none"))

    log("Content Gate service stopped")


if __name__ == "__main__":
    run_service()
