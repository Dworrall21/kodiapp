# -*- coding: utf-8 -*-
"""Xbox Content Gate - rating-based PIN gate for Kodi playback.

Monitors Player.OnPlay events, checks the content rating, and prompts
for a passcode when content exceeds the configured rating threshold.
Supports session PIN (one item) and extended PIN (8-hour unlock).
"""
from __future__ import unicode_literals

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "script.xbox.contentgate"
ADDON_VERSION = "1.0.0"

# Rating levels matching settings enum order
RATING_LEVELS = {
    "Off": 0,
    "G": 1,
    "PG": 2,
    "PG-13": 3,
    "R": 4,
    "NC-17": 5,
    "XXX": 6,
}

# TV ratings mapped to equivalent MPAA levels
TV_RATING_MAP = {
    "TV-Y": 1,      # All Children → G
    "TV-Y7": 2,     # Older Children → PG
    "TV-G": 2,      # General → PG
    "TV-PG": 3,     # Parental Guidance → PG-13
    "TV-14": 4,     # Parents Strongly Cautioned → R
    "TV-MA": 5,     # Mature Audience → NC-17
    "MA": 5,        # Mature Audience shorthand
    "MA15+": 5,     # Australian
    "R18+": 5,      # Australian
    "R-18": 5,
    "X18+": 6,      # Adult
    "R-Rated": 4,
    "Rated R": 4,
}

# Reverse lookup
RATING_NAMES = {v: k for k, v in RATING_LEVELS.items()}


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def get_setting(name, default=""):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        value = addon.getSetting(name)
        return value if value not in (None, "") else default
    except Exception:
        return default


def set_setting(name, value):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        addon.setSetting(name, str(value))
    except Exception as exc:
        log("Failed to set setting %s: %s" % (name, exc), xbmc.LOGWARNING)


def int_setting(name, default=0):
    try:
        return int(get_setting(name, str(default)))
    except Exception:
        return default


def bool_setting(name, default=False):
    return get_setting(name, "true" if default else "false").lower() in ("1", "true", "yes", "on")


def get_rating_from_metadata():
    """Try to extract the content rating (MPAA) from Kodi's current playback metadata.

    Returns a rating level name string (e.g. "R", "PG-13") or empty string.
    """
    # Try multiple InfoLabel sources
    labels_to_try = [
        "ListItem.MPAARating",
        "VideoPlayer.Rating",
        "Player.Filenameandpath",
        "VideoPlayer.Content",
        "ListItem.Rating",
    ]
    for label in labels_to_try:
        value = xbmc.getInfoLabel(label)
        if value:
            log("InfoLabel %s = %s" % (label, value))
    rating = xbmc.getInfoLabel("ListItem.MPAARating")
    if rating:
        # Normalise: "Rated R" -> "R", "PG-13" -> "PG-13", etc.
        rating = rating.replace("Rated ", "").strip()
        for known in RATING_LEVELS:
            if known.lower() in rating.lower():
                return known
        # Try to find any known rating substring
        for known in sorted(RATING_LEVELS, key=len, reverse=True):
            if known.lower() in rating.lower() or rating.lower() in known.lower():
                return known
    return rating


def get_playing_file():
    """Get the currently playing file path."""
    try:
        return xbmc.getInfoLabel("Player.Filenameandpath")
    except Exception:
        return ""


def get_playing_addon():
    """Try to identify which addon initiated playback from the file path."""
    path = get_playing_file()
    if path.startswith("plugin://"):
        parts = path.replace("plugin://", "").split("/")
        if parts:
            return parts[0]
    return ""


def is_gated_addon(addon_id):
    """Check if the given addon ID is in the gated list."""
    raw = get_setting("gated_addons", "plugin.video.redlight")
    gated = [a.strip() for a in raw.split(",") if a.strip()]
    return addon_id in gated


def rating_level(name):
    """Convert a rating name to a numeric level."""
    if not name:
        return 0
    name = name.strip()
    # Check MPAA ratings first
    if name in RATING_LEVELS:
        return RATING_LEVELS[name]
    # Check TV ratings
    if name in TV_RATING_MAP:
        return TV_RATING_MAP[name]
    # Fuzzy match against both maps
    for known, level in list(RATING_LEVELS.items()) + list(TV_RATING_MAP.items()):
        if known.lower().replace("-", "").replace(" ", "") in name.lower().replace("-", "").replace(" ", ""):
            return level
    # Log unrecognized ratings for debugging
    log("Unrecognized rating: '%s' — defaulting to 0" % name, xbmc.LOGWARNING)
    return 0


def is_unlocked_extended():
    """Check if the 8-hour extended unlock is still active."""
    raw = get_setting("unlocked_until", "")
    if not raw:
        return False
    try:
        until = float(raw)
        return time.time() < until
    except Exception:
        return False


def is_unlocked_session(file_path):
    """Check if this specific file was unlocked via session PIN."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
        return file_path in unlocked if isinstance(unlocked, list) else False
    except Exception:
        return False


def mark_session_unlocked(file_path):
    """Record a session unlock for this file."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
    except Exception:
        unlocked = []
    if not isinstance(unlocked, list):
        unlocked = []
    if file_path and file_path not in unlocked:
        unlocked.append(file_path)
    # Keep max 50 entries to prevent unbounded growth
    if len(unlocked) > 50:
        unlocked = unlocked[-50:]
    set_setting("session_unlocked", json.dumps(unlocked))
    log("Session unlocked: %s" % file_path)


def mark_extended_unlocked(hours=8):
    """Set extended unlock timer."""
    until = time.time() + (hours * 3600)
    set_setting("unlocked_until", str(until))
    log("Extended unlocked until %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(until)))


def clear_unlock_state():
    """Clear all unlock states."""
    set_setting("unlocked_until", "")
    set_setting("session_unlocked", "[]")
    log("All unlock states cleared")


def show_pin_dialog(rating_name, content_title):
    """Show PIN entry dialog and return the result.

    Returns "session", "extended", or None (cancelled).
    """
    session_pin = get_setting("session_pin", "1234")
    extended_pin = get_setting("extended_pin", "5678")

    # Show an initial notification that gate triggered
    xbmcgui.Dialog().notification(
        ADDON_ID,
        "Content requires passcode (rating: %s)" % (rating_name or "Unknown"),
        xbmcgui.NOTIFICATION_INFO, 4000
    )
    xbmc.sleep(500)

    # First dialog: choose session or extended unlock
    dialog = xbmcgui.Dialog()
    choice = dialog.select(
        "[COLOR yellow]Content Gate[/COLOR] - %s" % (content_title[:50] if content_title else "Playback"),
        [
            "[COLOR FF58A6FF]Enter Session PIN[/COLOR] (unlock just this item)",
            "[COLOR FF58A6FF]Enter Extended PIN[/COLOR] (unlock for 8 hours)",
            "[COLOR FF8B949E]Cancel[/COLOR] (stop playback)",
        ]
    )

    if choice == 2 or choice < 0:  # Cancel or dialog dismissed
        return None

    # Show PIN input dialog
    pin_label = "Session PIN" if choice == 0 else "Extended PIN"
    pin = dialog.input(
        "[COLOR yellow]Content Gate[/COLOR]\nRating: %s\nEnter %s:" % (rating_name or "Unknown", pin_label),
        "",
        xbmcgui.INPUT_ALPHANUM,  # Accept numbers
        False,  # Don't hide input (shows asterisks)
    )

    if not pin:
        return None  # User cancelled the input dialog

    correct_pin = session_pin if choice == 0 else extended_pin
    if pin == correct_pin:
        return "session" if choice == 0 else "extended"
    else:
        dialog.notification(ADDON_ID, "Incorrect passcode", xbmcgui.NOTIFICATION_ERROR, 3000)
        return show_pin_dialog(rating_name, content_title)  # Retry


STORE_FILE = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID), "store.json")

# Whitelist path (titles that are always allowed without PIN)
WHITELIST_PATH = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID), "whitelist.json")

# TMDB API key (embedded for reliability, also read from Red Light/Helix settings)
TMDB_API_KEY = "58bbb1b6e5a8f369f944322bf69413cb"

# Rating levels for comparison
TV_RATING_MAP = {
    "TV-Y": 1, "TV-Y7": 2, "TV-G": 2, "TV-PG": 3,
    "TV-14": 4, "TV-MA": 5, "MA": 5,
    "R": 4, "PG-13": 3, "PG": 2, "G": 1, "NC-17": 5, "XXX": 6,
}

# Default whitelist — safe shows/movies allowed without PIN
DEFAULT_WHITELIST = [
    "The Office", "The Simpsons", "The Dark Knight",
]

# CDN URL patterns for detecting which addon initiated playback
GATED_CDN_PATTERNS = {
    "plugin.video.redlight": ["wnam.tb-cdn.io", "tb-cdn.io", "torbox"],
    "plugin.video.povfork": ["wnam.tb-cdn.io", "tb-cdn.io"],
    "plugin.video.helix": ["wnam.tb-cdn.io", "tb-cdn.io"],
}


def get_store():
    try:
        with open(STORE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_store(data):
    try:
        d = os.path.dirname(STORE_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(STORE_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


# --- Whitelist + TMDB rating resolver ---

def _load_whitelist():
    """Load the whitelist — titles always allowed without PIN."""
    try:
        if xbmcvfs.exists(WHITELIST_PATH):
            with open(WHITELIST_PATH, "r") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception:
        pass
    _save_whitelist(DEFAULT_WHITELIST)
    return list(DEFAULT_WHITELIST)


def _save_whitelist(data):
    try:
        d = os.path.dirname(WHITELIST_PATH)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(WHITELIST_PATH, "w") as f:
            json.dump(data, f, indent=2)
    except Exception as exc:
        log("Failed to save whitelist: %s" % exc, xbmc.LOGWARNING)


def add_to_whitelist(title):
    """Add a title to the whitelist (allowed without PIN)."""
    if not title or not title.strip():
        return False
    wl = _load_whitelist()
    clean = title.strip()
    if clean not in wl:
        wl.append(clean)
        _save_whitelist(wl)
    return True


def remove_from_whitelist(title):
    """Remove a title from the whitelist."""
    wl = _load_whitelist()
    clean = title.strip()
    if clean in wl:
        wl.remove(clean)
        _save_whitelist(wl)
        return True
    return False


def get_whitelist():
    """Return the full whitelist."""
    return _load_whitelist()


def resolve_rating_and_gate(content_title, media_type="auto", threshold=3):
    """Determine if content should be gated.

    Returns dict with {gate: bool, reason: str, rating: str, source: str}

    Logic:
    1. If title in whitelist → ALLOW (no gate)
    2. TMDB lookup → if rating found:
         - If rating level >= threshold → GATE
         - If rating level < threshold → ALLOW
    3. TMDB not found (and not whitelisted) → GATE (deny-by-default)
    """
    result = {"gate": True, "reason": "deny-by-default", "rating": None, "source": None}
    if not content_title:
        return result

    title_clean = content_title.strip()

    # 1. Whitelist check
    wl = _load_whitelist()
    for wt in wl:
        if wt.lower() == title_clean.lower() or \
           wt.lower() in title_clean.lower() or \
           title_clean.lower() in wt.lower():
            result["gate"] = False
            result["reason"] = "whitelisted"
            return result

    # 2. TMDB lookup
    try:
        # Read key from settings first, fall back to embedded constant
        tmdb_key = None
        try:
            rl = xbmcaddon.Addon("plugin.video.redlight")
            tmdb_key = rl.getSetting("tmdb_api_key") or ""
        except Exception:
            pass
        if not tmdb_key:
            try:
                cg = xbmcaddon.Addon(ADDON_ID)
                tmdb_key = cg.getSetting("tmdb_api_key") or ""
            except Exception:
                pass
        if not tmdb_key:
            tmdb_key = TMDB_API_KEY  # embedded fallback

        if tmdb_key:
            tmdb_result = _lookup_tmdb(title_clean, media_type, tmdb_key)
            if tmdb_result and tmdb_result.get("rating"):
                r = tmdb_result["rating"]
                level = TV_RATING_MAP.get(r, 0)
                result["rating"] = r
                result["level"] = level
                result["source"] = "tmdb"
                if level >= threshold:
                    result["gate"] = True
                    result["reason"] = "rating above threshold"
                else:
                    result["gate"] = False
                    result["reason"] = "rating below threshold"
                log("TMDB result: %s = %s (level %s, threshold %s) → %s" % (
                    title_clean, r, level, threshold, result["reason"]))
                return result
            else:
                log("TMDB no rating found for: %s" % title_clean)
    except Exception as exc:
        log("TMDB resolve error: %s" % exc, xbmc.LOGWARNING)

    # 3. Deny by default
    log("No rating found for '%s' and not whitelisted → GATING" % title_clean)
    return result


def _lookup_tmdb(title, media_type, api_key):
    """Look up a title on TMDB and return US certification rating."""
    import urllib.request
    import urllib.parse
    import json as _json

    types_to_try = []
    if media_type == "movie":
        types_to_try = ["movie"]
    elif media_type == "tv":
        types_to_try = ["tv"]
    else:
        types_to_try = ["movie", "tv"]

    for search_type in types_to_try:
        try:
            search_url = (
                "https://api.themoviedb.org/3/search/%s?api_key=%s&query=%s&language=en-US"
                % (search_type, api_key, urllib.parse.quote(title))
            )
            req = urllib.request.Request(search_url, headers={"User-Agent": "XboxContentGate/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                search_data = _json.loads(resp.read())
            results = search_data.get("results", [])
            if not results:
                continue
            tmdb_id = results[0]["id"]
            if search_type == "movie":
                cert_url = "https://api.themoviedb.org/3/movie/%s/release_dates?api_key=%s" % (tmdb_id, api_key)
            else:
                cert_url = "https://api.themoviedb.org/3/tv/%s/content_ratings?api_key=%s" % (tmdb_id, api_key)
            req = urllib.request.Request(cert_url, headers={"User-Agent": "XboxContentGate/1.0"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                cert_data = _json.loads(resp.read())
            rating = None
            if search_type == "movie":
                for rd in cert_data.get("results", []):
                    if rd.get("iso_3166_1") == "US":
                        for release in rd.get("release_dates", []):
                            cert = release.get("certification", "")
                            if cert:
                                rating = cert
                                break
                    if rating:
                        break
            else:
                for result in cert_data.get("results", []):
                    if result.get("iso_3166_1") == "US":
                        rating = result.get("rating", "")
                        break
            if rating:
                level = TV_RATING_MAP.get(rating, 0)
                return {"rating": rating, "source": "tmdb", "level": level, "tmdb_title": results[0].get("title") or results[0].get("name", "")}
        except Exception:
            pass
    return None


def _rpc_pause(pause=True):
    """Pause or resume playback via JSON-RPC (more reliable than Player().pause())."""
    try:
        active = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "method": "Player.GetActivePlayers", "id": "cg-pause"
        })))
        players = active.get("result", [])
        if players:
            playerid = players[0].get("playerid", 1)
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Player.PlayPause",
                "params": {"playerid": playerid, "play": not pause},
                "id": "cg-pause2",
            }))
    except Exception as exc:
        log("Pause error: %s" % exc, xbmc.LOGWARNING)


def lookup_rating_from_proxy(title, media_type="auto"):
    """Fallback: call laptop proxy. Only used if local TMDB fails."""
    import urllib.request
    import json as _json
    import urllib.parse
    config = get_store().get("proxy", {})
    proxy_host = config.get("host", "10.0.0.4")
    proxy_port = config.get("port", 8080)
    url = "http://%s:%s/api/contentgate/lookup-rating?title=%s&type=%s" % (
        proxy_host, proxy_port, urllib.parse.quote(title), urllib.parse.quote(media_type))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "XboxContentGate/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = _json.loads(resp.read())
        return data
    except Exception:
        return None


def handle_gate_check():
    """Main gate logic - check if current playback needs a PIN."""
    if not bool_setting("enabled", True):
        return

    threshold = int_setting("rating_threshold", 3)  # Default: PG-13
    if threshold == 0:  # Off
        return

    file_path = get_playing_file()
    if not file_path:
        log("No file path, skipping gate")
        return

    # Check extended unlock first (8-hour)
    if is_unlocked_extended():
        log("Extended unlock active, allowing playback")
        return

    # Check if we already unlocked this item (session)
    if is_unlocked_session(file_path):
        log("Session unlock active for this item, allowing playback")
        return

    # Get content info
    rating = get_rating_from_metadata()
    addon_id = get_playing_addon()
    content_title = xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("Player.Title") or ""
    media_type = xbmc.getInfoLabel("ListItem.DBType") or "auto"

    level = rating_level(rating)
    log("Playing: %s | Kodi metadata rating: '%s' (level %s) | Addon: '%s' | File: %s" % (
        content_title, rating, level, addon_id, file_path[:80]))

    # Call the full rating/whitelist resolver
    gate_result = resolve_rating_and_gate(content_title, media_type, threshold)
    if gate_result.get("source") in ("tmdb",) or gate_result["gate"]:
        # Use TMDB result if we got one
        if gate_result.get("rating"):
            rating = gate_result["rating"]
            level = gate_result.get("level", 0)
        log("Gate decision: %s → gate=%s (reason: %s)" % (
            content_title, gate_result["gate"], gate_result["reason"]))

    # Also try to detect the addon from the file URL pattern
    if not addon_id:
        for known_addon, patterns in GATED_CDN_PATTERNS.items():
            for pat in patterns:
                if pat in file_path.lower():
                    addon_id = known_addon
                    log("Addon detected from file URL pattern: %s" % addon_id)
                    break
            if addon_id:
                break

    # Check if we should gate this
    should_gate = gate_result["gate"]

    # Also gate if the addon is gated (but not whitelisted)
    if not should_gate and addon_id and is_gated_addon(addon_id) and gate_result.get("reason") != "whitelisted":
        should_gate = True
        log("Addon %s is in gated list" % addon_id)

    if not should_gate:
        log("Gate: ALLOW — %s" % gate_result.get("reason", "unknown"))
        return

    log("Gate: BLOCK — %s" % gate_result.get("reason", "unknown"))

    # Gate triggered - pause and prompt
    was_playing = xbmc.Player().isPlaying()
    if was_playing:
        _rpc_pause(True)
        # Give time for pause and UI to settle
        xbmc.sleep(1500)

    result = None
    try:
        result = show_pin_dialog(rating or RATING_NAMES.get(level, "Unknown"), content_title)

        if result == "session":
            mark_session_unlocked(file_path)
            xbmcgui.Dialog().notification(ADDON_ID, "Session unlocked - playing now", xbmcgui.NOTIFICATION_INFO, 2000)
        elif result == "extended":
            mark_extended_unlocked()
            xbmcgui.Dialog().notification(ADDON_ID, "Unlocked for 8 hours", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            # Cancelled - stop playback
            log("Gate denied, stopping playback")
            if was_playing:
                try:
                    xbmc.Player().stop()
                except Exception:
                    pass
            return
    finally:
        # Resume if we paused and unlock was granted
        if result and was_playing:
            xbmc.sleep(300)
            _rpc_pause(False)


class ContentGateMonitor(xbmc.Monitor):
    """Monitors Kodi for playback events and applies content gating."""

    def __init__(self):
        super(ContentGateMonitor, self).__init__()
        self._cleanup_old_session_unlocks()

    def _cleanup_old_session_unlocks(self):
        """Clear session unlocks from previous Kodi sessions."""
        raw = get_setting("session_unlocked", "[]")
        try:
            unlocked = json.loads(raw)
            if isinstance(unlocked, list) and len(unlocked) > 50:
                set_setting("session_unlocked", json.dumps(unlocked[-50:]))
        except Exception:
            pass


def run_service():
    """Main service entry point."""
    log("Content Gate service started v%s" % ADDON_VERSION)

    # Clear all unlock states on startup (reset when Kodi opens)
    set_setting("unlocked_until", "")
    set_setting("session_unlocked", "[]")
    log("All unlock states cleared on service start")

    monitor = ContentGateMonitor()
    last_checked_file = ""
    check_count = 0

    # Initial check if already playing
    xbmc.sleep(2000)
    if xbmc.Player().isPlaying():
        file_path = get_playing_file()
        if file_path:
            log("Already playing on startup: %s" % file_path[:80])
            last_checked_file = file_path
            handle_gate_check()

    # Polling loop - checks playback every second
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break

        check_count += 1
        player = xbmc.Player()
        is_playing = player.isPlaying()

        if is_playing:
            file_path = get_playing_file()
            # Only check when file changes (new playback)
            if file_path and file_path != last_checked_file:
                last_checked_file = file_path
                log("New playback detected: %s" % file_path[:80])
                handle_gate_check()
        else:
            last_checked_file = ""

        # Periodic logging every 30 seconds
        if check_count % 30 == 0:
            log("Polling: playing=%s, last=%s" % (is_playing, last_checked_file[:60] if last_checked_file else "none"))

    log("Content Gate service stopped")


if __name__ == "__main__":
    run_service()
