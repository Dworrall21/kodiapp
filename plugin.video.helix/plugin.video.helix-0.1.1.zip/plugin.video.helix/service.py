# -*- coding: utf-8 -*-
"""
Helix service — runs in the background on Kodi start.

Tasks:
1. Periodic check of remote news URL, show toast when it changes.
2. Threshold-based cache cleanup.

Service is intentionally short-running: it schedules itself and exits.
"""
import xbmc
import time
import os
import sys

ADDON_ID = "plugin.video.helix"
SERVICE_RUN_FLAG = "/tmp/.helix_service_alive"

try:
    from resources.lib.modules.addonvar import setting, addon
    from resources.lib.service_core import run_loop
    _IMPORT_OK = True
except Exception as exc:
    xbmc.log("Helix service import failed: %r" % exc, xbmc.LOGERROR)
    _IMPORT_OK = False


def _main():
    if not _IMPORT_OK:
        return
    if os.path.exists(SERVICE_RUN_FLAG):
        xbmc.log("Helix service already alive, skipping", xbmc.LOGDEBUG)
        return
    try:
        open(SERVICE_RUN_FLAG, "w").close()
    except Exception:
        pass
    try:
        run_loop()
    finally:
        try:
            os.unlink(SERVICE_RUN_FLAG)
        except Exception:
            pass


if __name__ == "__main__":
    _main()
