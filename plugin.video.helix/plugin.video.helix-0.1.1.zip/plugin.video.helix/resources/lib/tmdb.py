# -*- coding: utf-8 -*-
"""
tmdb: thin TMDB v3 client.

Read-only calls: search, discover, image.
Requires a TMDB v3 API key in settings: tmdb.api_key

If the key is missing or the network call fails, returns [] / None
without raising.
"""
import json
import urllib.request
import urllib.error
import urllib.parse

from .utils import get_setting, log, cache_get, cache_set

BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p"


def _get(path, params, ttl=1800):
    api_key = get_setting("tmdb.api_key")
    if not api_key:
        return None
    params = dict(params or {})
    params["api_key"] = api_key
    params.setdefault("language", get_setting("tmdb.lang", "en-US"))
    region = get_setting("tmdb.region", "")
    if region and "region" not in params:
        params["region"] = region
    url = BASE + path + "?" + urllib.parse.urlencode(params)
    key = "tmdb:" + path + ":" + urllib.parse.urlencode(sorted(params.items()))
    cached = cache_get(key, ttl_seconds=ttl)
    if cached is not None:
        return cached
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        cache_set(key, data)
        return data
    except Exception as exc:
        log("tmdb %s failed: %r" % (path, exc), "warn")
        return None


def image(path, size="w500"):
    if not path:
        return ""
    return IMG + "/" + size + path


def search(query, page=1):
    data = _get("/search/multi", {"query": query, "page": page, "include_adult": "false"})
    if not data:
        return []
    return [r for r in (data.get("results") or []) if r.get("media_type") in ("movie", "tv", "person")]


def discover(kind, page=1):
    """kind in: trending_week, popular_day, top_rated, now_playing, upcoming"""
    table = {
        "trending_week": ("/trending/movie/week", {}),
        "popular_day": ("/movie/popular", {}),
        "top_rated": ("/movie/top_rated", {}),
        "now_playing": ("/movie/now_playing", {}),
        "upcoming": ("/movie/upcoming", {}),
    }
    if kind not in table:
        return []
    path, params = table[kind]
    params["page"] = page
    data = _get(path, params)
    if not data:
        return []
    return data.get("results") or []


def test_key():
    data = _get("/configuration", {}, ttl=86400)
    if data and "images" in data:
        from .utils import notify
        notify("Helix", "TMDB key OK.", "info", 3000)
        return True
    from .utils import notify
    notify("Helix", "TMDB key missing or invalid.", "error", 4000)
    return False
