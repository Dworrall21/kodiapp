# -*- coding: utf-8 -*-
"""
Kodi-safe utilities.

These helpers isolate xbmc imports so the rest of the codebase can be
unit-tested in plain Python.
"""
import os
import sys
import time
import json
import hashlib
import re

# Lazy xbmc imports - resolved at runtime inside Kodi only.
def _xbmc():
    import xbmc  # noqa: F401
    return sys.modules["xbmc"]


def _xbmcvfs():
    import xbmcvfs
    return xbmcvfs


def _xbmcaddon():
    import xbmcaddon
    return xbmcaddon


def _xbmcgui():
    import xbmcgui
    return xbmcgui


def _xbmcplugin():
    import xbmcplugin
    return xbmcplugin


# --- setting / addon accessor (single source of truth) ---
_addon_handle = None
_addon_obj = None


def get_addon():
    """Return the live xbmcaddon.Addon() instance (cached)."""
    global _addon_obj
    if _addon_obj is None:
        _addon_obj = _xbmcaddon().Addon()
    return _addon_obj


def get_setting(key, default=""):
    """Safe setting getter with fallback default."""
    try:
        v = get_addon().getSetting(key)
        return v if v else default
    except Exception:
        return default


def set_setting(key, value):
    try:
        get_addon().setSetting(key, str(value))
        return True
    except Exception:
        return False


def get_int_setting(key, default=0):
    try:
        return int(float(get_setting(key, str(default))))
    except Exception:
        return default


def get_bool_setting(key, default=False):
    v = get_setting(key, "false" if not default else "true").lower()
    return v in ("true", "1", "yes", "on")


# --- handle / content helpers ---
def set_handle(handle):
    global _addon_handle
    _addon_handle = handle


def get_handle():
    return _addon_handle or 0


def end_of_directory(succeeded=True, update_listing=False):
    try:
        _xbmcplugin().endOfDirectory(get_handle(), succeeded=succeeded, updateListing=update_listing)
    except Exception:
        pass


def set_content(content):
    try:
        _xbmcplugin().setContent(get_handle(), content)
    except Exception:
        pass


def add_sort_method(sort):
    try:
        _xbmcplugin().addSortMethod(get_handle(), sort)
    except Exception:
        pass


# --- path / url helpers ---
def translate_path(path):
    if path.startswith("special://"):
        try:
            return _xbmcvfs().translatePath(path)
        except Exception:
            return path
    return path


def addon_info(name):
    """name in: id, name, version, profile, path, icon, fanart"""
    try:
        a = get_addon()
        return {
            "id": a.getAddonInfo("id"),
            "name": a.getAddonInfo("name"),
            "version": a.getAddonInfo("version"),
            "profile": translate_path(a.getAddonInfo("profile")),
            "path": translate_path(a.getAddonInfo("path")),
            "icon": a.getAddonInfo("icon"),
            "fanart": a.getAddonInfo("fanart"),
        }.get(name, "")
    except Exception:
        return ""


def addon_profile_path(*parts):
    base = addon_info("profile") or os.path.join("/tmp", "helix_profile")
    if not os.path.isdir(base):
        try:
            os.makedirs(base)
        except Exception:
            pass
    return os.path.join(base, *parts) if parts else base


# --- logging ---
def log(msg, level="info"):
    try:
        xbmc = _xbmc()
        level_map = {
            "debug": xbmc.LOGDEBUG,
            "info": xbmc.LOGINFO,
            "warn": xbmc.LOGWARNING,
            "error": xbmc.LOGERROR,
        }
        xbmc.log("[Helix] " + str(msg), level_map.get(level, xbmc.LOGINFO))
    except Exception:
        print("[Helix] " + str(msg))


# --- URL builders ---
def build_url(action=None, **kwargs):
    """Build a plugin://... URL with query params (dict-friendly)."""
    from urllib.parse import urlencode
    params = {}
    if action is not None:
        params["action"] = action
    params.update({k: v for k, v in kwargs.items() if v is not None})
    return "plugin://" + ADDON_ID + "/?" + urlencode(params)


ADDON_ID = "plugin.video.helix"


def url_for(action, **kwargs):
    return build_url(action, **kwargs)


# --- common url parsing helpers ---
def parse_query(qs):
    """Parse a query string ('a=b&c=d') into a dict (values are str)."""
    from urllib.parse import parse_qs
    out = {}
    for k, v in parse_qs(qs, keep_blank_values=True).items():
        out[k] = v[0] if len(v) == 1 else v
    return out


# --- hashing / id helpers ---
def short_id(*parts, length=10):
    h = hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()
    return h[:length]


# --- string cleanup ---
def clean_title(s):
    if s is None:
        return ""
    s = str(s)
    s = re.sub(r"[\s.\-_]+", " ", s)
    s = re.sub(r"\[[^\]]*\]", "", s)
    s = re.sub(r"\([^)]*\)", "", s)
    return s.strip()


# --- simple cache helpers ---
def cache_get(key, ttl_seconds=300):
    """JSON cache file in addon profile dir, with TTL."""
    p = addon_profile_path("cache", short_id(key, length=20) + ".json")
    if not os.path.exists(p):
        return None
    try:
        age = time.time() - os.path.getmtime(p)
        if age > ttl_seconds:
            return None
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return None


def cache_set(key, value):
    p = addon_profile_path("cache", short_id(key, length=20) + ".json")
    try:
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(value, fh)
        return True
    except Exception:
        return False


def cache_clear():
    base = addon_profile_path("cache")
    if not os.path.isdir(base):
        return 0
    n = 0
    for f in os.listdir(base):
        try:
            os.unlink(os.path.join(base, f))
            n += 1
        except Exception:
            pass
    return n


# --- toast / dialog ---
def notify(title, message, level="info", duration_ms=4000):
    levels = {
        "info": _xbmcgui().NOTIFICATION_INFO,
        "warn": _xbmcgui().NOTIFICATION_WARNING,
        "error": _xbmcgui().NOTIFICATION_ERROR,
    }
    try:
        _xbmcgui().Dialog().notification(title, message, addon_info("icon"), duration_ms, levels.get(level, levels["info"]))
    except Exception:
        pass


def yesno(title, message, nolabel="No", yeslabel="Yes"):
    try:
        return _xbmcgui().Dialog().yesno(title, message, nolabel=nolabel, yeslabel=yeslabel)
    except Exception:
        return False


def text_viewer(title, body):
    try:
        _xbmcgui().Dialog().textviewer(title, body)
    except Exception:
        notify(title, body[:200] + ("..." if len(body) > 200 else ""))


def dialog_select(title, options):
    try:
        return _xbmcgui().Dialog().select(title, options)
    except Exception:
        return -1


def dialog_input(title, default=""):
    try:
        kb = _xbmcgui().Dialog().input(title, default)
        return kb or ""
    except Exception:
        return ""


# --- list item builder ---
def make_item(label, url=None, is_folder=True, info=None, art=None, properties=None, context=None, mime=None):
    """Build a xbmcgui.ListItem (the unit Kodi shows in a directory)."""
    li = _xbmcgui().ListItem(label=label)
    if info:
        li.setInfo("video", info) if "video" in str(info) or any(k in info for k in ("title", "plot", "year", "genre", "rating", "duration", "season", "episode", "tvshowtitle", "mediatype")) else li.setInfo("general", info)
    if art:
        li.setArt(art)
    if properties:
        for k, v in properties.items():
            li.setProperty(k, str(v))
    if context:
        li.addContextMenuItems(context)
    if not is_folder and url:
        li.setPath(url)
        if mime:
            li.setMimeType(mime)
    elif is_folder and url:
        li.setPath(url)
    return li


def add_item(label, url=None, is_folder=True, info=None, art=None, properties=None, context=None, mime=None):
    """Add a list item to the current plugin handle."""
    li = make_item(label, url, is_folder, info, art, properties, context, mime)
    ok = True
    try:
        _xbmcplugin().addDirectoryItem(get_handle(), url or "", li, isFolder=is_folder)
    except Exception as exc:
        log("add_item failed: %r" % exc, "error")
        ok = False
    return ok


def resolve_item(li):
    try:
        _xbmcplugin().setResolvedUrl(get_handle(), True, li)
    except Exception as e:
        log("setResolvedUrl failed: %r" % e, "error")


def play_url(url, listitem=None):
    """Hand a URL to the Kodi player."""
    try:
        pl = _xbmcplugin().Player()
        if listitem is not None:
            pl.play(url, listitem)
        else:
            pl.play(url)
    except Exception:
        try:
            _xbmcplayer = _xbmcplugin()
            _xbmcplayer.setResolvedUrl(get_handle(), True, make_item("Stream", url, is_folder=False))
        except Exception as e:
            log("play_url fallback failed: %r" % e, "error")
