# -*- coding: utf-8 -*-
"""
menus: builds the on-screen directory listings.

Browse home (POV-style):
    Movies | TV Shows | Anime | Discover | Search | Favorites
    Top bar: "Switch to Tools"

Tools home (Wizard-style):
    Account Manager | Maintenance | Backup/Restore | Tools | Notifications
    Top bar: "Switch to Browse"
"""
from .utils import (
    add_item, url_for, log, notify, get_setting, get_int_setting, addon_info,
    set_content, add_sort_method, play_url, make_item, resolve_item,
    dialog_input, cache_get, cache_set,
)
from .modules.colors import c, b, i
from . import m3u
from . import tmdb
from . import debrid
import xbmcplugin

SORT_LABEL = xbmcplugin.SORT_METHOD_LABEL
SORT_TITLE = xbmcplugin.SORT_METHOD_TITLE
SORT_DATE = xbmcplugin.SORT_METHOD_DATE


def _topbar():
    """First item: a non-folder link to switch context."""
    add_item(
        c("gold", b(">>> SWITCH TO TOOLS <<<")),
        url_for("tools"),
        is_folder=True,
        info={"plot": "Open the maintenance toolkit (Account Manager, Maintenance, Backup/Restore, Tools)."},
    )


def _bottombar():
    add_item(
        c("gold", b(">>> SWITCH TO BROWSE <<<")),
        url_for("home"),
        is_folder=True,
        info={"plot": "Open the browse experience (Movies, TV, Anime, Discover, Search, Favorites)."},
    )


def _browse_status():
    """A small status line that shows M3U count + active debrid."""
    src = m3u.get_cached_source()
    n_items = len(src.get("items", [])) if src else 0
    active = debrid.active_provider_name() or "None"
    src_url = get_setting("source.m3u.url") or get_setting("source.m3u.local") or "(no source)"
    add_item(
        c("gray", "[%d items]  [debrid: %s]  [source: %s]" % (n_items, active, _shorten(src_url, 60))),
        url_for("refresh_m3u"),
        is_folder=False,
        info={"plot": "Click to refresh the M3U source."},
    )


def _shorten(s, n):
    s = s or ""
    if len(s) <= n:
        return s
    return s[: n - 1] + "…"


def tools_submenu():
    set_content("files")
    add_sort_method(SORT_LABEL)
    add_item(c("orange", b("Speedtest")),        url_for("speedtest"),       is_folder=False, info={"plot": "Run a quick latency + download check."})
    add_item(c("orange", b("View Logs")),        url_for("view_logs"),       is_folder=False, info={"plot": "Tail the most recent kodi.log."})
    add_item(c("orange", b("Force Update")),     url_for("force_update"),    is_folder=False, info={"plot": "Trigger Kodi's addon repo update."})
    add_item(c("orange", b("Force Close Kodi")), url_for("force_close_kodi"),is_folder=False, info={"plot": "Quit Kodi."})
    add_item(c("orange", b("Whitelist")),        url_for("whitelist"),       is_folder=True,  info={"plot": "Manage the addon-ID whitelist."})


def browse_home(params=None):
    """The Browse home: tabs into Movies / TV / Anime / Discover / Search / Favorites."""
    set_content("files")
    add_sort_method(SORT_LABEL)

    _topbar()
    _browse_status()
    add_item(
        c("deepskyblue", b("Movies")),
        url_for("movies"),
        is_folder=True,
        info={"plot": "Browse movies from your M3U source."},
        art={"icon": "DefaultMovies.png"},
    )
    add_item(
        c("deepskyblue", b("TV Shows")),
        url_for("tv"),
        is_folder=True,
        info={"plot": "Browse TV shows from your M3U source."},
        art={"icon": "DefaultTVShows.png"},
    )
    add_item(
        c("deepskyblue", b("Anime")),
        url_for("anime"),
        is_folder=True,
        info={"plot": "Browse anime from your M3U source."},
        art={"icon": "DefaultAnime.png"},
    )
    add_item(
        c("deepskyblue", b("Discover")),
        url_for("discover"),
        is_folder=True,
        info={"plot": "Trending and recommended content from TMDB."},
        art={"icon": "DefaultStudios.png"},
    )
    add_item(
        c("deepskyblue", b("Search")),
        url_for("search"),
        is_folder=True,
        info={"plot": "Search TMDB for movies and shows."},
        art={"icon": "DefaultAddonsSearch.png"},
    )
    add_item(
        c("deepskyblue", b("Favorites")),
        url_for("favorites"),
        is_folder=True,
        info={"plot": "Your saved items."},
        art={"icon": "DefaultFavourites.png"},
    )
    add_item(
        c("lightgray", "Open Helix Settings…"),
        url_for("open_settings"),
        is_folder=False,
        info={"plot": "Configure M3U source, TMDB, debrid, news, cache."},
    )


def tools_home(params=None):
    """The Tools home: wizard-style menu of utilities."""
    set_content("files")
    add_sort_method(SORT_LABEL)

    _bottombar()
    add_item(
        c("orange", b("Account Manager")),
        url_for("account_manager"),
        is_folder=True,
        info={"plot": "Authorize Real-Debrid, AllDebrid, Premiumize, TorBox, or Trakt."},
    )
    add_item(
        c("orange", b("Maintenance")),
        url_for("maintenance"),
        is_folder=True,
        info={"plot": "Clear packages, clear thumbnails, clear cache, fresh start, advancedsettings."},
    )
    add_item(
        c("orange", b("Backup / Restore")),
        url_for("backup_restore"),
        is_folder=True,
        info={"plot": "Back up your Kodi userdata; restore from a previous backup."},
    )
    add_item(
        c("orange", b("Tools")),
        url_for("tools_menu"),
        is_folder=True,
        info={"plot": "Speedtest, View Logs, Force Update, Force Close, Whitelist."},
    )
    add_item(
        c("orange", b("Notifications")),
        url_for("notifications"),
        is_folder=True,
        info={"plot": "Read the latest announcement from the maintainer."},
    )
    add_item(
        c("lightgray", "Open Helix Settings…"),
        url_for("open_settings"),
        is_folder=False,
        info={"plot": "Configure M3U source, TMDB, debrid, news, cache."},
    )


# --- Browse: category listing (loads M3U and filters by group) ---
def list_movies(params):
    set_content("movies")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)
    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    items = m3u.get_filtered_items(kind="movie")
    for it in items:
        _render_title_item(it)


def list_tv(params):
    set_content("tvshows")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)
    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    items = m3u.get_filtered_items(kind="tv")
    for it in items:
        _render_title_item(it)


def list_anime(params):
    set_content("tvshows")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)
    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    items = m3u.get_filtered_items(kind="anime")
    for it in items:
        _render_title_item(it)


def _render_title_item(it):
    """A title (group) row. Opening it shows the streams under that title."""
    label = it.get("title", "(untitled)")
    n = it.get("count", 0)
    art = {"poster": it.get("poster", ""), "fanart": it.get("backdrop", "")} if it.get("poster") else None
    info = {
        "title": label,
        "plot": it.get("plot", ""),
        "year": it.get("year", 0),
        "rating": float(it.get("rating", 0) or 0),
        "genre": it.get("genres", ""),
        "mediatype": "movie" if it.get("kind") == "movie" else "tvshow",
    }
    add_item(
        c("white", b(label)) + c("gray", "  (" + str(n) + " streams)"),
        url_for("list_titles", group=it.get("id", "")),
        is_folder=True,
        info=info,
        art=art,
        context=[(
            "Add to Favorites",
            "RunPlugin(" + url_for("add_favorite", group=it.get("id", "")) + ")",
        )] if it.get("id") else None,
    )


def list_titles(params):
    """Show all streams in a group, then play the chosen one."""
    group_id = params.get("group")
    items = m3u.get_filtered_items(kind="all")
    group = next((g for g in items if g.get("id") == group_id), None)
    if not group:
        notify("Helix", "Group not found (refresh M3U and try again).", "warn")
        return
    set_content("videos")
    add_sort_method(SORT_LABEL)
    for s in group.get("streams", []):
        label = s.get("name") or s.get("title") or s.get("url", "(stream)")
        info = {
            "title": label,
            "size": int(s.get("size", 0) or 0) * 1024 * 1024,  # MB -> bytes
        }
        add_item(
            c("white", label),
            url_for("play", url=s.get("url", ""), group=group_id),
            is_folder=False,
            info=info,
            properties={"IsPlayable": "true"},
        )


def play(params):
    """Resolve and play a stream URL."""
    url = params.get("url")
    if not url:
        notify("Helix", "No URL provided.", "error")
        return
    log("play: %s" % _shorten(url, 100))
    resolved = debrid.resolve(url) or url
    li = make_item("Stream", resolved, is_folder=False, info={"title": "Stream"}, art={"icon": "DefaultVideo.png"})
    li.setProperty("IsPlayable", "true")
    resolve_item(li)
    play_url(resolved, li)


# --- Search / Discover / Favorites ---
def do_search(params):
    set_content("files")
    q = params.get("q")
    if not q:
        q = dialog_input("Search TMDB")
    if not q:
        return
    results = tmdb.search(q)
    if not results:
        notify("Helix", "No results (or no TMDB key).", "warn")
    for r in results:
        label = r.get("title") or r.get("name")
        info = {
            "title": label,
            "plot": r.get("overview", ""),
            "year": (r.get("release_date") or r.get("first_air_date") or "0000-00-00")[:4],
            "rating": float(r.get("vote_average") or 0),
        }
        art = {"poster": tmdb.image(r.get("poster_path"))} if r.get("poster_path") else None
        add_item(
            c("white", b(label or "(untitled)")) + c("gray", "  %s" % (info.get("year") or "")),
            url_for("play", url="tmdb://" + str(r.get("id", "")), group=r.get("id", "")),
            is_folder=False,
            info=info,
            art=art,
        )


def list_discover(params):
    set_content("movies")
    add_sort_method(SORT_LABEL)
    add_item(c("gold", b("Trending (week)")), url_for("discover", kind="trending_week"), is_folder=True)
    add_item(c("gold", b("Popular (day)")), url_for("discover", kind="popular_day"), is_folder=True)
    add_item(c("gold", b("Top Rated")), url_for("discover", kind="top_rated"), is_folder=True)
    add_item(c("gold", b("Now Playing")), url_for("discover", kind="now_playing"), is_folder=True)
    add_item(c("gold", b("Upcoming")), url_for("discover", kind="upcoming"), is_folder=True)

    kind = params.get("kind")
    if kind:
        results = tmdb.discover(kind)
        for r in results:
            label = r.get("title") or r.get("name")
            info = {
                "title": label,
                "plot": r.get("overview", ""),
                "year": (r.get("release_date") or r.get("first_air_date") or "0000-00-00")[:4],
                "rating": float(r.get("vote_average") or 0),
            }
            art = {"poster": tmdb.image(r.get("poster_path"))} if r.get("poster_path") else None
            add_item(
                c("white", b(label or "(untitled)")) + c("gray", "  %s" % (info.get("year") or "")),
                url_for("play", url="tmdb://" + str(r.get("id", "")), group=r.get("id", "")),
                is_folder=False,
                info=info,
                art=art,
            )


def list_favorites(params):
    set_content("files")
    add_sort_method(SORT_LABEL)
    favs = _load_favorites()
    if not favs:
        add_item(c("gray", "(no favorites yet — long-press a title to add)"), "", is_folder=False)
        return
    for fav in favs:
        info = {
            "title": fav.get("title"),
            "plot": fav.get("plot", ""),
            "year": fav.get("year", 0),
        }
        add_item(
            c("white", b(fav.get("title") or "(untitled)")),
            url_for("list_titles", group=fav.get("id", "")),
            is_folder=True,
            info=info,
            context=[(
                "Remove from Favorites",
                "RunPlugin(" + url_for("remove_favorite", group=fav.get("id", "")) + ")",
            )],
        )


# --- favorites: stored as JSON in addon profile ---
_FAV_PATH = None
def _fav_path():
    global _FAV_PATH
    if _FAV_PATH is None:
        _FAV_PATH = addon_info("profile")
        if not _FAV_PATH:
            _FAV_PATH = "/tmp/helix_profile"
        import os
        try:
            os.makedirs(_FAV_PATH, exist_ok=True)
        except Exception:
            pass
        _FAV_PATH = os.path.join(_FAV_PATH, "favorites.json")
    return _FAV_PATH


def _load_favorites():
    import os, json
    p = _fav_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return []


def _save_favorites(items):
    import os, json
    with open(_fav_path(), "w", encoding="utf-8") as fh:
        json.dump(items, fh, ensure_ascii=False, indent=2)


def add_favorite(params):
    import json
    group_id = params.get("group")
    if not group_id:
        return
    items = m3u.get_filtered_items(kind="all")
    g = next((g for g in items if g.get("id") == group_id), None)
    if not g:
        notify("Helix", "Could not add favorite (group missing).", "warn")
        return
    favs = _load_favorites()
    if not any(f.get("id") == group_id for f in favs):
        favs.append({
            "id": group_id,
            "title": g.get("title"),
            "plot": g.get("plot", ""),
            "year": g.get("year", 0),
        })
        _save_favorites(favs)
        notify("Helix", "Added: " + (g.get("title") or ""), "info", 2500)


def remove_favorite(params):
    group_id = params.get("group")
    if not group_id:
        return
    favs = _load_favorites()
    favs = [f for f in favs if f.get("id") != group_id]
    _save_favorites(favs)
    notify("Helix", "Removed.", "info", 2000)
