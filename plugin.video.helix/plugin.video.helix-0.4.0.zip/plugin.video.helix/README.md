# Helix — Kodi Add-on

A single Kodi video add-on that fuses a clean, TMDB-driven browse experience with a full maintenance toolkit. One icon. Two home windows. No bundled pirate sources — point it at your own M3U.

## What's in it

**Browse** (POV-inspired, Fen-style)
- Movies, TV Shows, Anime, Discover, Search, Favorites
- TMDB metadata + poster/fanart
- M3U playlist loader (URL or local file)
- Debrid resolver: Real-Debrid, AllDebrid, Premiumize, TorBox

**Tools** (Red Wizard-inspired)
- Account Manager (debrid + Trakt)
- Maintenance (clear packages, clear thumbnails, clear cache, fresh start)
- Backup / Restore (userdata)
- Speedtest, View Logs, Force Update, Whitelist, Notifications
- Service: periodic news + cache cleanup

## Layout

```
plugin.video.helix/
├── addon.xml
├── default.py           # entry; routes to MyHome or MyTools
├── service.py           # background service
├── resources/
│   ├── settings.xml
│   ├── language/        # strings (en_GB)
│   ├── skins/Default/1080i/
│   │   ├── MyHome.xml   # browse-style home
│   │   ├── MyTools.xml  # wizard-style home
│   │   └── ...
│   ├── media/           # icon, fanart, screenshots
│   └── lib/             # python modules
```

## Build

```bash
./package.sh
# -> dist/plugin.video.helix-0.1.0.zip
```

## Install

Install the zip via Kodi: Add-ons → Install from zip file. Or drop it into your Kodi repo and let the repo serve it.

## Legal

Helix is a content-neutral tool. It does not host, scrape, or link to any third-party media. Configure your own M3U playlist and your own debrid credentials. The end user is responsible for the legality of any content they access.

## License

MIT
