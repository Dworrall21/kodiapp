# -*- coding: utf-8 -*-
"""
Helix entry point.

Usage: plugin://plugin.video.helix/<action>[?<params>]
       or
       plugin://plugin.video.helix/  (opens Browse home)
"""
import sys
from resources.lib.router import dispatch

if __name__ == "__main__":
    try:
        base = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
        dispatch(base)
    except Exception as exc:
        # Last-ditch: surface error to the log but never crash Kodi.
        try:
            import xbmc
            import xbmcgui
            xbmc.log("Helix fatal: %r" % exc, xbmc.LOGERROR)
            xbmcgui.Dialog().notification("Helix", "Error: %s" % exc, xbmcgui.NOTIFICATION_ERROR, 5000)
        except Exception:
            import traceback
            traceback.print_exc()
