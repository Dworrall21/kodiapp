# -*- coding: utf-8 -*-
"""
service_core: pure-python body of the service loop.

This is split out from service.py so we can test it without
importing the Kodi xbmc module in the same file.
"""
import os
import time
import json
import shutil
import urllib.request

from .utils import log, get_setting, get_int_setting, get_bool_setting, notify, cache_get, cache_set


_LAST_NEWS_KEY = "service:news:last"

def _dir_size_mb(path):
    total = 0
    if not os.path.isdir(path):
        return 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except Exception:
                pass
    return total // (1024 * 1024)


def _special(p):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


def _check_news():
    url = get_setting("news.url")
    if not url:
        return
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        log("news fetch failed: %r" % exc, "warn")
        return
    last = cache_get(_LAST_NEWS_KEY, ttl_seconds=10**9)
    if last != body:
        cache_set(_LAST_NEWS_KEY, body)
        # Only show on change after the first read.
        if last is not None:
            notify("Helix — News update", body[:200].strip() or "(empty)", "info", 6000)


def _check_cache():
    if not get_bool_setting("cache.auto_clean", True):
        return
    threshold = get_int_setting("cache.threshold_mb", 500)
    home = _special("special://home")
    candidates = ["packages", "temp"]
    total = 0
    for c in candidates:
        total += _dir_size_mb(os.path.join(home, c))
    if total >= threshold:
        for c in candidates:
            p = os.path.join(home, c)
            if os.path.isdir(p):
                for entry in os.listdir(p):
                    full = os.path.join(p, entry)
                    try:
                        if os.path.isdir(full):
                            shutil.rmtree(full, ignore_errors=True)
                        else:
                            os.unlink(full)
                    except Exception:
                        pass
        log("cache cleaned: was %dMB" % total)


def _check_m3u():
    """Quietly refresh the M3U cache. Failures are logged, never notified."""
    if not get_bool_setting("source.m3u.auto_refresh", True):
        return
    try:
        from . import m3u
        m3u.clear_cache_and_refresh(quiet=True, timeout=8)
    except Exception as exc:
        log("m3u: refresh failed: %r" % exc, "warn")


def run_loop():
    """Service main loop. Polls news + cache + m3u, then sleeps."""
    news_h = max(1, get_int_setting("news.check_hours", 6))
    m3u_h = max(1, get_int_setting("source.m3u.refresh", 6))
    log("service: loop start (news every %dh, m3u every %dh)" % (news_h, m3u_h))
    last_news = 0
    last_cache = 0
    last_m3u = 0
    # Run a few cycles (the service exits; the addon's startup hook
    # re-launches us when the user reboots Kodi or if they re-enable)
    for _ in range(12):  # ~12 * 5min = 1h
        # Restart sentinel — Dashboard → "Restart Helix service" sets this;
        # we exit cleanly so Kodi respawns the service.
        if os.path.exists("/tmp/.helix_service_restart"):
            try:
                os.unlink("/tmp/.helix_service_restart")
            except Exception:
                pass
            log("service: restart requested via /tmp/.helix_service_restart, exiting")
            return
        now = time.time()
        if now - last_news > news_h * 3600:
            try:
                _check_news()
            except Exception as exc:
                log("news: %r" % exc, "warn")
            last_news = now
        if now - last_cache > 3600:
            try:
                _check_cache()
            except Exception as exc:
                log("cache: %r" % exc, "warn")
            last_cache = now
        if now - last_m3u > m3u_h * 3600:
            try:
                _check_m3u()
            except Exception as exc:
                log("m3u: %r" % exc, "warn")
            last_m3u = now
        time.sleep(300)  # 5 min
    log("service: loop exit")
