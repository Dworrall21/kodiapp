# -*- coding: utf-8 -*-
"""
backup: zip up Kodi userdata (or a subset) and restore from a zip.

Default backup folder: special://profile/backups  (Helix addon profile)
"""
import os
import time
import shutil
import zipfile

from .utils import log, notify, yesno, dialog_input, addon_info, dialog_select, get_setting, set_setting


def menu():
    from .utils import add_item, url_for, set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)
    from .modules.colors import c, b
    add_item(c("orange", b("Backup Now")),             url_for("backup_run"),         is_folder=False, info={"plot": "Zip up userdata and save it in the backup folder."})
    add_item(c("orange", b("Restore…")),              url_for("restore_run"),        is_folder=False, info={"plot": "Choose a backup zip and restore."})
    add_item(c("orange", b("Set Backup Folder…")),    url_for("backup_set_folder"),  is_folder=False, info={"plot": "Move the backup folder."})
    add_item(c("orange", b("Reset Backup Folder")),   url_for("backup_reset_folder"),is_folder=False, info={"plot": "Reset to the addon default."})


def _special(p):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


def _backup_dir():
    p = get_setting("backup.folder")
    if p:
        return p
    profile = addon_info("profile") or "/tmp/helix_profile"
    bp = os.path.join(profile, "backups")
    os.makedirs(bp, exist_ok=True)
    return bp


def _list_backups():
    d = _backup_dir()
    if not os.path.isdir(d):
        return []
    return sorted(
        (os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(".zip")),
        key=lambda p: os.path.getmtime(p),
        reverse=True,
    )


def run_backup():
    userdata = _special("special://userdata")
    if not os.path.isdir(userdata):
        notify("Helix", "Userdata not found at " + userdata, "error")
        return
    ts = time.strftime("%Y%m%d-%H%M%S")
    out = os.path.join(_backup_dir(), "userdata-%s.zip" % ts)
    try:
        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for root, dirs, files in os.walk(userdata):
                # Skip large cache dirs
                if "Thumbnails" in root or "Database" in root or "cache" in root:
                    continue
                for f in files:
                    full = os.path.join(root, f)
                    try:
                        zf.write(full, os.path.relpath(full, userdata))
                    except Exception as exc:
                        log("backup skip %s: %r" % (full, exc), "warn")
    except Exception as exc:
        log("backup failed: %r" % exc, "error")
        notify("Helix", "Backup failed: %s" % exc, "error")
        return
    notify("Helix", "Backup saved: " + os.path.basename(out), "info", 4000)


def run_restore(params):
    zips = _list_backups()
    if not zips:
        notify("Helix", "No backups in: " + _backup_dir(), "warn", 5000)
        return
    labels = [os.path.basename(p) + "   (" + time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(p))) + ")" for p in zips]
    sel = dialog_select("Choose a backup to restore", labels)
    if sel < 0 or sel >= len(zips):
        return
    target = zips[sel]
    if not yesno("Helix", "Restore " + os.path.basename(target) + "?\nThis will overwrite files in userdata.", nolabel="Cancel", yeslabel="Restore"):
        return
    userdata = _special("special://userdata")
    try:
        with zipfile.ZipFile(target, "r") as zf:
            for name in zf.namelist():
                if name.endswith("/"):
                    continue
                out = os.path.join(userdata, name)
                os.makedirs(os.path.dirname(out), exist_ok=True)
                with zf.open(name) as src, open(out, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    except Exception as exc:
        log("restore failed: %r" % exc, "error")
        notify("Helix", "Restore failed: %s" % exc, "error")
        return
    notify("Helix", "Restored from " + os.path.basename(target), "info", 5000)


def set_folder():
    p = dialog_input("Backup folder (absolute path)")
    if not p:
        return
    p = p.strip()
    try:
        os.makedirs(p, exist_ok=True)
    except Exception as exc:
        notify("Helix", "Could not create: %s" % exc, "error")
        return
    set_setting("backup.folder", p)
    notify("Helix", "Backup folder: " + p, "info", 3000)


def reset_folder():
    set_setting("backup.folder", "")
    notify("Helix", "Backup folder reset.", "info", 2000)
