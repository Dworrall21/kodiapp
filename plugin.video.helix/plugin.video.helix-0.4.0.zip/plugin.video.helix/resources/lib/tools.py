# -*- coding: utf-8 -*-
"""
tools: misc utilities — view logs, force update, force close, whitelist, notifications.
"""
import os
import time
import json
import urllib.request

from .utils import log, notify, yesno, dialog_input, get_setting, set_setting, text_viewer, dialog_select
from .modules.colors import c, b


def view_logs():
    """Tail the most recent kodi.log."""
    paths = [
        "/storage/.kodi/temp/kodi.log",          # LibreELEC
        "/root/.kodi/temp/kodi.log",             # Linux
        os.path.expanduser("~/Library/Logs/kodi.log"),  # macOS
    ]
    for p in paths:
        if os.path.exists(p):
            try:
                with open(p, "rb") as fh:
                    fh.seek(0, 2)
                    size = fh.tell()
                    fh.seek(max(0, size - 200 * 1024))
                    data = fh.read().decode("utf-8", errors="replace")
                text_viewer("Helix — kodi.log (tail)", data)
                return
            except Exception as exc:
                notify("Helix", "Read failed: %s" % exc, "error")
                return
    notify("Helix", "kodi.log not found in known locations.", "warn")


def force_update():
    try:
        import xbmc
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
        notify("Helix", "Add-on update check triggered.", "info", 3000)
    except Exception as exc:
        notify("Helix", "Update failed: %s" % exc, "error")


def force_close():
    if not yesno("Helix", "Force close Kodi now?", nolabel="Cancel", yeslabel="Close"):
        return
    try:
        import xbmc
        xbmc.executebuiltin("Quit")
    except Exception:
        os._exit(1)


# --- whitelist (addon IDs to keep) ---
_WHITELIST_KEY = "whitelist.addon_ids"

def _wl_path():
    from .utils import addon_info
    p = addon_info("profile")
    if not p:
        p = "/tmp/helix_profile"
    os.makedirs(p, exist_ok=True)
    return os.path.join(p, "whitelist.json")


def _wl_load():
    p = _wl_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return []


def _wl_save(items):
    with open(_wl_path(), "w", encoding="utf-8") as fh:
        json.dump(items, fh, ensure_ascii=False, indent=2)


def whitelist_menu():
    from .utils import add_item, url_for, set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)
    add_item(c("orange", b("Add to Whitelist")),    url_for("whitelist_add"),    is_folder=False, info={"plot": "Add an addon ID to the whitelist."})
    add_item(c("orange", b("Remove from Whitelist")), url_for("whitelist_remove"), is_folder=False, info={"plot": "Remove an addon ID from the whitelist."})
    items = _wl_load()
    if not items:
        add_item(c("gray", "(empty)"), "", is_folder=False)
    for x in items:
        add_item(c("white", x), "", is_folder=False)


def whitelist_add():
    addon_id = dialog_input("Addon ID (e.g. plugin.video.youtube)")
    if not addon_id:
        return
    addon_id = addon_id.strip()
    items = _wl_load()
    if addon_id not in items:
        items.append(addon_id)
        _wl_save(items)
    notify("Helix", "Whitelist saved.", "info", 2000)


def whitelist_remove():
    items = _wl_load()
    if not items:
        notify("Helix", "Whitelist is empty.", "warn")
        return
    sel = dialog_select("Remove from whitelist", items)
    if sel < 0 or sel >= len(items):
        return
    items.pop(sel)
    _wl_save(items)
    notify("Helix", "Removed.", "info", 2000)


# --- notifications (remote news) ---
def notifications():
    url = get_setting("news.url")
    if not url:
        notify("Helix", "No news URL configured in settings.", "warn", 5000)
        return
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            body = resp.read().decode("utf-8", errors="replace")
    except Exception as exc:
        notify("Helix", "News fetch failed: %s" % exc, "error")
        return
    text_viewer("Helix — Notifications", body)
