# -*- coding: utf-8 -*-
"""
maintenance: clear packages, clear thumbnails, clear cache, fresh start,
              advancedsettings helper.

Operates on Kodi's special:// paths and uses xbmcvfs to delete files.
"""
import os
import shutil

from .utils import log, notify, yesno, addon_info, get_bool_setting, get_int_setting, get_setting


def menu():
    """Rendered as a directory (router re-dispatches)."""
    from .utils import add_item, url_for, set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)

    from .modules.colors import c, b
    add_item(c("orange", b("Clear Packages")),       url_for("maint_clear_packages"),   is_folder=False, info={"plot": "Empty the packages/ cache used during addon installs."})
    add_item(c("orange", b("Clear Thumbnails")),     url_for("maint_clear_thumbnails"), is_folder=False, info={"plot": "Delete the cached texture thumbnails."})
    add_item(c("orange", b("Clear Helix Cache")),    url_for("maint_clear_cache"),      is_folder=False, info={"plot": "Clear Helix's own cache (M3U, TMDB, debrid)."})
    add_item(c("orange", b("Fresh Start")),          url_for("maint_fresh_start"),      is_folder=False, info={"plot": "Backup guisettings, then clear Kodi to a clean state. Kodi will exit."})
    add_item(c("orange", b("Video Cache Settings")), url_for("maint_cache_settings"),   is_folder=False, info={"plot": "Open Kodi's advancedsettings.xml."})


def _special(p):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(p)
    except Exception:
        return p


def _dir_size_mb(path):
    total = 0
    if not os.path.isdir(path):
        return 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except Exception:
                pass
    return total // (1024 * 1024)


def _delete_contents(path):
    if not os.path.isdir(path):
        return 0
    n = 0
    for entry in os.listdir(path):
        full = os.path.join(path, entry)
        try:
            if os.path.isdir(full):
                shutil.rmtree(full, ignore_errors=True)
            else:
                os.unlink(full)
            n += 1
        except Exception as exc:
            log("delete failed %s: %r" % (full, exc), "warn")
    return n


def clear_packages():
    p = _special("special://home/addons/packages")
    n = _delete_contents(p)
    notify("Helix", "Cleared %d package files." % n, "info", 3000)


def clear_thumbnails():
    # Standard Kodi thumbnail paths
    paths = [
        _special("special://home/Thumbnails"),
        _special("special://userdata/Thumbnails"),
    ]
    n = 0
    for p in paths:
        n += _delete_contents(p)
    notify("Helix", "Cleared %d thumbnail entries." % n, "info", 3000)


def clear_cache():
    """Clear Helix's own addon cache (JSON files in profile/cache)."""
    from .utils import cache_clear
    n = cache_clear()
    notify("Helix", "Helix cache cleared (%d files)." % n, "info", 3000)


def fresh_start():
    """Backup guisettings, then clean Kodi to a fresh state.

    Implementation note: a 'fresh start' in Kodi terms means removing
    addons, addon_data, database, playlists, packages and thumbnails,
    while keeping userdata files. We do that here and force-exit.
    """
    if not yesno("Helix — Fresh Start", "Backup guisettings, then delete all addons/addon_data/databases/packages/thumbnails/playlists. Kodi will be reset to a clean state. Continue?", nolabel="Cancel", yeslabel="Fresh Start"):
        return
    backup_guisettings()
    home = _special("special://home")
    targets = [
        "addons",
        "addon_data",
        "Database",
        "userdata/Thumbnails",
        "userdata/Playlist",
        "userdata/PeripheralData",
        "packages",
        "temp",
    ]
    for t in targets:
        _delete_contents(os.path.join(home, t))
    notify("Helix", "Fresh start complete. Closing Kodi in 3s…", "info", 3000)
    # exit Kodi so the user can re-launch
    try:
        import xbmc
        xbmc.sleep(3000)
        xbmc.executebuiltin("Quit")
    except Exception:
        pass


def backup_guisettings():
    p = _special("special://userdata/guisettings.xml")
    bk = p + ".helix.bak"
    try:
        if os.path.exists(p):
            import shutil as sh
            sh.copy2(p, bk)
    except Exception as exc:
        log("backup_guisettings failed: %r" % exc, "warn")


def cache_settings():
    """Open advancedsettings.xml so the user can edit it."""
    p = _special("special://userdata/advancedsettings.xml")
    if not os.path.exists(p):
        # Write a minimal one the user can edit
        template = (
            '<?xml version="1.0" encoding="utf-8"?>\n'
            '<advancedsettings>\n'
            '  <network>\n'
            '    <buffermode>1</buffermode>\n'
            '    <cachemembuffersize>104857600</cachemembuffersize>\n'
            '    <readbufferfactor>4</readbufferfactor>\n'
            '  </network>\n'
            '</advancedsettings>\n'
        )
        try:
            with open(p, "w", encoding="utf-8") as fh:
                fh.write(template)
        except Exception as exc:
            notify("Helix", "Could not write advancedsettings: %s" % exc, "error")
            return
    notify("Helix", "advancedsettings.xml is at:\n" + p, "info", 6000)
