# -*- coding: utf-8 -*-
"""
torrentio: scraper for Torrentio (Stremio addon) API.

Queries Torrentio's streaming API by IMDB ID, returns a list of
torrents with quality, size, seeders, and infoHash.

API endpoint (from settings: indexers.torrentio_url, default
https://torrentio.strem.fun):

    GET /stream/movie/{imdb_id}.json
    GET /stream/series/{imdb_id}:{season}:{episode}.json

Response shape:

    {
      "streams": [
        {
          "name": "4k HDR",
          "title": "Release Name ... 👤 122 💾 8.91 GB ⚙️ 1337x",
          "infoHash": "2849211f150e966ef7924f43aec22727a644e10d",
          "fileIdx": 0,
          "behaviorHints": {...}
        }
      ]
    }

Each stream is parsed into a flat dict with the fields needed by the
addon's menus and debrid layer.
"""
import json
import re
import urllib.request
import urllib.error
import urllib.parse

from .utils import get_setting, log

# Regex to extract seeders from the Torrentio title line.
# Format: "👤 122 💾 8.91 GB ⚙️ 1337x"
_RE_SEEDERS = re.compile(r"👤\s*(\d+)")
_RE_SIZE = re.compile(r"💾\s*([\d.,]+)\s*(GB|GiB|MB|MiB)", re.IGNORECASE)

# Quality heuristics derived from the stream name / title.
# Ordered highest-first so we can pick the best match.
_QUALITY_TAGS = [
    (re.compile(r"\b4k\b", re.I),              "2160p"),
    (re.compile(r"\b2160p\b", re.I),            "2160p"),
    (re.compile(r"\buhd\b", re.I),              "2160p"),
    (re.compile(r"\b1080p\b", re.I),            "1080p"),
    (re.compile(r"\b720p\b", re.I),             "720p"),
    (re.compile(r"\b480p\b", re.I),             "480p"),
    (re.compile(r"\b360p\b", re.I),             "360p"),
]

# Debrid providers that support magnet: links in their /unrestrict endpoint
# This is a comment / documentation note — the actual handing is in debrid.py.


def base_url():
    """Return the configured Torrentio base URL."""
    return (get_setting("indexers.torrentio_url") or
            "https://torrentio.strem.fun").rstrip("/")


def enabled():
    """Return True if indexers are enabled in settings."""
    return get_setting("indexers.enabled", "true").lower() in ("true", "1")


_http_cache = {}


def _fetch_json(url, timeout=10):
    """Fetch a JSON URL with a tiny in-memory cache (within one call chain)."""
    if url in _http_cache:
        return _http_cache[url]
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "Helix/0.1 (+https://helix.local)",
            "Accept": "application/json",
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        _http_cache[url] = data
        return data
    except (urllib.error.HTTPError, urllib.error.URLError,
            json.JSONDecodeError, OSError) as exc:
        log("torrentio fetch failed: %s %r" % (url, exc), "warn")
        return None


def clear_cache():
    """Clear the in-memory request cache (called before a fresh scrape)."""
    _http_cache.clear()


def _detect_quality(name, title):
    """Return a quality label (2160p / 1080p / 720p / etc) from name + title."""
    combined = (name or "") + " " + (title or "")
    for pattern, label in _QUALITY_TAGS:
        if pattern.search(combined):
            return label
    return "unknown"


def _parse_size(s):
    """Parse a size string like '8.91 GB' -> int MB."""
    if not s:
        return 0
    m = _RE_SIZE.search(s)
    if not m:
        return 0
    num = float(m.group(1).replace(",", "."))
    unit = m.group(2).upper()
    if unit.startswith("G"):
        return int(num * 1024)
    return int(num)


def _parse_seeders(s):
    """Parse seeders from Torrentio title line."""
    if not s:
        return 0
    m = _RE_SEEDERS.search(s)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return 0
    return 0


def _build_magnet(info_hash, display_name):
    """Build a magnet: URI from infoHash and a human-readable name."""
    name_enc = urllib.parse.quote(display_name or "video")
    return "magnet:?xt=urn:btih:%s&dn=%s" % (info_hash, name_enc)


def parse_streams(raw_data, filter_lang=None):
    """Parse the Torrentio JSON response into a list of stream dicts.

    Each output dict:
        {
            "infoHash": str,
            "name": str,           # clean title / release name
            "quality": str,        # 2160p / 1080p / 720p / unknown
            "size": int,           # MB
            "seeders": int,
            "magnet": str,         # magnet: URI
            "fileIdx": int or None,
            "language": str,       # 'en' by default (multi-language present)
            "provider": "torrentio",
        }

    If filter_lang is set (e.g. "en"), only streams whose title suggests
    the language are returned (very coarse heuristic — matches on '/EN',
    'EN/', 'ENGLISH', or the country flags in the title).
    """
    if not raw_data or "streams" not in raw_data:
        return []
    out = []
    for entry in raw_data["streams"]:
        try:
            name_raw = entry.get("name", "")
            title_raw = entry.get("title", "")
            info_hash = entry.get("infoHash", "")
            if not info_hash:
                continue

            # Build the release name from the first line of title
            title_lines = title_raw.split("\n")
            clean_name = title_lines[0].strip() if title_lines else name_raw.strip()
            if not clean_name:
                clean_name = "Torrent"

            quality = _detect_quality(name_raw, title_raw)
            size_mb = _parse_size(title_raw)
            seeders = _parse_seeders(title_raw)
            magnet = _build_magnet(info_hash, clean_name)

            # Coarse language filter: the title contains many language flags.
            # Skip if user wants English and title doesn't suggest it.
            if filter_lang:
                title_up = title_raw.upper()
                lang_ok = any(marker in title_up for marker in
                              ["/EN", "EN/", "ENGLISH", "🇬🇧", "EN.",
                               "/ENGLISH", ".EN."])
                if not lang_ok:
                    continue

            out.append({
                "infoHash": info_hash,
                "name": clean_name,
                "quality": quality,
                "size": size_mb,
                "seeders": seeders,
                "magnet": magnet,
                "fileIdx": entry.get("fileIdx"),
                "language": "en",
                "provider": "torrentio",
            })
        except Exception as exc:
            log("torrentio parse_streams entry: %r" % exc, "warn")
            continue

    # Sort by quality (highest first) then by seeders (descending)
    quality_order = {"2160p": 4, "1080p": 3, "720p": 2, "480p": 1, "unknown": 0}
    out.sort(key=lambda x: (quality_order.get(x["quality"], 0), x["seeders"]),
             reverse=True)
    return out


def fetch_movie_streams(imdb_id, filter_lang=None):
    """Fetch Torrentio streams for a movie by IMDB ID.

    Args:
        imdb_id: IMDB ID string, e.g. "tt1375666".
        filter_lang: optional language filter (e.g. "en").

    Returns:
        List of stream dicts (see parse_streams).
    """
    if not enabled():
        log("torrentio: indexers disabled in settings", "debug")
        return []
    url = "%s/stream/movie/%s.json" % (base_url(), imdb_id)
    data = _fetch_json(url)
    return parse_streams(data, filter_lang)


def fetch_episode_streams(imdb_id, season, episode, filter_lang=None):
    """Fetch Torrentio streams for a TV episode.

    Args:
        imdb_id: IMDB ID of the series, e.g. "tt0903747".
        season: season number (int or str).
        episode: episode number (int or str).
        filter_lang: optional language filter.

    Returns:
        List of stream dicts.
    """
    if not enabled():
        log("torrentio: indexers disabled in settings", "debug")
        return []
    url = "%s/stream/series/%s:%s:%s.json" % (base_url(), imdb_id, season, episode)
    data = _fetch_json(url)
    return parse_streams(data, filter_lang)
