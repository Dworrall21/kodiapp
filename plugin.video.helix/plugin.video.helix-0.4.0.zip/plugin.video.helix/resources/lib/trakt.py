# -*- coding: utf-8 -*-
"""
trakt: Trakt.tv API integration — search, lists, scrobbling, watchlist.

Depends on settings (trakt.client_id, trakt.client_secret, trakt.token).
Token is stored as JSON with {access_token, refresh_token, created_at, expires_in}.
"""
import json
import time
import urllib.request
import urllib.parse
import urllib.error

from .utils import get_setting, set_setting, log, cache_get, cache_set, notify

API_BASE = "https://api.trakt.tv"
_CACHE_PREFIX = "trakt:"
_CACHE_TTL = 1800  # 30 min
TIMEOUT = 10
USER_AGENT = "Helix/0.2"


# ── helpers ──────────────────────────────────────────────────────────

def _token_json():
    """Return parsed token dict or None."""
    raw = get_setting("trakt.token")
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return None


def has_token():
    """Shortcut: do we have a stored access token at all?"""
    t = _token_json()
    if not t:
        return False
    return bool(t.get("access_token"))


def is_configured():
    """Quick check — does the user have a Trakt client_id set?"""
    return bool(get_setting("trakt.client_id", ""))


def is_authorized():
    """Check if a valid OAuth token exists (beyond just having client_id)."""
    return has_token()


def _client_id():
    return get_setting("trakt.client_id", "")


def _client_secret():
    return get_setting("trakt.client_secret", "")


def _token_expired(token):
    """Check whether the stored token needs refresh."""
    created = token.get("created_at", 0)
    expires_in = token.get("expires_in", 7776000)  # default 90 days
    return time.time() > created + expires_in


# ── Auth headers ────────────────────────────────────────────────────

def _headers(with_auth=True):
    """Build auth headers for Trakt API.

    Returns None if no client_id configured (caller should bail).
    """
    cid = _client_id()
    if not cid:
        return None
    h = {
        "Content-Type": "application/json",
        "trakt-api-version": "2",
        "trakt-api-key": cid,
        "User-Agent": USER_AGENT,
    }
    if with_auth:
        token = _token_json()
        if token:
            h["Authorization"] = "Bearer %s" % token.get("access_token", "")
    return h


# ── Low-level HTTP helpers ──────────────────────────────────────────

def _request(method, path, data=None, params=None, with_auth=True, retry_on_401=True):
    """Generic HTTP request to the Trakt API.

    Returns parsed JSON dict/list, or None on failure.
    Handles 401 → token refresh → retry automatically.
    """
    headers = _headers(with_auth=with_auth)
    if not headers:
        return None

    url = API_BASE + "/" + path.lstrip("/")
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)

    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = urllib.request.Request(
        url, data=body, headers=headers,
        method=method or ("POST" if data is not None else "GET"),
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as exc:
        body_text = ""
        try:
            body_text = exc.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        log("trakt %s %s: HTTP %d — %s" % (method or "GET", path, exc.code, body_text[:200]), "warn")
        if exc.code == 401 and with_auth and retry_on_401:
            if refresh_token():
                return _request(method, path, data, params, with_auth, retry_on_401=False)
        return None
    except Exception as exc:
        log("trakt %s %s failed: %r" % (method or "GET", path, exc), "error")
        return None


def _get(path, params=None, with_auth=True, ttl=_CACHE_TTL):
    """HTTP GET with optional file-cache layer."""
    cache_key = _CACHE_PREFIX + path + ":" + urllib.parse.urlencode(sorted((params or {}).items()))
    if ttl > 0:
        cached = cache_get(cache_key, ttl_seconds=ttl)
        if cached is not None:
            return cached
    data = _request("GET", path, params=params, with_auth=with_auth)
    if data is not None and ttl > 0:
        cache_set(cache_key, data)
    return data


def _post(path, data_body, with_auth=True):
    """HTTP POST with JSON body — no caching."""
    return _request("POST", path, data=data_body, with_auth=with_auth)


def _delete(path, data_body, with_auth=True):
    """HTTP DELETE with JSON body — no caching."""
    return _request("DELETE", path, data=data_body, with_auth=with_auth)


# ── Normalised search helpers ───────────────────────────────────────

def _normalise(result_item, media_type):
    """Convert one Trakt search result into our normalised dict."""
    entity = result_item.get(media_type) or result_item.get("movie") or result_item.get("show") or {}
    ids = entity.get("ids") or {}

    title = entity.get("title", "")
    year = entity.get("year", 0) or 0
    overview = entity.get("overview", "") or ""
    poster = ""
    if ids.get("tmdb"):
        poster = "https://image.tmdb.org/t/p/w500%s" % ids["tmdb"]

    return {
        "_score": float(result_item.get("score", 0)),
        "_source": "trakt",
        "title": title,
        "year": year,
        "overview": overview[:500],
        "poster": poster,
        "rating": float(entity.get("rating", 0) or 0),
        "tmdb_id": ids.get("tmdb"),
        "imdb_id": ids.get("imdb"),
        "media_type": media_type,
        "trakt_id": ids.get("trakt"),
    }


# ── Public search functions ─────────────────────────────────────────

def search_movie(query, limit=20):
    """Search Trakt for movies by title."""
    data = _get("/search/movie", {"query": query, "limit": str(limit)}, with_auth=False)
    if not data:
        return []
    return [_normalise(item, "movie") for item in data]


def search_show(query, limit=20):
    """Search Trakt for TV shows by title."""
    data = _get("/search/show", {"query": query, "limit": str(limit)}, with_auth=False)
    if not data:
        return []
    return [_normalise(item, "tv") for item in data]


def search(query, limit_per_type=20):
    """Search both movies and shows on Trakt. Returns merged list sorted by relevance."""
    movies = search_movie(query, limit=limit_per_type)
    shows = search_show(query, limit=limit_per_type)
    combined = movies + shows
    combined.sort(key=lambda r: r["_score"], reverse=True)
    return combined


# ── Token refresh ────────────────────────────────────────────────────

def refresh_token():
    """Refresh the access_token using the stored refresh_token.

    Returns True on success.
    """
    token = _token_json()
    if not token or not token.get("refresh_token"):
        log("trakt: no refresh_token to refresh with", "warn")
        return False

    data = {
        "refresh_token": token["refresh_token"],
        "client_id": _client_id(),
        "client_secret": _client_secret(),
        "grant_type": "refresh_token",
    }
    try:
        req = urllib.request.Request(
            API_BASE + "/oauth/token",
            data=json.dumps(data).encode("utf-8"),
            headers=_headers(with_auth=False) or {"Content-Type": "application/json", "User-Agent": USER_AGENT},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            new_token = json.loads(resp.read().decode("utf-8"))
        new_token["created_at"] = int(time.time())
        set_setting("trakt.token", json.dumps(new_token))
        log("trakt: token refreshed")
        return True
    except Exception as exc:
        log("trakt refresh failed: %r" % exc, "error")
        return False


# ── Scrobbling ───────────────────────────────────────────────────────

def scrobble(action, media_type, tmdb_id, progress=0.0, season=None, episode=None):
    """Send a scrobble event to Trakt.

    ``action``: "start", "stop", "pause"
    ``media_type``: "movie" or "episode"
    ``tmdb_id``: integer TMDB id
    ``progress``: 0–100 percentage
    ``season`` / ``episode``: required for episode scrobbles
    """
    if not _client_id() or not has_token():
        log("trakt scrobble skipped: no client_id or token", "debug")
        return False

    if media_type in ("movie", "movies"):
        data = {
            "movie": {"ids": {"tmdb": int(tmdb_id)}},
            "progress": float(progress),
        }
    else:
        if season is None or episode is None:
            log("trakt scrobble: missing season/episode for episode scrobble", "warn")
            return False
        data = {
            "show": {"ids": {"tmdb": int(tmdb_id)}},
            "episode": {"season": int(season), "number": int(episode)},
            "progress": float(progress),
        }

    result = _request("POST", "scrobble/%s" % action, data=data)
    if result:
        log("trakt scrobble/%s ok (tmdb=%s)" % (action, tmdb_id), "info")
        return True
    log("trakt scrobble/%s failed" % action, "warn")
    return False


def scrobble_start(media_type, tmdb_id, season=None, episode=None):
    return scrobble("start", media_type, tmdb_id, 0.0, season, episode)


def scrobble_stop(media_type, tmdb_id, progress=100.0, season=None, episode=None):
    return scrobble("stop", media_type, tmdb_id, progress, season, episode)


def scrobble_pause(media_type, tmdb_id, progress=50.0, season=None, episode=None):
    return scrobble("pause", media_type, tmdb_id, progress, season, episode)


# ── Mark as watched ──────────────────────────────────────────────────

def mark_as_watched(media_type, tmdb_id, season=None, episode=None):
    """Add an item to the watch history on Trakt."""
    if media_type in ("movie", "movies"):
        data = {"movies": [{"ids": {"tmdb": int(tmdb_id)}}]}
    else:
        if season is not None and episode is not None:
            data = {
                "shows": [{
                    "ids": {"tmdb": int(tmdb_id)},
                    "seasons": [{"number": int(season), "episodes": [{"number": int(episode)}]}],
                }]
            }
        else:
            data = {"shows": [{"ids": {"tmdb": int(tmdb_id)}}]}

    result = _post("sync/history", data)
    if result:
        added = result.get("added", {})
        total = added.get("movies", 0) + added.get("episodes", 0) + added.get("shows", 0)
        if total > 0:
            log("trakt mark-watched ok (tmdb=%s, +%d)" % (tmdb_id, total), "info")
            return True
    log("trakt mark-watched returned no additions (tmdb=%s)" % tmdb_id, "warn")
    return False


# ── Watchlist ────────────────────────────────────────────────────────

def get_watchlist(media_type="movies"):
    """Pull the authenticated user's watchlist.

    ``media_type``: "movies" or "shows"
    Returns a list of dicts with keys: title, year, tmdb_id, trakt_id, listed_at, poster
    """
    if not has_token():
        log("trakt get_watchlist: no token", "warn")
        return []
    path = "sync/watchlist/%s?extended=full" % media_type
    raw = _request("GET", path)
    if raw is None:
        return []
    if not isinstance(raw, list):
        return []

    key = "movie" if media_type == "movies" else "show"
    out = []
    for item in raw:
        obj = item.get(key, {})
        ids = obj.get("ids", {})
        tmdb_id = ids.get("tmdb")
        if not tmdb_id:
            continue
        out.append({
            "title": obj.get("title", "?"),
            "year": (obj.get("year") or 0),
            "tmdb_id": tmdb_id,
            "trakt_id": ids.get("trakt"),
            "slug": ids.get("slug", ""),
            "listed_at": item.get("listed_at", ""),
            "overview": obj.get("overview", ""),
            "poster": "",
        })
    return out


def remove_from_watchlist(media_type, tmdb_id):
    """Remove an item from the user's Trakt watchlist."""
    if media_type in ("movie", "movies"):
        data = {"movies": [{"ids": {"tmdb": int(tmdb_id)}}]}
    else:
        data = {"shows": [{"ids": {"tmdb": int(tmdb_id)}}]}

    result = _post("sync/watchlist/remove", data)
    if result:
        deleted = result.get("deleted", {})
        total = deleted.get("movies", 0) + deleted.get("shows", 0)
        if total > 0:
            log("trakt remove-from-watchlist ok (tmdb=%s, +%d)" % (tmdb_id, total), "info")
            return True
    return False


# ── User & list helpers ─────────────────────────────────────────────

def get_user_slug():
    """Return the current user's slug (e.g. 'dworrall21') or None."""
    data = _get("/users/me", with_auth=True)
    if not data:
        return None
    return data.get("ids", {}).get("slug") or data.get("username")


def get_user_lists():
    """Fetch all custom lists for the authenticated user.

    Returns list of dicts: {id, name, slug, description, privacy, item_count, updated_at}
    """
    data = _get("/users/me/lists", with_auth=True)
    if not isinstance(data, list):
        return []
    out = []
    for lst in data:
        ids = lst.get("ids", {})
        out.append({
            "id": str(ids.get("trakt", "")),
            "slug": ids.get("slug", ""),
            "name": lst.get("name", "(unnamed)"),
            "description": lst.get("description", ""),
            "privacy": lst.get("privacy", "private"),
            "item_count": lst.get("counts", {}).get("items", 0) if isinstance(lst.get("counts"), dict) else 0,
            "updated_at": lst.get("updated_at", ""),
        })
    return out


def get_list_items(list_id, list_type="movies"):
    """Fetch items in a specific Trakt list.

    list_type: "movies", "shows", "seasons", "episodes", "people", "all"
    Returns list of dicts with normalized fields.
    """
    data = _get("/lists/%s/items/%s" % (list_id, list_type), with_auth=True)
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        entry = _normalize_list_item(item, list_type)
        if entry:
            out.append(entry)
    return out


def _normalize_list_item(item, list_type=None):
    """Convert a Trakt list item to our normalized format."""
    t = item.get("type", list_type or "movie")
    entry = {
        "type": t, "trakt_id": None, "tmdb_id": None,
        "imdb_id": None, "title": "", "year": None,
    }
    if t == "movie":
        movie = item.get("movie", {})
        ids = movie.get("ids", {})
        entry["trakt_id"] = ids.get("trakt")
        entry["tmdb_id"] = ids.get("tmdb")
        entry["imdb_id"] = ids.get("imdb")
        entry["title"] = movie.get("title", "")
        entry["year"] = movie.get("year")
    elif t == "show":
        show = item.get("show", {})
        ids = show.get("ids", {})
        entry["trakt_id"] = ids.get("trakt")
        entry["tmdb_id"] = ids.get("tmdb")
        entry["imdb_id"] = ids.get("imdb")
        entry["title"] = show.get("title", "")
        entry["year"] = show.get("year")
    return entry


def create_list(name, description="", privacy="private"):
    """Create a new custom list on Trakt. Returns {id, slug, name} or None."""
    payload = {"name": name, "description": description, "privacy": privacy}
    resp = _post("/users/me/lists", payload)
    if not resp:
        return None
    ids = resp.get("ids", {})
    return {
        "id": str(ids.get("trakt", "")),
        "slug": ids.get("slug", ""),
        "name": resp.get("name", name),
    }


def find_or_create_list(name, description="Helix favorites synced from addon", privacy="private"):
    """Find an existing list by name, or create one. Returns {id, slug, name}."""
    lists = get_user_lists()
    for lst in lists:
        if lst["name"] == name:
            return lst
    return create_list(name, description, privacy)


def add_items_to_list(list_id, items):
    """Add movies/shows to a Trakt list.

    items: list of dicts [{"media_type": "movie", "tmdb_id": "12345"}, ...]
    Returns True on success.
    """
    movies = []
    shows = []
    for it in items:
        tmdb_id = it.get("tmdb_id")
        if not tmdb_id:
            continue
        try:
            int_tmdb = int(tmdb_id)
        except (ValueError, TypeError):
            continue
        mt = it.get("media_type", "movie")
        entry = {"ids": {"tmdb": int_tmdb}}
        if mt in ("tv", "show"):
            shows.append(entry)
        else:
            movies.append(entry)

    payload = {}
    if movies:
        payload["movies"] = movies
    if shows:
        payload["shows"] = shows
    if not payload:
        return False

    resp = _post("/lists/%s/items" % list_id, payload)
    if resp is None:
        return False
    added = resp.get("added", {}) if resp else {}
    n = added.get("movies", 0) + added.get("shows", 0)
    log("Trakt: added %d items to list %s" % (n, list_id))
    return True


def remove_items_from_list(list_id, items):
    """Remove movies/shows from a Trakt list.

    items: same format as add_items_to_list
    Returns True on success.
    """
    movies = []
    shows = []
    for it in items:
        tmdb_id = it.get("tmdb_id")
        if not tmdb_id:
            continue
        try:
            int_tmdb = int(tmdb_id)
        except (ValueError, TypeError):
            continue
        mt = it.get("media_type", "movie")
        entry = {"ids": {"tmdb": int_tmdb}}
        if mt in ("tv", "show"):
            shows.append(entry)
        else:
            movies.append(entry)

    payload = {}
    if movies:
        payload["movies"] = movies
    if shows:
        payload["shows"] = shows
    if not payload:
        return False

    resp = _delete("/lists/%s/items" % list_id, payload)
    if resp is None:
        return False
    deleted = resp.get("deleted", {}) if resp else {}
    n = deleted.get("movies", 0) + deleted.get("shows", 0)
    log("Trakt: removed %d items from list %s" % (n, list_id))
    return True


# ── Favorites sync ───────────────────────────────────────────────────

HELIX_FAV_LIST_NAME = "Helix Favorites"


def sync_favorites_to_trakt(local_favorites):
    """Push local favorites to Trakt's 'Helix Favorites' list.

    Strategy: fetch current list items → diff → add missing.
    Returns dict with {added: N, total: N}
    """
    if not local_favorites:
        return {"added": 0, "total": 0}

    syncable = [f for f in local_favorites if f.get("tmdb_id")]
    if not syncable:
        log("Trakt: no favorites with TMDB ID to sync", "info")
        return {"added": 0, "total": 0}

    fav_list = find_or_create_list(HELIX_FAV_LIST_NAME)
    if not fav_list:
        log("Trakt: could not find or create Helix Favorites list", "error")
        return {"added": 0, "total": 0}

    list_id = fav_list["id"]
    if not list_id:
        return {"added": 0, "total": 0}

    existing = set()
    try:
        for lt in ("movies", "shows"):
            items = get_list_items(list_id, lt) or []
            for it in items:
                if it["tmdb_id"]:
                    t = "tv" if lt == "shows" else "movie"
                    existing.add((str(it["tmdb_id"]), t))
    except Exception as exc:
        log("Trakt: failed to fetch existing list items: %s" % exc, "warn")
        existing = set()

    to_add = []
    for fav in syncable:
        tmdb_id = str(fav.get("tmdb_id") or "")
        media_type = str(fav.get("media_type") or "movie")
        if not tmdb_id:
            continue
        norm_type = "tv" if media_type in ("tv", "show") else "movie"
        if (tmdb_id, norm_type) not in existing:
            to_add.append({"tmdb_id": tmdb_id, "media_type": norm_type})

    if not to_add:
        log("Trakt: all favorites already synced (%d items)" % len(syncable))
        return {"added": 0, "total": len(syncable)}

    ok = add_items_to_list(list_id, to_add)
    if ok:
        return {"added": len(to_add), "total": len(syncable)}
    return {"added": 0, "total": len(syncable)}
