# -*- coding: utf-8 -*-
"""
speedtest: minimal latency + download speed check.

We do not bundle a binary. We:
  1. Find a few known large static URLs.
  2. Measure round-trip + how long it takes to read N bytes.
  3. Report a single line + a toast.
"""
import time
import urllib.request
import socket

from .utils import notify, log, text_viewer

# Small files, served by reputable CDNs. Adjust if any go dead.
TARGETS = [
    ("Cloudflare",  "https://speed.cloudflare.com/__down?bytes=5000000"),
    ("Hetzner",     "https://speed.hetzner.de/100MB.bin"),
    ("OVH",         "https://proof.ovh.net/files/10Mb.dat"),
]


def run():
    notify("Helix", "Speed test starting…", "info", 2000)
    socket.setdefaulttimeout(15)
    out = []
    for name, url in TARGETS:
        try:
            t0 = time.time()
            req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = resp.read(2 * 1024 * 1024)  # 2 MB
            dt = max(0.001, time.time() - t0)
            mbps = (len(data) * 8) / dt / 1_000_000
            out.append("%s: %.1f Mbps  (%.2fs, %.1f MB)" % (name, mbps, dt, len(data) / 1024 / 1024))
        except Exception as exc:
            out.append("%s: failed (%s)" % (name, exc))
    body = "\n".join(out) + "\n\nHigher is better. First test is usually slower (TLS handshake)."
    text_viewer("Helix — Speedtest", body)
    notify("Helix", out[0] if out else "No result", "info", 4000)
