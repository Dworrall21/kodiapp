# -*- coding: utf-8 -*-
"""
account_manager: authorize/list debrid providers + Trakt.

The addon's settings store the API key (debrid) or token (Trakt).
This module is the on-screen UI for them.
"""
import time
import json
import urllib.request
import urllib.parse
import urllib.error

from .utils import add_item, url_for, log, notify, get_setting, set_setting, dialog_input
from .modules.colors import c, b
from . import debrid


PROVIDER_AUTH_URLS = {
    "Real-Debrid": "https://real-debrid.com/apitoken",
    "AllDebrid":   "https://alldebrid.com/apikeys",
    "Premiumize":  "https://premiumize.me/account",
    "TorBox":      "https://torbox.app/settings",
}


def menu():
    from .utils import set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)

    add_item(c("gold", b("--- Debrid ---")), "", is_folder=False)
    for name, url in PROVIDER_AUTH_URLS.items():
        # Open the provider's API-key page so the user can grab their key.
        add_item(
            c("white", b("Authorize " + name)),
            url_for("authorize_debrid", name=name),
            is_folder=True,
            info={"plot": "Open the provider's API-key page, paste the key here."},
        )
    add_item(
        c("white", b("Check Active Debrid")),
        url_for("check_debrid"),
        is_folder=True,
        info={"plot": "Test the currently configured debrid key."},
    )

    add_item(c("gold", b("--- Trakt ---")), "", is_folder=False)
    add_item(
        c("white", b("Trakt Device Flow")),
        url_for("trakt_device"),
        is_folder=True,
        info={"plot": "Authorize Trakt via the device-code flow."},
    )
    add_item(
        c("white", b("Trakt Lists")),
        url_for("trakt_lists"),
        is_folder=True,
        info={"plot": "Browse your Trakt custom lists, sync favorites."},
    )


def authorize_debrid(params):
    """Walk the user through: open provider site -> paste key -> save."""
    name = params.get("name", "")
    if name not in PROVIDER_AUTH_URLS:
        notify("Helix", "Unknown provider: " + str(name), "error")
        return
    site = PROVIDER_AUTH_URLS[name]
    setting_keys = {
        "Real-Debrid": "debrid.real_debrid.key",
        "AllDebrid":   "debrid.all_debrid.key",
        "Premiumize":  "debrid.premiumize.key",
        "TorBox":      "debrid.torbox.key",
    }
    # Step 1: tell the user where to get the key (toast + text).
    notify("Helix", "Open: " + site + "  (then paste key)", "info", 6000)
    # Step 2: ask for the key.
    key = dialog_input(name + " — paste API key (or leave blank to cancel)")
    if not key:
        return
    if not set_setting(setting_keys[name], key):
        notify("Helix", "Failed to save key.", "error")
        return
    # Step 3: also flip the active debrid to this provider (matching enum order)
    enum_map = {"Real-Debrid": 1, "AllDebrid": 2, "Premiumize": 3, "TorBox": 4}
    set_setting("debrid.provider", str(enum_map.get(name, 0)))
    notify("Helix", "%s key saved." % name, "info", 3000)


def check_debrid(params):
    debrid.test_active()


def trakt_device_flow():
    """Trakt device-code flow (skeleton).

    Real flow:
      1. POST /oauth/device/code with client_id
      2. Show user_code, ask user to visit trakt.tv/activate
      3. Poll /oauth/device/token until user authorizes
      4. Save token JSON to settings: trakt.token
    """
    client_id = get_setting("trakt.client_id")
    if not client_id:
        notify("Helix", "Set trakt.client_id in settings first.", "warn", 5000)
        return
    try:
        data = urllib.request.urlopen(
            urllib.request.Request(
                "https://api.trakt.tv/oauth/device/code",
                data=json.dumps({"client_id": client_id}).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "Helix/0.1",
                },
                method="POST",
            ),
            timeout=10,
        )
        payload = json.loads(data.read().decode("utf-8"))
    except Exception as exc:
        log("trakt device code failed: %r" % exc, "error")
        notify("Helix", "Trakt: " + str(exc), "error")
        return

    user_code = payload.get("user_code", "?")
    verification_url = payload.get("verification_url", "https://trakt.tv/activate")
    device_code = payload.get("device_code", "")
    interval = int(payload.get("interval", 5))
    expires_in = int(payload.get("expires_in", 600))

    from .utils import text_viewer
    text_viewer(
        "Trakt Activation",
        "[B]Trakt Device Code[/B]\n\n"
        "Your code:  [B][COLOR=lime]%s[/COLOR][/B]\n\n"
        "Visit:  [B]%s[/B]\n"
        "Enter the code above on the Trakt website.\n\n"
        "This dialog will close automatically once authorized."
        % (user_code, verification_url),
    )

    # Poll
    import xbmc
    deadline = time.time() + expires_in
    while time.time() < deadline:
        xbmc.sleep(interval * 1000)
        try:
            resp = urllib.request.urlopen(
                urllib.request.Request(
                    "https://api.trakt.tv/oauth/device/token",
                    data=json.dumps({
                        "code": device_code,
                        "client_id": client_id,
                        "client_secret": get_setting("trakt.client_secret", ""),
                    }).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "Helix/0.1"},
                    method="POST",
                ),
                timeout=10,
            )
            token = json.loads(resp.read().decode("utf-8"))
            if token.get("access_token"):
                token["created_at"] = int(time.time())
                set_setting("trakt.token", json.dumps(token))
                notify("Helix", "Trakt authorized.", "info", 3000)
                return
        except urllib.error.HTTPError as he:
            if he.code == 400:
                # pending — keep polling
                continue
            if he.code == 410:
                notify("Helix", "Trakt code expired; try again.", "error", 5000)
                return
            continue
        except Exception as exc:
            log("trakt poll: %r" % exc, "warn")
            continue
    notify("Helix", "Trakt authorization timed out.", "warn", 5000)
