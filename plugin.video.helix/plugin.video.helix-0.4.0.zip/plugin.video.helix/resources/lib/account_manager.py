# -*- coding: utf-8 -*-
"""
account_manager: unified account dashboard.
Shows status of all debrid providers + Trakt at a glance.
Authorize, test, and switch providers from one screen.
"""
import time
import json
import socket
import urllib.request
import urllib.parse
import urllib.error

from .utils import add_item, url_for, log, notify, get_setting, set_setting, dialog_input, text_viewer
from .modules.colors import c, b
from . import debrid
from .trakt import TRAKT_CLIENT_ID, TRAKT_CLIENT_SECRET

import xbmc
import xbmcgui

PROVIDER_CONFIG = [
    ("Real-Debrid", "debrid.real_debrid.key", 1, "https://real-debrid.com/apitoken"),
    ("AllDebrid",   "debrid.all_debrid.key",  2, "https://alldebrid.com/apikeys"),
    ("Premiumize",  "debrid.premiumize.key",  3, "https://premiumize.me/account"),
    ("TorBox",      "debrid.torbox.key",      4, None),  # OAuth device flow
]

PROVIDER_ENUM = {p[0]: p[2] for p in PROVIDER_CONFIG}


def menu():
    """Account dashboard: see all account statuses at a glance."""
    from .utils import set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)

    _section("Debrid Providers")
    for name, setting_key, enum_val, auth_url in PROVIDER_CONFIG:
        key = get_setting(setting_key, "")
        has_key = bool(key and key.strip())
        active = debrid.active_provider_name()
        is_active = (name == active)
        
        if is_active:
            icon = c("ok", "● ")
        elif has_key:
            icon = c("dim-gray", "○ ")
        else:
            icon = c("dim-gray", "○ ")
        
        status = ""
        if is_active:
            status = c("ok", " [ACTIVE]")
        elif has_key:
            status = c("warn", " [key saved, not active]")
        
        label = "%s%s%s" % (icon, name, status)
        plot = "Active debrid provider. Click to re-authorize." if is_active else \
               ("Key saved. Click to activate or re-authorize." if has_key else \
                "Not configured. Click to set up.")
        
        add_item(c("white", b(label)), url_for("authorize_debrid", name=name),
                 is_folder=True, info={"plot": plot})

    add_item(c("gold", b("Test All Providers")), url_for("check_all_debrid"),
             is_folder=False, info={"plot": "Check connectivity for all configured debrid services."})

    _section("Trakt")
    trakt_configured = bool(get_setting("trakt.client_id", "") or TRAKT_CLIENT_ID)
    trakt_token = get_setting("trakt.token", "")
    trakt_ok = bool(trakt_token and trakt_token.strip())
    
    if trakt_ok:
        icon = c("ok", "● ")
        status = c("ok", " [Authorized]")
    elif trakt_configured:
        icon = c("warn", "○ ")
        status = c("warn", " [Not authorized]")
    else:
        icon = c("dim-gray", "○ ")
        status = c("dim-gray", " [Not configured]")

    add_item(c("white", b("%sTrakt%s" % (icon, status))), url_for("trakt_device"),
             is_folder=True, info={"plot": "Trakt OAuth device flow."})
    
    if trakt_ok:
        add_item(c("white", b("Trakt Account Info")), url_for("trakt_account"),
                 is_folder=False, info={"plot": "View Trakt account details."})
        add_item(c("white", b("Trakt Lists")), url_for("trakt_lists"),
                 is_folder=True, info={"plot": "Browse your Trakt custom lists, sync favorites."})
        add_item(c("danger", b("Revoke Trakt")), url_for("trakt_revoke"),
                 is_folder=False, info={"plot": "Remove Trakt authorization."})

    _section("Quick Actions")
    add_item(c("lightgray", "Helix Settings…"), url_for("open_settings"),
             is_folder=False, info={"plot": "Configure M3U, TMDB, debrid, indexers, cache."})


def _section(title):
    add_item(c("gold", b("--- %s ---" % title)), "", is_folder=False)


# =========================================================================
# Authorization flows
# =========================================================================

def authorize_debrid(params):
    """Route to the correct auth flow based on provider name."""
    name = params.get("name", "")
    config = {p[0]: p for p in PROVIDER_CONFIG}
    if name not in config:
        notify("Helix", "Unknown provider: " + str(name), "error")
        return
    if name == "TorBox":
        _torbox_device_flow()
    else:
        _manual_key_flow(name)


def _manual_key_flow(name):
    """Manual API-key paste flow for RD/AD/PM."""
    config = {p[0]: p for p in PROVIDER_CONFIG}
    entry = config.get(name)
    if not entry:
        return
    _, setting_key, enum_val, auth_url = entry
    notify("Helix", "Open: " + auth_url + "  (then paste key)", "info", 6000)
    key = dialog_input(name + " — paste API key (or leave blank to cancel)")
    if not key:
        return
    if not set_setting(setting_key, key):
        notify("Helix", "Failed to save key.", "error")
        return
    set_setting("debrid.provider", str(enum_val))
    notify("Helix", "%s key saved and activated." % name, "info", 3000)


def _torbox_device_flow():
    """TorBox OAuth device-code flow with live polling dialog."""
    try:
        req = urllib.request.Request(
            "https://api.torbox.app/v1/api/user/auth/device/start",
            method="GET",
            headers={"User-Agent": "Helix/0.4", "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        log("TorBox device start failed: %r" % exc, "error")
        notify("Helix", "TorBox: " + str(exc), "error")
        return

    if not payload.get("success"):
        notify("Helix", "TorBox: device auth start failed.", "error")
        return

    data = payload.get("data", {})
    device_code = data.get("device_code", "")
    user_code = data.get("code", "?")
    interval = int(data.get("interval", 5))
    verification_url = data.get("friendly_verification_url", "https://tor.box/link")

    progress = xbmcgui.DialogProgress()
    progress.create("TorBox Activation",
                    "Your code: [B][COLOR=lime]%s[/COLOR][/B]\n"
                    "Visit: [B]%s[/B]\n"
                    "Enter the code on the TorBox website.\n\n"
                    "Waiting for authorization..." % (user_code, verification_url))
    progress.update(0)

    deadline = time.time() + 600
    succeeded = False
    while time.time() < deadline and not progress.iscanceled():
        progress.update(0)
        xbmc.sleep(interval * 1000)
        try:
            poll_req = urllib.request.Request(
                "https://api.torbox.app/v1/api/user/auth/device/token",
                data=json.dumps({"device_code": device_code}).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Helix/0.4"},
                method="POST",
            )
            with urllib.request.urlopen(poll_req, timeout=15) as resp:
                token_payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as he:
            if he.code in (400, 401):
                continue
            log("TorBox poll error: %d" % he.code, "warn")
            continue
        except (urllib.error.URLError, socket.timeout, OSError):
            continue
        except Exception as exc:
            log("TorBox poll: %r" % exc, "warn")
            continue

        if token_payload.get("success") and token_payload.get("data", {}).get("token"):
            token = token_payload["data"]["token"]
            set_setting("debrid.torbox.key", token)
            set_setting("debrid.provider", "4")
            succeeded = True
            break

    progress.close()
    if succeeded:
        notify("Helix", "TorBox authorized.", "info", 3000)
    elif progress.iscanceled():
        notify("Helix", "TorBox authorization cancelled.", "warn", 3000)
    else:
        notify("Helix", "TorBox authorization timed out.", "warn", 5000)


def check_debrid(params):
    """Test the currently active debrid provider."""
    debrid.test_active()


def check_all_debrid(params):
    """Test all configured debrid providers and show results."""
    results = []
    for name, setting_key, _, _ in PROVIDER_CONFIG:
        key = get_setting(setting_key, "").strip()
        if not key:
            results.append((name, False, "no key saved"))
            continue
        # Temporarily switch to this provider to test
        was_active = get_setting("debrid.provider", "0")
        set_setting("debrid.provider", str(PROVIDER_ENUM.get(name, 0)))
        ok, msg = debrid.check_active()
        # Restore previous active provider
        set_setting("debrid.provider", was_active)
        results.append((name, ok, msg))
    
    lines = ["=== Account Status ===\n"]
    passed = 0
    for name, ok, detail in results:
        status = "✓ OK" if ok else "✗ FAIL"
        if ok: passed += 1
        lines.append("  %s  %s: %s" % (status, name, detail))
    lines.append("\n%d/%d providers connected" % (passed, len(results)))
    
    # Also show Trakt status
    from . import trakt as trakt_mod
    if trakt_mod.is_authorized():
        lines.append("\n  Trakt: ✓ Authorized")
    elif trakt_mod.is_configured():
        lines.append("\n  Trakt: ○ Not authorized (run device flow)")
    else:
        lines.append("\n  Trakt: ○ Not configured")
    
    text_viewer("Account Status", "\n".join(lines))


def trakt_device_flow():
    """Trakt device-code flow with live polling dialog."""
    client_id = get_setting("trakt.client_id", "") or TRAKT_CLIENT_ID
    if not client_id:
        notify("Helix", "No Trakt Client ID — add one in Settings.", "warn", 5000)
        return
    try:
        data = urllib.request.urlopen(
            urllib.request.Request(
                "https://api.trakt.tv/oauth/device/code",
                data=json.dumps({"client_id": client_id}).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Helix/0.1"},
                method="POST",
            ), timeout=10,
        )
        payload = json.loads(data.read().decode("utf-8"))
    except Exception as exc:
        log("trakt device code failed: %r" % exc, "error")
        notify("Helix", "Trakt: " + str(exc), "error")
        return

    user_code = payload.get("user_code", "?")
    verification_url = payload.get("verification_url", "https://trakt.tv/activate")
    device_code = payload.get("device_code", "")
    interval = int(payload.get("interval", 5))
    expires_in = int(payload.get("expires_in", 600))

    progress = xbmcgui.DialogProgress()
    progress.create("Trakt Activation",
                    "Your code: [B][COLOR=lime]%s[/COLOR][/B]\n"
                    "Visit: [B]%s[/B]\n"
                    "Enter the code on the Trakt website.\n\n"
                    "Waiting for authorization..." % (user_code, verification_url))
    progress.update(0)

    deadline = time.time() + expires_in
    succeeded = False
    while time.time() < deadline and not progress.iscanceled():
        progress.update(0)
        xbmc.sleep(interval * 1000)
        try:
            resp = urllib.request.urlopen(
                urllib.request.Request(
                    "https://api.trakt.tv/oauth/device/token",
                    data=json.dumps({
                        "code": device_code, "client_id": client_id,
                        "client_secret": get_setting("trakt.client_secret", "") or TRAKT_CLIENT_SECRET,
                    }).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "Helix/0.1"},
                    method="POST",
                ), timeout=10,
            )
            token = json.loads(resp.read().decode("utf-8"))
            if token.get("access_token"):
                token["created_at"] = int(time.time())
                set_setting("trakt.token", json.dumps(token))
                succeeded = True
                break
        except urllib.error.HTTPError as he:
            if he.code == 400: continue
            if he.code == 410:
                notify("Helix", "Trakt code expired; try again.", "error", 5000)
                break
            continue
        except Exception as exc:
            log("trakt poll: %r" % exc, "warn")
            continue

    progress.close()
    if succeeded:
        notify("Helix", "Trakt authorized.", "info", 3000)
    elif progress.iscanceled():
        notify("Helix", "Trakt authorization cancelled.", "warn", 3000)
    else:
        notify("Helix", "Trakt authorization timed out.", "warn", 5000)


def trakt_revoke(params):
    """Revoke Trakt authorization and clear token."""
    if not xbmcgui.Dialog().yesno("Helix", "Revoke Trakt authorization?"):
        return
    set_setting("trakt.token", "")
    notify("Helix", "Trakt token cleared.", "info", 3000)
