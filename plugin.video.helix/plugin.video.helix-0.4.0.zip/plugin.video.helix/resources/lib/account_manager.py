# -*- coding: utf-8 -*-
"""
account_manager: authorize/list debrid providers + Trakt.

The addon's settings store the API key (debrid) or token (Trakt).
This module is the on-screen UI for them.
"""
import time
import json
import socket
import urllib.request
import urllib.parse
import urllib.error

from .utils import add_item, url_for, log, notify, get_setting, set_setting, dialog_input
from .modules.colors import c, b
from . import debrid
from .trakt import TRAKT_CLIENT_ID, TRAKT_CLIENT_SECRET

import xbmc
import xbmcgui

PROVIDER_AUTH_URLS = {
    "Real-Debrid": "https://real-debrid.com/apitoken",
    "AllDebrid":   "https://alldebrid.com/apikeys",
    "Premiumize":  "https://premiumize.me/account",
    "TorBox":      None,  # uses OAuth device flow
}

PROVIDER_SETTING_KEYS = {
    "Real-Debrid": "debrid.real_debrid.key",
    "AllDebrid":   "debrid.all_debrid.key",
    "Premiumize":  "debrid.premiumize.key",
    "TorBox":      "debrid.torbox.key",
}

PROVIDER_ENUM = {"Real-Debrid": 1, "AllDebrid": 2, "Premiumize": 3, "TorBox": 4}


def menu():
    from .utils import set_content, add_sort_method
    import xbmcplugin
    set_content("files")
    add_sort_method(xbmcplugin.SORT_METHOD_LABEL)

    add_item(c("gold", b("--- Debrid ---")), "", is_folder=False)
    for name in PROVIDER_AUTH_URLS:
        add_item(
            c("white", b("Authorize " + name)),
            url_for("authorize_debrid", name=name),
            is_folder=True,
            info={"plot": PROVIDER_AUTH_URLS[name] or "Connect via device-code OAuth."},
        )
    add_item(
        c("white", b("Check Active Debrid")),
        url_for("check_debrid"),
        is_folder=True,
        info={"plot": "Test the currently configured debrid key."},
    )
    add_item(c("gold", b("--- Trakt ---")), "", is_folder=False)
    add_item(
        c("white", b("Authorize Trakt")),
        url_for("trakt_device"),
        is_folder=True,
        info={"plot": "Trakt device-code flow — requires client_id in settings."},
    )
    add_item(
        c("white", b("Trakt Lists")),
        url_for("trakt_lists"),
        is_folder=True,
        info={"plot": "Browse your Trakt custom lists, sync favorites."},
    )


def authorize_debrid(params):
    """Route to the correct auth flow based on provider name."""
    name = params.get("name", "")
    if name not in PROVIDER_AUTH_URLS:
        notify("Helix", "Unknown provider: " + str(name), "error")
        return
    if name == "TorBox":
        _torbox_device_flow()
    else:
        _manual_key_flow(name)


def _manual_key_flow(name):
    """Manual API-key paste flow for RD/AD/PM."""
    site = PROVIDER_AUTH_URLS.get(name, "")
    setting_key = PROVIDER_SETTING_KEYS.get(name)
    if not setting_key:
        return
    notify("Helix", "Open: " + site + "  (then paste key)", "info", 6000)
    key = dialog_input(name + " — paste API key (or leave blank to cancel)")
    if not key:
        return
    if not set_setting(setting_key, key):
        notify("Helix", "Failed to save key.", "error")
        return
    enum_val = PROVIDER_ENUM.get(name, 0)
    set_setting("debrid.provider", str(enum_val))
    notify("Helix", "%s key saved and activated." % name, "info", 3000)


def _torbox_device_flow():
    """TorBox OAuth device-code flow with live polling dialog."""
    try:
        req = urllib.request.Request(
            "https://api.torbox.app/v1/api/user/auth/device/start",
            method="GET",
            headers={"User-Agent": "Helix/0.4", "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        log("TorBox device start failed: %r" % exc, "error")
        notify("Helix", "TorBox: " + str(exc), "error")
        return

    if not payload.get("success"):
        notify("Helix", "TorBox: device auth start failed.", "error")
        return

    data = payload.get("data", {})
    device_code = data.get("device_code", "")
    user_code = data.get("code", "?")
    interval = int(data.get("interval", 5))
    expires_at = data.get("expires_at", "")
    verification_url = data.get("friendly_verification_url", "https://tor.box/link")

    # Show progress dialog while polling for auth
    progress = xbmcgui.DialogProgress()
    progress.create("TorBox Activation",
                    "Your code: [B][COLOR=lime]%s[/COLOR][/B]\n"
                    "Visit: [B]%s[/B]\n"
                    "Enter the code on the TorBox website.\n\n"
                    "Waiting for authorization..." % (user_code, verification_url))
    progress.update(0)

    deadline = time.time() + 600
    succeeded = False
    while time.time() < deadline and not progress.iscanceled():
        progress.update(0)
        xbmc.sleep(interval * 1000)
        try:
            poll_req = urllib.request.Request(
                "https://api.torbox.app/v1/api/user/auth/device/token",
                data=json.dumps({"device_code": device_code}).encode("utf-8"),
                headers={"Content-Type": "application/json", "User-Agent": "Helix/0.4"},
                method="POST",
            )
            with urllib.request.urlopen(poll_req, timeout=15) as resp:
                token_payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as he:
            if he.code in (400, 401):
                continue  # still pending
            log("TorBox poll error: %d" % he.code, "warn")
            continue
        except (urllib.error.URLError, socket.timeout, OSError):
            # Timeout or connection issue — retry
            continue
        except Exception as exc:
            log("TorBox poll: %r" % exc, "warn")
            continue

        if token_payload.get("success") and token_payload.get("data", {}).get("token"):
            token = token_payload["data"]["token"]
            set_setting(PROVIDER_SETTING_KEYS["TorBox"], token)
            set_setting("debrid.provider", str(PROVIDER_ENUM["TorBox"]))
            succeeded = True
            break

    progress.close()
    if succeeded:
        notify("Helix", "TorBox authorized.", "info", 3000)
    elif progress.iscanceled():
        notify("Helix", "TorBox authorization cancelled.", "warn", 3000)
    else:
        notify("Helix", "TorBox authorization timed out.", "warn", 5000)


def check_debrid(params):
    debrid.test_active()


def trakt_device_flow():
    """Trakt device-code flow with live polling dialog."""
    client_id = get_setting("trakt.client_id", "") or TRAKT_CLIENT_ID  # fallback to built-in
    if not client_id:
        notify("Helix", "No Trakt Client ID available — add one in Settings.", "warn", 5000)
        return
    try:
        data = urllib.request.urlopen(
            urllib.request.Request(
                "https://api.trakt.tv/oauth/device/code",
                data=json.dumps({"client_id": client_id}).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "User-Agent": "Helix/0.1",
                },
                method="POST",
            ),
            timeout=10,
        )
        payload = json.loads(data.read().decode("utf-8"))
    except Exception as exc:
        log("trakt device code failed: %r" % exc, "error")
        notify("Helix", "Trakt: " + str(exc), "error")
        return

    user_code = payload.get("user_code", "?")
    verification_url = payload.get("verification_url", "https://trakt.tv/activate")
    device_code = payload.get("device_code", "")
    interval = int(payload.get("interval", 5))
    expires_in = int(payload.get("expires_in", 600))

    # Progress dialog with live polling
    progress = xbmcgui.DialogProgress()
    progress.create("Trakt Activation",
                    "Your code: [B][COLOR=lime]%s[/COLOR][/B]\n"
                    "Visit: [B]%s[/B]\n"
                    "Enter the code on the Trakt website.\n\n"
                    "Waiting for authorization..." % (user_code, verification_url))
    progress.update(0)

    deadline = time.time() + expires_in
    succeeded = False
    while time.time() < deadline and not progress.iscanceled():
        progress.update(0)
        xbmc.sleep(interval * 1000)
        try:
            resp = urllib.request.urlopen(
                urllib.request.Request(
                    "https://api.trakt.tv/oauth/device/token",
                    data=json.dumps({
                        "code": device_code,
                        "client_id": client_id,
                        "client_secret": get_setting("trakt.client_secret", "") or TRAKT_CLIENT_SECRET,
                    }).encode("utf-8"),
                    headers={"Content-Type": "application/json", "User-Agent": "Helix/0.1"},
                    method="POST",
                ),
                timeout=10,
            )
            token = json.loads(resp.read().decode("utf-8"))
            if token.get("access_token"):
                token["created_at"] = int(time.time())
                set_setting("trakt.token", json.dumps(token))
                succeeded = True
                break
        except urllib.error.HTTPError as he:
            if he.code == 400:
                continue  # pending
            if he.code == 410:
                notify("Helix", "Trakt code expired; try again.", "error", 5000)
                break
            continue
        except Exception as exc:
            log("trakt poll: %r" % exc, "warn")
            continue

    progress.close()
    if succeeded:
        notify("Helix", "Trakt authorized.", "info", 3000)
    elif progress.iscanceled():
        notify("Helix", "Trakt authorization cancelled.", "warn", 3000)
    else:
        notify("Helix", "Trakt authorization timed out.", "warn", 5000)
