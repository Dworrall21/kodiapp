# -*- coding: utf-8 -*-
"""
m3u: parse and group M3U playlists.

Reads M3U from URL or local file, groups streams by tvg-name / title,
attempts a coarse classification (movie / tv / anime) by keywords and
duration, and caches the result in the addon profile.

No scraping of pirate sites; the addon only consumes what the user
explicitly configures as their M3U source.
"""
import os
import re
import json
import time
import hashlib
import urllib.request
import urllib.error

from .utils import get_setting, cache_get, cache_set, cache_clear, log, notify, addon_profile_path, clean_title

CACHE_KEY = "m3u:source"
DEFAULT_TTL = 6 * 3600  # refresh setting in hours; fallback default

_GROUP_KEYWORDS_TV = ("tv", "series", "show", "episode", "season", " s0", " s1", " s2", " e0", " e1")
_GROUP_KEYWORDS_ANIME = ("anime", "アニメ", "[jp]", "japan")
_MOVIE_KEYWORDS = ("movie", "film", "(19", "(20")


def _is_anime_group(name):
    s = (name or "").lower()
    return any(k in s for k in _GROUP_KEYWORDS_ANIME)


def _is_tv_group(name):
    s = (name or "").lower()
    return any(k in s for k in _GROUP_KEYWORDS_TV) and not _is_anime_group(s)


def _is_movie_group(name):
    s = (name or "").lower()
    if _is_tv_group(s) or _is_anime_group(s):
        return False
    return True


def _fetch_url(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1 (Kodi addon)"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


def _read_local(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


def get_cached_source():
    """Return the parsed M3U dict, fetching + parsing on miss.

    Schema:
        {
          "fetched_at": <epoch>,
          "source": <url or path>,
          "items": [
              {
                "id": <short_id>,
                "title": <display title>,
                "kind": "movie" | "tv" | "anime" | "other",
                "streams": [ {"name":..., "url":..., "size": <MB int or 0>, "group": <group title>} ]
              }
          ]
        }
    """
    cached = cache_get(CACHE_KEY, ttl_seconds=DEFAULT_TTL)
    if cached:
        return cached

    return refresh()


def refresh(quiet=False, timeout=15):
    """Force a refresh of the M3U source (URL or local file).

    If ``quiet`` is True, suppress user-facing notifications on success/failure
    (intended for background service usage).
    """
    cache_clear()  # we use a single key, just nuke
    url = (get_setting("source.m3u.url") or "").strip()
    local = (get_setting("source.m3u.local") or "").strip()
    if not url and not local:
        if not quiet:
            notify("Helix", "No M3U source configured. Open Settings.", "warn", 5000)
        return None
    try:
        if url:
            text = _fetch_url(url, timeout=timeout)
            source_desc = url
        else:
            text = _read_local(local)
            source_desc = local
    except Exception as exc:
        log("m3u fetch failed: %r" % exc, "error")
        if not quiet:
            notify("Helix", "M3U fetch failed: %s" % exc, "error", 5000)
        return None

    parsed = parse_m3u(text)
    out = {
        "fetched_at": int(time.time()),
        "source": source_desc,
        "items": parsed,
    }
    cache_set(CACHE_KEY, out)
    log("m3u: parsed %d groups from %s" % (len(parsed), source_desc))
    return out


def clear_cache_and_refresh(quiet=False, timeout=15):
    return refresh(quiet=quiet, timeout=timeout)


# --- parsing ---
def parse_m3u(text):
    """Parse M3U text into a list of grouped items.

    M3U format:
        #EXTINF:-1 tvg-id="..." tvg-name="Movie (2023)" tvg-logo="..." group-title="Movies",Movie (2023)
        http://example.com/stream.mkv
    """
    if not text:
        return []
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    groups = {}  # group_title -> [stream]
    current = None
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("#EXTINF"):
            current = _parse_extinf(line)
            i += 1
            if i < len(lines) and not lines[i].startswith("#"):
                url = lines[i]
                g = (current.get("group-title") or "Default").strip() or "Default"
                current["url"] = url
                groups.setdefault(g, []).append(current)
                i += 1
            current = None
        else:
            i += 1

    items = []
    for gtitle, streams in groups.items():
        # Use the most common stream name as the title for the group
        if not streams:
            continue
        rep = streams[0]
        tvg_name = (rep.get("tvg-name") or rep.get("display") or gtitle).strip()
        # Collect all unique tvg-ids from this group's streams
        _tvg_ids = list(dict.fromkeys(
            s.get("tvg-id", "").strip() for s in streams if s.get("tvg-id", "").strip()
        )) if streams else []
        _tvg_id = _tvg_ids[0] if _tvg_ids else rep.get("tvg-id", "")
        kind = "anime" if _is_anime_group(gtitle) else "tv" if _is_tv_group(gtitle) else "movie" if _is_movie_group(gtitle) else "other"
        # year guess
        m = re.search(r"\b(19|20)\d{2}\b", tvg_name)
        year = int(m.group(0)) if m else 0
        items.append({
            "id": hashlib.sha1(gtitle.encode("utf-8")).hexdigest()[:12],
            "title": clean_title(tvg_name) or gtitle,
            "kind": kind,
            "group": gtitle,
            "year": year,
            "tvg_id": _tvg_id,
            "tvg_name": tvg_name,
            "poster": rep.get("tvg-logo") or "",
            "count": len(streams),
            "streams": [
                {
                    "name": s.get("display") or s.get("tvg-name") or "",
                    "tvg_id": s.get("tvg-id", ""),
                    "tvg_name": s.get("tvg-name", ""),
                    "url": s.get("url", ""),
                    "group": gtitle,
                    "size": _parse_size_mb(s.get("display", "")),
                }
                for s in streams
            ],
        })
    items.sort(key=lambda x: (x.get("title") or "").lower())
    return items


def _parse_extinf(line):
    """Parse an #EXTINF line into a dict of attributes + 'display' name."""
    out = {"display": "", "tvg-id": "", "tvg-name": "", "tvg-logo": "", "group-title": ""}
    # Drop the #EXTINF:<duration>
    body = re.sub(r"^#EXTINF:.*?,", "", line)
    out["display"] = body.strip()
    # attributes
    for attr in re.findall(r'([a-zA-Z\-]+)="([^"]*)"', line):
        key, val = attr
        key = key.lower()
        if key in out:
            out[key] = val
    return out


def _parse_size_mb(s):
    """Look for '1.2 GB' / '850 MB' / '500M' style markers; return int MB."""
    if not s:
        return 0
    m = re.search(r"(\d+(?:\.\d+)?)\s*(GB|MB|M)\b", s, re.IGNORECASE)
    if not m:
        return 0
    n = float(m.group(1))
    unit = m.group(2).lower()
    if unit.startswith("g"):
        return int(n * 1024)
    return int(n)


# --- filtering for menus ---
def get_filtered_items(kind="all"):
    src = get_cached_source()
    if not src:
        return []
    items = src.get("items", [])
    if kind == "all":
        return items
    if kind == "movie":
        return [i for i in items if i.get("kind") == "movie"]
    if kind == "tv":
        return [i for i in items if i.get("kind") == "tv"]
    if kind == "anime":
        return [i for i in items if i.get("kind") == "anime"]
    return items
