# -*- coding: utf-8 -*-
"""
epg: parse XMLTV guide data and provide now/next + grid overlays for Live TV.

Data flow:
    XMLTV URL → parse_xmltv() → cached dict → get_now_next(tvg_id) → menus

Cached schema:
    {
        "fetched_at": <epoch>,
        "source": <url>,
        "channels": { "channel.id": {"display_name": "...", "icon": "..."} },
        "programmes": { "channel.id": [ {p1}, {p2}, ... ] },
    }

Each programme dict:
    {
        "start": <epoch UTC>,
        "stop": <epoch UTC>,
        "title": "...",
        "sub_title": "...",
        "desc": "...",
        "category": "...",
        "episode": "...",
    }

This module uses only Python stdlib and the addon cache, so it works
inside Kodi and can be unit-tested in plain Python.
"""
import xml.etree.ElementTree as ET
import time
import re
from datetime import datetime, timezone, timedelta

from .utils import (
    get_setting, set_setting, cache_get, cache_set, cache_clear,
    log, notify,
)

CACHE_KEY = "epg:data"
DEFAULT_TTL = 3600  # 1 hour default refresh

# ── public helpers ──────────────────────────────────────────────────────────

def now_epoch():
    """Current UTC epoch (int)."""
    return int(time.time())


def parse_xmltv_datetime(s):
    """Parse XMLTV datetime (e.g. '20230101000000 +0000' or '20230101000000').

    Returns UTC epoch int, or 0 if unparseable.
    """
    if not s:
        return 0
    s = s.strip()
    # Try with timezone offset first: YYYYMMDDHHMMSS ±HHMM
    m = re.match(r"^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{2})(\d{2})$", s)
    if m:
        parts = [int(g) for g in m.groups()[:6]]
        tz_sign = 1 if m.group(7)[0] == "+" else -1
        tz_hours = int(m.group(7))
        tz_mins = int(m.group(8))
        try:
            dt = datetime(*parts, tzinfo=timezone.utc)
            offset = timedelta(hours=tz_hours, minutes=tz_mins)
            dt = dt - offset * tz_sign
            return int(dt.timestamp())
        except ValueError:
            return 0
    # Try without offset: YYYYMMDDHHMMSS (assume UTC)
    m = re.match(r"^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})", s)
    if m:
        parts = [int(g) for g in m.groups()]
        try:
            dt = datetime(*parts, tzinfo=timezone.utc)
            return int(dt.timestamp())
        except ValueError:
            return 0
    # Try ISO format
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int(dt.timestamp())
    except (ValueError, TypeError):
        pass
    return 0


def epoch_to_time_str(epoch, fmt="%H:%M"):
    """Format epoch as time string (default HH:MM in local time)."""
    if not epoch:
        return ""
    try:
        return datetime.fromtimestamp(epoch).strftime(fmt)
    except (ValueError, OSError):
        return ""


def epoch_to_date_str(epoch, fmt="%a %b %d"):
    """Format epoch as date string."""
    if not epoch:
        return ""
    try:
        return datetime.fromtimestamp(epoch).strftime(fmt)
    except (ValueError, OSError):
        return ""


# ── XMLTV parsing ───────────────────────────────────────────────────────────

def parse_xmltv(text):
    """Parse XMLTV XML text into {channels: {}, programmes: {}}.

    Channels is a dict keyed by channel id:
        { "channel.id": {"display_name": "...", "icon": "..."} }

    Programmes is a dict keyed by channel id, each a list of programme dicts
    sorted by start time:
        { "channel.id": [programme, ...] }
    """
    if not text:
        return {"channels": {}, "programmes": {}}

    try:
        root = ET.fromstring(text)
    except ET.ParseError as exc:
        log("epg: XMLTV parse error: %s" % exc, "error")
        return {"channels": {}, "programmes": {}}

    channels = {}
    for ch in root.findall("channel"):
        cid = ch.get("id", "")
        if not cid:
            continue
        dn_el = ch.find("display-name")
        icon_el = ch.find("icon")
        channels[cid] = {
            "display_name": (dn_el.text or "").strip() if dn_el is not None and dn_el.text else cid,
            "icon": icon_el.get("src", "") if icon_el is not None else "",
        }

    programmes = {}
    for prog in root.findall("programme"):
        ch_id = prog.get("channel", "")
        if not ch_id:
            continue
        start_epoch = parse_xmltv_datetime(prog.get("start", ""))
        stop_epoch = parse_xmltv_datetime(prog.get("stop", ""))
        title_el = prog.find("title")
        sub_title_el = prog.find("sub-title")
        desc_el = prog.find("desc")
        cat_el = prog.find("category")
        ep_el = prog.find("episode-num")

        p = {
            "start": start_epoch,
            "stop": stop_epoch,
            "title": (title_el.text or "").strip() if title_el is not None and title_el.text else "",
            "sub_title": (sub_title_el.text or "").strip() if sub_title_el is not None and sub_title_el.text else "",
            "desc": (desc_el.text or "").strip() if desc_el is not None and desc_el.text else "",
            "category": (cat_el.text or "").strip() if cat_el is not None and cat_el.text else "",
            "episode": (ep_el.text or "").strip() if ep_el is not None and ep_el.text else "",
        }
        programmes.setdefault(ch_id, []).append(p)

    # Sort each channel's programmes by start time
    for ch_id in programmes:
        programmes[ch_id].sort(key=lambda x: x["start"])

    return {"channels": channels, "programmes": programmes}


def _fetch_xmltv(url, timeout=30):
    """Fetch XMLTV content from URL."""
    import urllib.request
    req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.3 (Kodi addon)"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="replace")


# ── EPG data lifecycle ──────────────────────────────────────────────────────

def refresh(url=None, quiet=False):
    """Fetch XMLTV from URL, parse it, cache the result.

    If ``url`` is None, reads from setting ``epg.xmltv_url``.

    Returns the parsed data dict, or None on failure.
    """
    if url is None:
        url = (get_setting("epg.xmltv_url") or "").strip()
    if not url:
        if not quiet:
            notify("Helix", "No EPG URL configured. Open Settings.", "warn", 5000)
        log("epg: no XMLTV URL configured", "warn")
        return None

    try:
        text = _fetch_xmltv(url)
    except Exception as exc:
        log("epg: fetch failed: %r" % exc, "error")
        if not quiet:
            notify("Helix", "EPG fetch failed: %s" % exc, "error", 5000)
        return None

    parsed = parse_xmltv(text)
    out = {
        "fetched_at": now_epoch(),
        "source": url,
        "channels": parsed.get("channels", {}),
        "programmes": parsed.get("programmes", {}),
    }

    cache_clear()  # nuke the single-key cache so we always start fresh
    cache_set(CACHE_KEY, out)
    n_ch = len(out["channels"])
    n_pg = sum(len(v) for v in out["programmes"].values())
    log("epg: parsed %d channels, %d programmes from %s" % (n_ch, n_pg, url))
    if not quiet:
        notify("Helix", "EPG: %d channels, %d programmes" % (n_ch, n_pg), "info", 3000)
    return out


def get_data():
    """Return cached EPG data, auto-refreshing if stale or missing.

    TTL is read from setting epg.ttl (default 1 hour).
    """
    ttl = int(get_setting("epg.ttl", "3600"))
    cached = cache_get(CACHE_KEY, ttl_seconds=ttl)
    if cached:
        return cached

    url = (get_setting("epg.xmltv_url") or "").strip()
    if not url:
        return {"channels": {}, "programmes": {}, "fetched_at": 0, "source": ""}

    return refresh(url, quiet=True) or {"channels": {}, "programmes": {}, "fetched_at": 0, "source": ""}


def get_now_next(tvg_id):
    """Return the current and next programme for a channel.

    Args:
        tvg_id: The tvg-id from M3U #EXTINF (string).

    Returns:
        {"now": programme dict or None, "next": programme dict or None}
    """
    data = get_data()
    progs = data.get("programmes", {}).get(tvg_id, [])
    if not progs:
        return {"now": None, "next": None}

    now = now_epoch()
    current = None
    upcoming = None

    for p in progs:
        if p["start"] <= now < p["stop"]:
            current = p
        elif p["start"] > now and upcoming is None:
            upcoming = p

        if current and upcoming is not None:
            break

    return {"now": current, "next": upcoming}


def get_channel_info(tvg_id):
    """Get channel display info from EPG data."""
    data = get_data()
    return data.get("channels", {}).get(tvg_id, {})


def get_grid(hours_ahead=4, channel_ids=None):
    """Build a grid of upcoming programmes.

    Args:
        hours_ahead: How many hours from now to include.
        channel_ids: Optional list of tvg_ids to filter. None = all.

    Returns:
        {
            "from_epoch": <epoch>,
            "to_epoch": <epoch>,
            "channels": [
                {
                    "tvg_id": "...",
                    "display_name": "...",
                    "icon": "...",
                    "programmes": [p1, p2, ...],
                },
                ...
            ],
            "timeslots": [<epoch>, ...],  # hour boundaries for column headers
        }
    """
    data = get_data()
    now = now_epoch()
    until = now + hours_ahead * 3600
    channels_data = data.get("programmes", {})
    channel_info = data.get("channels", {})

    if channel_ids:
        ch_ids = [c for c in channel_ids if c in channels_data]
    else:
        ch_ids = list(channels_data.keys())

    out_channels = []
    for cid in sorted(ch_ids, key=lambda x: channel_info.get(x, {}).get("display_name", x).lower()):
        progs = [p for p in channels_data[cid] if p["start"] < until and p["stop"] > now]
        if progs:
            out_channels.append({
                "tvg_id": cid,
                "display_name": channel_info.get(cid, {}).get("display_name", cid),
                "icon": channel_info.get(cid, {}).get("icon", ""),
                "programmes": progs,
            })

    # Build timeslot boundaries (top-of-hour from now to until)
    timeslots = []
    ts = now - (now % 3600)  # round down to current hour
    while ts < until:
        timeslots.append(ts)
        ts += 3600

    return {
        "from_epoch": now,
        "to_epoch": until,
        "channels": out_channels,
        "timeslots": timeslots,
    }


def format_programme_label(p):
    """Render a single programme as a one-line menu label with time.

    Example: "19:30 | Movie Title (S01E02)"
    """
    if not p:
        return ""
    start = epoch_to_time_str(p.get("start", 0))
    label = p.get("title", "")
    if p.get("episode"):
        label += " (%s)" % p["episode"]
    return "%s | %s" % (start, label) if start else label


def get_now_next_label(tvg_id):
    """Return a short now/next string for channel listings.

    Returns e.g. "Now: News at Six | Next: Weather" or empty string.
    """
    nn = get_now_next(tvg_id)
    parts = []
    if nn["now"]:
        parts.append("Now: %s" % nn["now"]["title"])
    if nn["next"]:
        parts.append("Next: %s" % nn["next"]["title"])
    return " | ".join(parts) if parts else ""
