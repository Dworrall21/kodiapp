# -*- coding: utf-8 -*-
"""addonvar: shortcut accessors re-exported for compatibility with POV-style addons."""
from ..utils import (
    get_addon, get_setting, set_setting,
    get_int_setting, get_bool_setting,
    addon_info, addon_profile_path,
    log, notify, yesno, text_viewer, dialog_select, dialog_input,
    build_url, url_for, parse_query,
    make_item, add_item, resolve_item, play_url,
    set_content, add_sort_method, end_of_directory, set_handle,
    cache_get, cache_set, cache_clear,
)

ADDON = get_addon
ADDON_ID = "plugin.video.helix"


def setting(key, default=""):
    return get_setting(key, default)


def setting_set(key, value):
    return set_setting(key, value)
