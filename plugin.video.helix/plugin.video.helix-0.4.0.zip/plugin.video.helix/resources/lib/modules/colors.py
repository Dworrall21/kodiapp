# -*- coding: utf-8 -*-
"""colors: small helper for colorizing menu text (POV-style)."""
# Kodi color tags: [COLOR red]...[/COLOR], [B]...[/B], [I]...[/I]
def c(name, text):
    return "[COLOR %s]%s[/COLOR]" % (name, text)


def b(text):
    return "[B]%s[/B]" % text


def i(text):
    return "[I]%s[/I]" % text
