# -*- coding: utf-8 -*-
"""
debrid: skeleton client for debrid services.

Supported providers (in priority order set in settings):
    1. Real-Debrid
    2. AllDebrid
    3. Premiumize
    4. TorBox

`resolve(url)` picks the active provider (from settings) and tries
to unrestrict the link. If the provider has no key or the API call
fails, returns the original URL unchanged (Kodi will try the
direct link).

The methods exposed here are public and the same shape they would
take in a real client — easy to fill in production with the
provider's API documentation. This file deliberately implements
*just enough* to round-trip a few representative calls so the
addon's UI flow is testable end-to-end.
"""
import json
import socket
import time
import urllib.error
import urllib.request
import urllib.parse

from .utils import get_setting, get_int_setting, log, notify

import xbmc

# debrid.provider enum ->  (setting key, label, base_url)
PROVIDERS = {
    0: (None, "None", ""),
    1: ("debrid.real_debrid.key", "Real-Debrid", "https://api.real-debrid.com/rest/1.0"),
    2: ("debrid.all_debrid.key", "AllDebrid", "https://api.alldebrid.com/v4"),
    3: ("debrid.premiumize.key", "Premiumize", "https://premiumize.me/api"),
    4: ("debrid.torbox.key", "TorBox", "https://api.torbox.app/v1/api"),
}

# Errors that are worth retrying once after a short delay (transient network blips).
_RETRY_HTTP = (502, 503, 504, 429)


def active_provider():
    """Return (idx, setting_key, name, base_url) for the active provider."""
    try:
        idx = int(get_setting("debrid.provider", "0"))
    except Exception:
        idx = 0
    if idx not in PROVIDERS:
        idx = 0
    setting_key, name, base = PROVIDERS[idx]
    return idx, setting_key, name, base


def active_provider_name():
    return active_provider()[2]


def _api_key():
    _, setting_key, _, _ = active_provider()
    if not setting_key:
        return None
    return (get_setting(setting_key) or "").strip()


def _http_json(url, method="GET", headers=None, body=None, timeout=15, retries=1):
    """Issue an HTTP request, parse JSON, with light retry on transient errors.

    Returns dict on success, None on failure. Failures are logged.
    """
    headers = dict(headers or {})
    headers.setdefault("User-Agent", "Helix/0.1 (+https://example.local/helix)")
    headers.setdefault("Accept", "application/json")
    data = None
    if body is not None:
        if isinstance(body, (dict, list)):
            data = json.dumps(body).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        else:
            data = urllib.parse.urlencode(body).encode("utf-8")
            headers.setdefault("Content-Type", "application/x-www-form-urlencoded")
    attempt = 0
    last_exc = None
    while attempt <= retries:
        try:
            req = urllib.request.Request(url, data=data, method=method, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
                if not raw:
                    return None
                try:
                    return json.loads(raw)
                except ValueError:
                    return {"raw": raw}
        except urllib.error.HTTPError as exc:
            last_exc = exc
            if exc.code in _RETRY_HTTP and attempt < retries:
                log("debrid.http %s: %d (retrying)" % (url, exc.code), "warn")
                attempt += 1
                xbmc.sleep(500)
                continue
            log("debrid.http %s: %d %s" % (url, exc.code, exc.reason), "warn")
            return None
        except (urllib.error.URLError, socket.timeout, ConnectionError) as exc:
            last_exc = exc
            if attempt < retries:
                log("debrid.http %s: %r (retrying)" % (url, exc), "warn")
                attempt += 1
                xbmc.sleep(500)
                continue
            log("debrid.http %s: %r" % (url, exc), "warn")
            return None
    log("debrid.http %s: giving up: %r" % (url, last_exc), "warn")
    return None


def _detect_provider_from_url(url):
    """Pick a provider implementation based on URL scheme.

    Helix supports several input kinds:
      - direct http(s):// stream URL  (no debrid, return as-is)
      - debrid://<provider>/<id>       (custom scheme the addon
        recognizes from a debrid-style indexer)
      - magnet:?xt=urn:btih:<hash>     (torrent magnet, resolve via debrid)
    """
    if not url:
        return None, None
    if url.startswith("debrid://"):
        parts = url[len("debrid://"):].split("/", 1)
        return parts[0], parts[1] if len(parts) > 1 else None
    if url.startswith("magnet:") or url.startswith("magnet://"):
        # Route to the active debrid provider
        idx, _, name, _ = active_provider()
        if idx == 0:
            return None, url  # no provider active
        return name.lower().replace("-", "_"), url
    return "direct", url


def resolve(url):
    """Return an unrestricted stream URL, or the original URL on failure.

    Direct URLs: returned as-is.
    Debrid scheme: dispatched to the appropriate provider.
    """
    if not url:
        return url
    provider_name, payload = _detect_provider_from_url(url)
    if provider_name in (None, "direct"):
        return url
    if not _api_key():
        log("debrid.resolve: no API key for active provider", "warn")
        return url
    try:
        if provider_name == "real_debrid":
            return _resolve_real_debrid(payload)
        if provider_name == "all_debrid":
            return _resolve_all_debrid(payload)
        if provider_name == "premiumize":
            return _resolve_premiumize(payload)
        if provider_name == "torbox":
            return _resolve_torbox(payload)
    except Exception as exc:
        log("debrid.resolve failed: %r" % exc, "error")
    return url


# --- per-provider resolver skeletons (real shape) ---
def _resolve_real_debrid(link_or_id):
    """Real-Debrid: POST /unrestrict/link with `link` form field."""
    key = _api_key()
    if not key:
        return None
    # If payload is a magnet or link, the call shape is the same.
    body = {"link": link_or_id}
    data = _http_json(
        "https://api.real-debrid.com/rest/1.0/unrestrict/link",
        method="POST",
        headers={"Authorization": "Bearer " + key},
        body=body,
    )
    if not data:
        return None
    # RD returns 'download' (the unrestricted URL)
    return data.get("download") or (data.get("data") or {}).get("download")


def _resolve_all_debrid(link_or_id):
    """AllDebrid v4: POST /link/unlock with `link` form field."""
    key = _api_key()
    if not key:
        return None
    data = _http_json(
        "https://api.alldebrid.com/v4/link/unlock",
        method="POST",
        headers={"Authorization": "Bearer " + key},
        body={"link": link_or_id},
    )
    if not data:
        return None
    return (data.get("data") or {}).get("link")


def _resolve_premiumize(link_or_id):
    """Premiumize: POST /transfer/directdl with `src` form field."""
    key = _api_key()
    if not key:
        return None
    data = _http_json(
        "https://premiumize.me/api/transfer/directdl",
        method="POST",
        headers={"Authorization": "Bearer " + key},
        body={"src": link_or_id},
    )
    if not data:
        return None
    loc = (data.get("content") or [{}])[0].get("link") if isinstance(data.get("content"), list) else None
    return loc or data.get("location")


def _resolve_torbox(link_or_id):
    """TorBox: POST /api/usenet/create or /api/stream/create (we use stream)."""
    key = _api_key()
    if not key:
        return None
    data = _http_json(
        "https://api.torbox.app/v1/api/stream/create",
        method="POST",
        headers={"Authorization": "Bearer " + key},
        body={"link": link_or_id, "type": "torrent"},
    )
    if not data:
        return None
    return (data.get("data") or {}).get("stream_url") or (data.get("data") or {}).get("url")


def check_cache(info_hashes):
    """Check which info_hashes are cached on the active debrid provider.

    Args:
        info_hashes: list of torrent info_hash strings.

    Returns:
        dict mapping hash -> bool (True = cached, False = not cached).
        Returns empty dict if no active provider / bad config.
    """
    if not info_hashes:
        return {}
    provider_name = active_provider_name()
    if not provider_name or provider_name == "None":
        log("debrid.check_cache: no active provider", "warn")
        return {}
    key = _api_key()
    if not key:
        log("debrid.check_cache: no API key", "warn")
        return {}

    try:
        if provider_name == "Real-Debrid":
            return _check_cache_rd(info_hashes, key)
        if provider_name == "AllDebrid":
            return _check_cache_ad(info_hashes, key)
        if provider_name == "Premiumize":
            return _check_cache_pm(info_hashes, key)
        if provider_name == "TorBox":
            return _check_cache_tb(info_hashes, key)
    except Exception as exc:
        log("debrid.check_cache failed: %r" % exc, "error")
    return {h: False for h in info_hashes}


def _check_cache_rd(hashes, key):
    """Real-Debrid: GET /torrents/instantAvailability/{hash}.

    Returns dict like {hash: True/False}. RD returns a non-null body
    for cached torrents, or {} / 404 for uncached.
    """
    result = {}
    for h in hashes:
        h_lower = h.lower()
        data = _http_json(
            "https://api.real-debrid.com/rest/1.0/torrents/instantAvailability/" + h_lower,
            headers={"Authorization": "Bearer " + key},
        )
        # RD returns something like {h_lower: {"rd": [{"filename": ...}]}} when cached
        # or None / {"error": ...} when not cached.
        if data and isinstance(data, dict):
            result[h] = h_lower in data or bool(data.get(h_lower))
        else:
            result[h] = False
    return result


def _check_cache_ad(hashes, key):
    """AllDebrid: GET /v4/magnet/instant?magnets[]=hash&agent=helix&apikey=key"""
    url = "https://api.alldebrid.com/v4/magnet/instant"
    params = {"magnets[]": hashes, "agent": "helix", "apikey": key}
    qs = urllib.parse.urlencode(params, doseq=True)
    data = _http_json(url + "?" + qs)
    result = {}
    if data and isinstance(data, dict):
        magnets = (data.get("data") or {}).get("magnets") or []
        for m in magnets:
            h = (m.get("hash") or "").lower()
            if h:
                result[h] = bool(m.get("instant", False))
    # fill uncached
    for h in hashes:
        result.setdefault(h.lower(), False)
    return result


def _check_cache_pm(hashes, key):
    """Premiumize: POST /cache/check?items[]=hash&type=hash"""
    url = "https://premiumize.me/api/cache/check"
    params = {"items[]": hashes, "type": "hash", "apikey": key}
    qs = urllib.parse.urlencode(params, doseq=True)
    data = _http_json(url + "?" + qs)
    result = {}
    if data and isinstance(data, dict):
        responses = data.get("response") or []
        # Premiumize returns an array in the same order as items[]
        for idx, resp in enumerate(responses):
            if idx < len(hashes):
                # A filename means cached; None means not cached
                result[hashes[idx].lower()] = bool(resp and isinstance(resp, dict) and resp.get("filename"))
    for h in hashes:
        result.setdefault(h.lower(), False)
    return result


def _check_cache_tb(hashes, key):
    """TorBox: GET /api/torrents/checkcached?hash=hash1,hash2"""
    # TorBox accepts comma-separated hashes
    hash_str = ",".join(h.lower() for h in hashes)
    data = _http_json(
        "https://api.torbox.app/v1/api/torrents/checkcached?hash=" + hash_str,
        headers={"Authorization": "Bearer " + key},
    )
    result = {}
    if data and isinstance(data, dict):
        items = (data.get("data") or {}) if isinstance(data.get("data"), dict) else (data.get("data") or [])
        if isinstance(items, list):
            for item in items:
                h = (item.get("hash") or "").lower()
                if h:
                    result[h] = bool(item.get("cached", False))
        elif isinstance(items, dict):
            for h, info in items.items():
                h_lower = h.lower()
                if isinstance(info, dict):
                    result[h_lower] = bool(info.get("cached", False))
                else:
                    result[h_lower] = bool(info)
    for h in hashes:
        result.setdefault(h.lower(), False)
    return result


# --- account / status ---
def check_active():
    """Verify the active provider's key by calling a /user or /account endpoint."""
    _, _, name, base = active_provider()
    key = _api_key()
    if not name or not base or not key:
        return False, "No key for %s" % name
    try:
        if name == "Real-Debrid":
            data = _http_json(base + "/user", headers={"Authorization": "Bearer " + key})
            ok = bool(data and data.get("username"))
        elif name == "AllDebrid":
            data = _http_json(base + "/user", headers={"Authorization": "Bearer " + key})
            ok = bool(data and (data.get("data") or {}).get("user", {}).get("username"))
        elif name == "Premiumize":
            data = _http_json(base + "/account/info", headers={"Authorization": "Bearer " + key})
            ok = bool(data and (data.get("customer_id") or data.get("premium_until")))
        elif name == "TorBox":
            data = _http_json(base + "/user/me", headers={"Authorization": "Bearer " + key})
            ok = bool(data and (data.get("data") or {}).get("email"))
        else:
            return False, "Unknown provider"
        return ok, "OK" if ok else "Invalid response"
    except Exception as exc:
        return False, str(exc)


def test_active():
    ok, msg = check_active()
    if ok:
        notify("Helix", "%s: OK" % active_provider_name(), "info", 3000)
    else:
        notify("Helix", "%s: %s" % (active_provider_name(), msg), "error", 4000)
