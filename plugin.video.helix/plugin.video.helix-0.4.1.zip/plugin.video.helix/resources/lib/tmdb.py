# -*- coding: utf-8 -*-
"""
tmdb: thin TMDB v3 client.

Read-only calls: search, discover, image, details, external_ids.
Requires a TMDB v3 API key in settings: tmdb.api_key

If the key is missing or the network call fails, returns [] / None
without raising.
"""
import json
import urllib.request
import urllib.error
import urllib.parse

from .utils import get_setting, log, cache_get, cache_set

BASE = "https://api.themoviedb.org/3"
IMG = "https://image.tmdb.org/t/p"


def _get(path, params, ttl=1800):
    api_key = get_setting("tmdb.api_key")
    if not api_key:
        return None
    # Defensive: reject paths with unresolved format specifiers
    if "%s" in path or "%d" in path or "%r" in path:
        log("tmdb: rejecting malformed path with unresolved specifier: %r" % path, "error")
        return None
    params = dict(params or {})
    params["api_key"] = api_key
    params.setdefault("language", get_setting("tmdb.lang", "en-US"))
    region = get_setting("tmdb.region", "")
    if region and "region" not in params:
        params["region"] = region
    url = BASE + path + "?" + urllib.parse.urlencode(params)
    key = "tmdb:" + path + ":" + urllib.parse.urlencode(sorted(params.items()))
    cached = cache_get(key, ttl_seconds=ttl)
    if cached is not None:
        return cached
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Helix/0.1", "Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        cache_set(key, data)
        return data
    except Exception as exc:
        log("tmdb %s failed: %r" % (path, exc), "warn")
        return None


def image(path, size="w500"):
    if not path:
        return ""
    return IMG + "/" + size + path


def search(query, page=1):
    """Search TMDB for movies and TV (no person results)."""
    data = _get("/search/multi", {"query": query, "page": page, "include_adult": "false"})
    if not data:
        return []
    return [r for r in (data.get("results") or []) if r.get("media_type") in ("movie", "tv")]


def details(media_type, tmdb_id):
    """Fetch full metadata for a single TMDB entry.

    media_type: "movie" or "tv"
    tmdb_id: numeric TMDB ID

    Returns dict with keys: title, name, overview, release_date,
    first_air_date, vote_average, poster_path, etc.
    or None on failure.
    """
    path = "/%s/%s" % (media_type, tmdb_id)
    return _get(path, {}, ttl=86400)


def discover(kind, page=1):
    """kind in: trending_week, popular_day, top_rated, now_playing, upcoming,
    airing_today, on_the_air, trending_movies, popular_movies,
    top_rated_movies, trending_tv, popular_tv, top_rated_tv,
    trending_anime, popular_anime"""
    table = {
        # movie
        "trending_week": ("/trending/movie/week", {}),
        "popular_day": ("/movie/popular", {}),
        "top_rated": ("/movie/top_rated", {}),
        "now_playing": ("/movie/now_playing", {}),
        "upcoming": ("/movie/upcoming", {}),
        # tv
        "airing_today": ("/tv/airing_today", {}),
        "on_the_air": ("/tv/on_the_air", {}),
        # movie (explicit)
        "trending_movies": ("/trending/movie/week", {}),
        "popular_movies": ("/movie/popular", {}),
        "top_rated_movies": ("/movie/top_rated", {}),
        # tv
        "trending_tv": ("/trending/tv/week", {}),
        "popular_tv": ("/tv/popular", {}),
        "top_rated_tv": ("/tv/top_rated", {}),
        # anime (TMDB genre 16 = Animation)
        "trending_anime": ("/discover/tv", {"with_genres": "16", "sort_by": "popularity.desc"}),
        "popular_anime": ("/discover/tv", {"with_genres": "16", "sort_by": "vote_count.desc"}),
    }
    if kind not in table:
        return []
    path, params = table[kind]
    params = dict(params)
    params["page"] = page
    data = _get(path, params)
    if not data:
        return []
    return data.get("results") or []


def get_imdb_id(tmdb_id, media_type="movie"):
    """Look up the IMDB ID for a TMDB movie or TV show.

    Args:
        tmdb_id: int or str TMDB ID (e.g. 27205 for Inception).
        media_type: "movie" or "tv".

    Returns:
        IMDB ID string (e.g. "tt1375666") or None if not found.
    """
    if not tmdb_id:
        return None


def trending(media_type="movie", time_window="week"):
    """Convenience: trending movies or TV from TMDB."""
    kind = "trending_%s" % media_type if media_type == "movie" else "trending_tv"
    return discover(kind)


def popular(media_type="movie"):
    """Convenience: popular movies or TV from TMDB."""
    kind = "popular_%s" % media_type if media_type == "movie" else "popular_tv"
    return discover(kind)


_GENRE_CACHE = {}


def genres(media_type="movie"):
    """Return list of {id, name} for movie or TV genres."""
    if media_type not in _GENRE_CACHE:
        data = _get("/genre/%s/list" % media_type, {})
        _GENRE_CACHE[media_type] = (data or {}).get("genres") or []
    return _GENRE_CACHE[media_type]


def discover_by_genre(media_type="movie", genre_id="", page=1):
    """Discover titles by TMDB genre ID."""
    if not genre_id:
        return []
    data = _get("/discover/%s" % media_type, {"with_genres": str(genre_id), "page": page, "sort_by": "popularity.desc"})
    return (data or {}).get("results") or []


def get_external_ids(media_type, tmdb_id):
    """Get IMDb / TVDB / TMDB external IDs for a title.

    media_type: "movie" or "tv"
    tmdb_id: numeric TMDB ID

    Returns dict like {"imdb_id": "tt...", "tvdb_id": 123, "tvrage_id": ...}
    or empty dict on failure.
    """
    path = "/%s/%s/external_ids" % (media_type, tmdb_id)
    data = _get(path, {}, ttl=86400)
    if not data:
        return {}
    return {k: v for k, v in data.items() if k.endswith("_id") and v}


def test_key():
    data = _get("/configuration", {}, ttl=86400)
    if data and "images" in data:
        from .utils import notify
        notify("Helix", "TMDB key OK.", "info", 3000)
        return True
    from .utils import notify
    notify("Helix", "TMDB key missing or invalid.", "error", 4000)
    return False
