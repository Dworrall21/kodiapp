# -*- coding: utf-8 -*-
"""
tb_cloud: TorBox cloud scraper — query user's TorBox library for cached content.

Bypasses indexers entirely by searching the user's existing TorBox torrent
library. When a match is found, returns direct playable links via requestdl.

Follows POV Fork's tb_cloud pattern:
  1. GET /torrents/mylist — list all torrents in user's cloud
  2. Filter by title, year, season, episode against torrent name + file names
  3. Return matching files as stream dicts with cached=True + direct link

Caller: debrid_search.search_by_tmdb() calls this BEFORE indexers.
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.request

from . import debrid
from .utils import log

# Video file extensions to filter for
_VIDEO_EXTS = (".mp4", ".mkv", ".avi", ".mov", ".m4v", ".webm", ".mpeg", ".ts")


def _api_key() -> str | None:
    """Get TorBox API key if TorBox is the active provider."""
    name = debrid.active_provider_name()
    if name != "TorBox":
        return None
    return debrid._api_key()


def _get_json(url: str, key: str) -> dict | list | None:
    """Simple GET with Bearer auth, returns parsed JSON."""
    try:
        req = urllib.request.Request(
            url, headers={"Authorization": "Bearer " + key}
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except (urllib.error.HTTPError, urllib.error.URLError, OSError, json.JSONDecodeError) as exc:
        log("tb_cloud: %s %s" % (url, exc), "warn")
        return None


def _normalize_title(title: str) -> str:
    """Lowercase, strip punctuation, collapse whitespace."""
    t = title.lower().strip()
    t = re.sub(r"[^\w\s]", "", t)
    t = re.sub(r"\s+", " ", t)
    return t


def _year_match(torrent_name: str, year: int | None) -> bool:
    """Check if a 4-digit year in torrent_name matches target year ±1."""
    if not year:
        return True
    found = re.findall(r"\b(19\d{2}|20\d{2})\b", torrent_name)
    if not found:
        return True  # no year in name = can't rule out
    target_range = set(str(y) for y in range(year - 1, year + 2))
    return any(y in target_range for y in found)


def _seas_ep_match(filename: str, season: int | None, episode: int | None) -> bool:
    """Check if filename contains matching SxxExx pattern."""
    if season is None or episode is None:
        return True  # movie or no coordinates
    # Match S01E02, S1E2, 1x02, season 1 episode 2 patterns
    patterns = [
        r"\bS(\d+)[Ee](\d+)\b",
        r"\bs(\d+)[Ee](\d+)\b",
        r"\b(\d+)x(\d+)\b",
        r"\bSeason[.\s](\d+)[.\s]Episode[.\s](\d+)\b",
    ]
    for pat in patterns:
        m = re.search(pat, filename)
        if m:
            s, e = int(m.group(1)), int(m.group(2))
            if s == season and e == episode:
                return True
    return False


def search(
    title: str,
    year: int | None = None,
    season: int | None = None,
    episode: int | None = None,
) -> list[dict]:
    """Search TorBox user library for matching cached content.

    Args:
        title: Show/movie title to match against.
        year: Release year (for year filtering).
        season, episode: TV episode coordinates.

    Returns:
        List of stream dicts (same format as indexers return):
            {name, source, size_mb, cached=True, infoHash, url, _quality}
        url is a direct download link from requestdl.
        Empty list if no matches or TorBox not active.
    """
    key = _api_key()
    if not key:
        log("tb_cloud: TorBox not active", "debug")
        return []

    log("tb_cloud: searching TorBox library for \"%s\"..." % title)

    # Step 1: Get all torrents from user's cloud
    data = _get_json(
        "https://api.torbox.app/v1/api/torrents/mylist", key
    )
    if not data:
        log("tb_cloud: mylist returned no data", "warn")
        return []

    torrents = data.get("data") if isinstance(data, dict) else data
    if not isinstance(torrents, list):
        torrents = [torrents] if isinstance(torrents, dict) else []

    if not torrents:
        log("tb_cloud: no torrents in library", "debug")
        return []

    log("tb_cloud: scanning %d torrents..." % len(torrents))

    # Step 2: Filter torrents that might match
    needle = _normalize_title(title)
    matches: list[dict] = []

    for tor in torrents:
        # Only completed torrents with files
        if not tor.get("download_finished", False):
            continue
        files = tor.get("files") or []
        if not files:
            continue

        tor_name = _normalize_title(tor.get("name") or "")
        # Quick title check against torrent name
        tor_words = set(tor_name.split())
        needle_words = set(needle.split())
        # Require at least some word overlap
        if not needle_words & tor_words:
            continue

        # Year check
        if not _year_match(tor_name, year):
            continue

        torrent_id = tor.get("id")
        if not torrent_id:
            continue

        # Step 3: Check individual files
        for f in files:
            fname = (f.get("short_name") or f.get("name") or "").lower()
            if not fname.endswith(_VIDEO_EXTS):
                continue

            # Episode filter
            if not _seas_ep_match(fname, season, episode):
                continue

            file_id = f.get("id")
            if not file_id:
                continue

            size_mb = int(f.get("size") or 0)  # TorBox returns bytes
            if size_mb > 0:
                size_mb = size_mb // (1024 * 1024)

            # Build a stream entry
            quality = _guess_quality(fname)
            file_key = "%s,%s" % (torrent_id, file_id)

            matches.append({
                "name": f.get("short_name") or f.get("name", ""),
                "source": "tb_cloud",
                "size_mb": size_mb,
                "cached": True,
                "infoHash": (tor.get("hash") or "").lower(),
                "url": file_key,  # torrent_id,file_id for _resolve_torbox
                "_quality": quality,
            })

    log("tb_cloud: found %d matching files in TorBox library" % len(matches))
    return matches


def _guess_quality(filename: str) -> str:
    """Guess quality tier from filename."""
    name = filename.lower()
    if any(x in name for x in ("2160", "4k", "uhd", "ultrahd")):
        return "2160p"
    if any(x in name for x in ("1080", "fhd")):
        return "1080p"
    if "720" in name:
        return "720p"
    if "480" in name:
        return "480p"
    return "unknown"
