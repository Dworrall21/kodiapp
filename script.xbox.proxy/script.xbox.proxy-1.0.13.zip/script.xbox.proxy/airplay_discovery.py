# -*- coding: utf-8 -*-
"""Small stdlib-only mDNS browser for AirPlay/RAOP services.

Kodi add-ons cannot rely on third-party packages being installed, especially on
Xbox. This module sends one-shot multicast DNS PTR queries for AirPlay service
families and parses common PTR/SRV/TXT/A/AAAA records from responses.
"""
from __future__ import unicode_literals

import random
import socket
import struct
import time

MDNS_ADDR = "224.0.0.251"
MDNS_PORT = 5353
AIRPLAY_SERVICE_TYPES = ("_airplay._tcp.local", "_raop._tcp.local")
TYPE_A = 1
TYPE_PTR = 12
TYPE_TXT = 16
TYPE_AAAA = 28
TYPE_SRV = 33
CLASS_IN = 1


class MdnsParseError(Exception):
    pass


def _ensure_dot(name):
    return name.rstrip(".") + "."


def _strip_dot(name):
    return name[:-1] if name.endswith(".") else name


def encode_name(name):
    parts = _strip_dot(name).split(".") if name else []
    out = bytearray()
    for part in parts:
        data = part.encode("utf-8")
        if len(data) > 63:
            raise ValueError("DNS label too long: %s" % part)
        out.append(len(data))
        out.extend(data)
    out.append(0)
    return bytes(out)


def read_name(packet, offset):
    labels = []
    jumped = False
    end = offset
    seen = set()
    while True:
        if offset >= len(packet):
            raise MdnsParseError("name offset outside packet")
        length = packet[offset]
        if length == 0:
            offset += 1
            if not jumped:
                end = offset
            break
        if length & 0xC0 == 0xC0:
            if offset + 1 >= len(packet):
                raise MdnsParseError("truncated compression pointer")
            pointer = ((length & 0x3F) << 8) | packet[offset + 1]
            if pointer in seen:
                raise MdnsParseError("compression pointer loop")
            seen.add(pointer)
            offset = pointer
            if not jumped:
                end = end + 2
                jumped = True
            continue
        if length & 0xC0:
            raise MdnsParseError("unsupported DNS label type")
        offset += 1
        label = packet[offset:offset + length]
        if len(label) != length:
            raise MdnsParseError("truncated DNS label")
        labels.append(label.decode("utf-8", errors="replace"))
        offset += length
        if not jumped:
            end = offset
    return _ensure_dot(".".join(labels)), end


def build_ptr_query(service_types=AIRPLAY_SERVICE_TYPES):
    txid = random.randint(0, 0xFFFF)
    header = struct.pack("!HHHHHH", txid, 0, len(service_types), 0, 0, 0)
    questions = []
    for service_type in service_types:
        questions.append(encode_name(service_type) + struct.pack("!HH", TYPE_PTR, CLASS_IN))
    return header + b"".join(questions)


def _parse_txt(rdata):
    values = {}
    raw = []
    offset = 0
    while offset < len(rdata):
        ln = rdata[offset]
        offset += 1
        item = rdata[offset:offset + ln].decode("utf-8", errors="replace")
        offset += ln
        raw.append(item)
        if "=" in item:
            key, value = item.split("=", 1)
            values[key] = value
        elif item:
            values[item] = True
    return values, raw


def parse_response(packet):
    if len(packet) < 12:
        raise MdnsParseError("packet too small")
    _txid, _flags, qd, an, ns, ar = struct.unpack("!HHHHHH", packet[:12])
    offset = 12
    for _ in range(qd):
        _name, offset = read_name(packet, offset)
        offset += 4
        if offset > len(packet):
            raise MdnsParseError("truncated question")

    ptrs = []
    srv = {}
    txt = {}
    addresses = {}
    records = an + ns + ar
    for _ in range(records):
        name, offset = read_name(packet, offset)
        if offset + 10 > len(packet):
            raise MdnsParseError("truncated record header")
        rtype, rclass, ttl, rdlen = struct.unpack("!HHIH", packet[offset:offset + 10])
        offset += 10
        rdata_offset = offset
        rdata = packet[offset:offset + rdlen]
        if len(rdata) != rdlen:
            raise MdnsParseError("truncated rdata")
        offset += rdlen
        if rtype == TYPE_PTR:
            target, _ = read_name(packet, rdata_offset)
            ptrs.append({"service_type": _strip_dot(name), "name": _strip_dot(target), "ttl": ttl})
        elif rtype == TYPE_SRV:
            if rdlen < 6:
                continue
            priority, weight, port = struct.unpack("!HHH", rdata[:6])
            target, _ = read_name(packet, rdata_offset + 6)
            srv[_strip_dot(name)] = {
                "target": _strip_dot(target),
                "port": port,
                "priority": priority,
                "weight": weight,
                "ttl": ttl,
            }
        elif rtype == TYPE_TXT:
            values, raw = _parse_txt(rdata)
            txt[_strip_dot(name)] = {"values": values, "raw": raw, "ttl": ttl}
        elif rtype == TYPE_A and rdlen == 4:
            addresses.setdefault(_strip_dot(name), []).append(socket.inet_ntop(socket.AF_INET, rdata))
        elif rtype == TYPE_AAAA and rdlen == 16:
            addresses.setdefault(_strip_dot(name), []).append(socket.inet_ntop(socket.AF_INET6, rdata))

    devices = []
    for ptr in ptrs:
        name = ptr["name"]
        service = srv.get(name, {})
        target = service.get("target")
        devices.append({
            "name": name,
            "service_type": ptr["service_type"],
            "host": target,
            "port": service.get("port"),
            "addresses": addresses.get(target, []) if target else [],
            "txt": txt.get(name, {}).get("values", {}),
            "txt_raw": txt.get(name, {}).get("raw", []),
            "ttl": min([v for v in [ptr.get("ttl"), service.get("ttl"), txt.get(name, {}).get("ttl")] if v is not None] or [0]),
        })
    return devices


def dedupe_devices(devices):
    merged = {}
    for device in devices:
        key = (device.get("name"), device.get("service_type"))
        current = merged.setdefault(key, dict(device))
        addresses = list(current.get("addresses") or [])
        for address in device.get("addresses") or []:
            if address not in addresses:
                addresses.append(address)
        current["addresses"] = addresses
        if not current.get("host") and device.get("host"):
            current["host"] = device.get("host")
        if not current.get("port") and device.get("port"):
            current["port"] = device.get("port")
        current.setdefault("txt", {}).update(device.get("txt") or {})
        raw = current.setdefault("txt_raw", [])
        for item in device.get("txt_raw") or []:
            if item not in raw:
                raw.append(item)
    return sorted(merged.values(), key=lambda d: (d.get("service_type") or "", d.get("name") or ""))


def discover_airplay(timeout=2.0, service_types=AIRPLAY_SERVICE_TYPES):
    deadline = time.time() + max(0.2, float(timeout or 2.0))
    devices = []
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    try:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 1)
        except Exception:
            pass
        sock.settimeout(0.25)
        query = build_ptr_query(service_types)
        sock.sendto(query, (MDNS_ADDR, MDNS_PORT))
        while time.time() < deadline:
            try:
                packet, _addr = sock.recvfrom(9000)
            except socket.timeout:
                continue
            try:
                devices.extend(parse_response(packet))
            except Exception:
                continue
    finally:
        try:
            sock.close()
        except Exception:
            pass
    return dedupe_devices(devices)
