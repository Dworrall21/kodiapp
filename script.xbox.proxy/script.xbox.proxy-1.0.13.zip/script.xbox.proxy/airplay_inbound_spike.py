# -*- coding: utf-8 -*-
"""Tiny inbound HTTP listener spike for Xbox Kodi add-on LAN testing.

This is deliberately minimal and stdlib-only. Its purpose is to prove whether a
Kodi Python service add-on on Xbox Retail Mode can bind a LAN TCP port and accept
connections. It is not a full AirPlay receiver.
"""
from __future__ import unicode_literals

import json
import socket
import threading
import time
import traceback


class InboundSpikeServer(object):
    def __init__(self, host="0.0.0.0", port=7100, name="Kodi Xbox", logger=None):
        self.host = host or "0.0.0.0"
        self.port = int(port or 7100)
        self.name = name or "Kodi Xbox"
        self.logger = logger or (lambda message: None)
        self._sock = None
        self._thread = None
        self._stop = threading.Event()
        self.started_at = None
        self.last_error = None
        self.last_request = None
        self.request_count = 0
        self.bound = False

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._serve)
        self._thread.daemon = True
        self._thread.start()

    def stop(self):
        self._stop.set()
        try:
            if self._sock:
                self._sock.close()
        except Exception:
            pass
        self._sock = None
        self.bound = False

    def is_alive(self):
        return bool(self._thread and self._thread.is_alive())

    def status(self):
        return {
            "enabled": True,
            "bound": bool(self.bound),
            "host": self.host,
            "port": self.port,
            "name": self.name,
            "started_at": self.started_at,
            "request_count": self.request_count,
            "last_request": self.last_request,
            "last_error": self.last_error,
            "thread_alive": self.is_alive(),
        }

    def _log(self, message):
        try:
            self.logger("Inbound AirPlay spike: %s" % message)
        except Exception:
            pass

    def _serve(self):
        self.started_at = int(time.time())
        self.last_error = None
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock = sock
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((self.host, self.port))
            sock.listen(8)
            sock.settimeout(1.0)
            self.bound = True
            self._log("listening on %s:%s" % (self.host, self.port))
            while not self._stop.is_set():
                try:
                    client, addr = sock.accept()
                except Exception as exc:
                    if self._stop.is_set() or _is_timeout(exc):
                        continue
                    raise
                thread = threading.Thread(target=self._handle_client, args=(client, addr))
                thread.daemon = True
                thread.start()
        except Exception as exc:
            self.bound = False
            self.last_error = "%s: %s" % (exc.__class__.__name__, exc)
            self._log("server error: %s\n%s" % (self.last_error, traceback.format_exc()))
        finally:
            self.bound = False
            try:
                sock.close()
            except Exception:
                pass

    def _handle_client(self, client, addr):
        try:
            client.settimeout(3.0)
            data = _recv_http_head(client)
            request_line = data.split(b"\r\n", 1)[0].decode("iso-8859-1", "replace") if data else ""
            parts = request_line.split()
            method = parts[0] if len(parts) >= 1 else ""
            path = parts[1] if len(parts) >= 2 else "/"
            self.request_count += 1
            self.last_request = {
                "time": int(time.time()),
                "remote": "%s:%s" % (addr[0], addr[1]),
                "request_line": request_line,
                "method": method,
                "path": path,
            }
            self._log("%s %s from %s:%s" % (method or "?", path, addr[0], addr[1]))
            if path in ("/status", "/server-info", "/info", "/"):
                body = json.dumps({
                    "status": "ok",
                    "receiver": self.name,
                    "message": "Inbound listener reached Kodi add-on",
                    "time": int(time.time()),
                    "path": path,
                    "request_count": self.request_count,
                }, separators=(",", ":")).encode("utf-8")
                _send_response(client, 200, "OK", body, "application/json")
            else:
                _send_response(client, 404, "Not Found", b"not found\n", "text/plain; charset=utf-8")
        except Exception as exc:
            self.last_error = "%s: %s" % (exc.__class__.__name__, exc)
            self._log("client error: %s" % self.last_error)
            try:
                _send_response(client, 500, "Internal Server Error", b"error\n", "text/plain; charset=utf-8")
            except Exception:
                pass
        finally:
            try:
                client.close()
            except Exception:
                pass


def disabled_status():
    return {
        "enabled": False,
        "bound": False,
        "host": None,
        "port": None,
        "name": None,
        "started_at": None,
        "request_count": 0,
        "last_request": None,
        "last_error": None,
        "thread_alive": False,
    }


def _recv_http_head(client):
    data = b""
    while b"\r\n\r\n" not in data and len(data) < 65536:
        chunk = client.recv(4096)
        if not chunk:
            break
        data += chunk
    return data


def _send_response(client, status, reason, body, content_type):
    body = body or b""
    headers = [
        "HTTP/1.1 %s %s" % (status, reason),
        "Content-Type: %s" % content_type,
        "Content-Length: %s" % len(body),
        "Connection: close",
        "Cache-Control: no-store",
        "Access-Control-Allow-Origin: *",
        "",
        "",
    ]
    client.sendall("\r\n".join(headers).encode("ascii") + body)


def _is_timeout(exc):
    return isinstance(exc, socket.timeout) or "timed out" in str(exc).lower()
