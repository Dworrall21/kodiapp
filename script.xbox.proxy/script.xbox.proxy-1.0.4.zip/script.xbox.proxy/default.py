# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import base64, hashlib, json, os, random, socket, ssl, struct, sys, time, traceback, urllib.request, zlib
import xbmc, xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_VERSION = ADDON.getAddonInfo("version")
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_FRAME = 4 * 1024 * 1024
TEXT_TYPES = ("text/", "application/json", "application/javascript", "application/xml", "application/xhtml+xml", "image/svg+xml")
ALLOWED_METHODS = {"GET", "POST", "HEAD", "OPTIONS"}

def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[%s] %s" % (ADDON_ID, msg), level)

def setting(name, default=""):
    value = ADDON.getSetting(name)
    return value if value not in ("", None) else default

def int_setting(name, default):
    try: return int(setting(name, str(default)))
    except Exception: return default

def cfg():
    return {
        "host": setting("bridge_host", "127.0.0.1"),
        "port": int_setting("bridge_port", 8765),
        "path": setting("bridge_path", "/"),
        "token": setting("auth_token", ""),
        "tls": setting("use_tls", "false").lower() == "true",
        "kodi_host": setting("kodi_host", "127.0.0.1"),
        "kodi_port": int_setting("kodi_port", 8080),
    }

class WS:
    def __init__(self, c):
        self.c = c
        self.s = None

    def connect(self):
        s = socket.create_connection((self.c["host"], self.c["port"]), timeout=15)
        if self.c["tls"]:
            s = ssl.wrap_socket(s)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        path = self.c["path"] if self.c["path"].startswith("/") else "/" + self.c["path"]
        headers = [
            "GET %s HTTP/1.1" % path,
            "Host: %s:%s" % (self.c["host"], self.c["port"]),
            "Upgrade: websocket", "Connection: Upgrade",
            "Sec-WebSocket-Key: %s" % key,
            "Sec-WebSocket-Version: 13",
            "X-Kodi-Proxy-Protocol: 2",
            "X-Kodi-Proxy-Addon: %s/%s" % (ADDON_ID, ADDON_VERSION),
        ]
        if self.c["token"]:
            headers.append("Authorization: Bearer %s" % self.c["token"])
        s.sendall(("\r\n".join(headers) + "\r\n\r\n").encode("ascii"))
        data = b""
        while b"\r\n\r\n" not in data:
            data += s.recv(4096)
            if len(data) > 65536: raise RuntimeError("handshake too large")
        text = data.decode("iso-8859-1", "replace")
        if " 101 " not in text.split("\r\n", 1)[0]: raise RuntimeError("upgrade failed: " + text[:80])
        expect = base64.b64encode(hashlib.sha1((key + GUID).encode("ascii")).digest()).decode("ascii")
        if expect.lower() not in text.lower(): raise RuntimeError("bad websocket accept")
        s.settimeout(1)
        self.s = s

    def recv_exact(self, n):
        out = b""
        while len(out) < n:
            part = self.s.recv(n - len(out))
            if not part: raise RuntimeError("socket closed")
            out += part
        return out

    def recv(self):
        b1, b2 = struct.unpack("!BB", self.recv_exact(2))
        op, masked, ln = b1 & 15, b2 & 128, b2 & 127
        if ln == 126: ln = struct.unpack("!H", self.recv_exact(2))[0]
        elif ln == 127: ln = struct.unpack("!Q", self.recv_exact(8))[0]
        if ln > MAX_FRAME: raise RuntimeError("frame too large")
        mask = self.recv_exact(4) if masked else None
        payload = self.recv_exact(ln) if ln else b""
        if masked: payload = bytes(x ^ mask[i % 4] for i, x in enumerate(payload))
        if op == 8: raise RuntimeError("closed")
        if op == 9:
            self.frame(payload, 10); return None
        if op == 1: return payload.decode("utf-8", "replace")
        if op == 2:
            if payload[:1] == b"\x01": payload = zlib.decompress(payload[1:])
            elif payload[:1] == b"\x00": payload = payload[1:]
            return payload.decode("utf-8", "replace")
        return None

    def send(self, obj):
        data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
        self.frame(data, 1)

    def frame(self, payload, op):
        key = os.urandom(4)
        ln = len(payload)
        if ln < 126: head = struct.pack("!BB", 128 | op, 128 | ln)
        elif ln < 65536: head = struct.pack("!BBH", 128 | op, 254, ln)
        else: head = struct.pack("!BBQ", 128 | op, 255, ln)
        masked = bytes(x ^ key[i % 4] for i, x in enumerate(payload))
        self.s.sendall(head + key + masked)

    def close(self):
        try: self.s.close()
        except Exception: pass

def encode_body(body, headers):
    ct = ""
    for k, v in headers.items():
        if k.lower() == "content-type": ct = v.lower()
    if any(ct.startswith(t) for t in TEXT_TYPES):
        return {"body_encoding":"utf-8","body":body.decode("utf-8","replace")}
    return {"body_encoding":"base64","body":base64.b64encode(body).decode("ascii")}

def http_request(ws, c, m):
    rid = m.get("id", "unknown")
    method = str(m.get("method", "GET")).upper()
    path = m.get("path", "/")
    if method not in ALLOWED_METHODS or not isinstance(path, str) or not path.startswith("/") or "\r" in path or "\n" in path:
        ws.send({"type":"response","id":rid,"status":400,"error":"invalid request"}); return
    url = "http://%s:%s%s" % (c["kodi_host"], c["kodi_port"], path)
    try:
        req = urllib.request.Request(url, method=method)
        with urllib.request.urlopen(req, timeout=15) as r:
            headers = dict(r.headers.items())
            out = {"type":"response","id":rid,"status":getattr(r,"status",r.getcode()),"headers":headers}
            out.update(encode_body(r.read(MAX_FRAME), headers))
            ws.send(out)
    except Exception as e:
        ws.send({"type":"response","id":rid,"status":500,"error":str(e)})

def rpc(ws, m):
    rid = m.get("id", "unknown")
    try:
        raw = xbmc.executeJSONRPC(json.dumps({"jsonrpc":"2.0","method":m["method"],"params":m.get("params",{}),"id":rid}))
        try: body = json.loads(raw)
        except Exception: body = raw
        ws.send({"type":"command_result","id":rid,"status":200,"body":body})
    except Exception as e:
        ws.send({"type":"command_result","id":rid,"status":500,"error":str(e)})

def run():
    mon = xbmc.Monitor()
    while not mon.abortRequested():
        c = cfg()
        if not c["token"]:
            log("No auth token configured; not connecting.", xbmc.LOGERROR)
            mon.waitForAbort(30); continue
        ws = WS(c)
        try:
            ws.connect()
            ws.send({"type":"connected","info":{"addon_id":ADDON_ID,"addon_version":ADDON_VERSION,"protocol_version":2,"build":xbmc.getInfoLabel("System.BuildVersion"),"python":sys.version}})
            while not mon.abortRequested():
                try: msg = ws.recv()
                except socket.timeout: continue
                if not msg: continue
                m = json.loads(msg)
                if m.get("type") in ("request","http_request"): http_request(ws, c, m)
                elif m.get("type") in ("command","kodi_command","jsonrpc"): rpc(ws, m)
                elif m.get("type") == "ping": ws.send({"type":"pong","id":m.get("id"),"time":int(time.time())})
        except Exception as e:
            log("Bridge error: %s\n%s" % (e, traceback.format_exc()), xbmc.LOGERROR)
        finally:
            ws.close()
        mon.waitForAbort(10 + random.randint(0, 5))

if __name__ == "__main__":
    run()
