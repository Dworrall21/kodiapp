# -*- coding: utf-8 -*-
"""Robust Xbox Web Proxy service for Kodi.

Protocol v2:
- Client opens an outbound WebSocket to the bridge.
- Text frames are plain JSON.
- Binary frames use a one-byte envelope: 0x00 raw JSON bytes, 0x01 zlib JSON bytes.
- HTTP bodies are returned as utf-8 text or base64 binary using body_encoding.

iPhone Remote Bridge (Option B2):
- Optional custom iPhone remote app mode.
- The iPhone app listens on the LAN while foregrounded.
- This add-on connects outbound to the iPhone app and receives JSON-line commands.
- This is not official Kore compatibility and does not require inbound Xbox LAN access.
"""
from __future__ import unicode_literals

import base64
import collections
import hashlib
import json
import os
import random
import socket
import ssl
import struct
import sys
import threading
import time
import traceback
import urllib.request
import zipfile
import zlib

import xbmc
import xbmcaddon
import xbmcvfs

try:
    from iphone_bridge import (
        BridgeProtocolError,
        encode_json_line,
        extract_json_lines,
        is_timeout_error,
        make_auth_message,
        make_error_message,
        make_hello_message,
        make_result_message,
    )
except Exception:
    from addon.iphone_bridge import (
        BridgeProtocolError,
        encode_json_line,
        extract_json_lines,
        is_timeout_error,
        make_auth_message,
        make_error_message,
        make_hello_message,
        make_result_message,
    )

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_VERSION = ADDON.getAddonInfo("version")
ADDON_NAME = ADDON.getAddonInfo("name") or ADDON_ID
GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
PROTOCOL_VERSION = 2
MAX_FRAME_BYTES = 4 * 1024 * 1024
MAX_REQUEST_BODY_BYTES = 4 * 1024 * 1024
MAX_LOG_LINES = 1000
TEXT_TYPES = ("text/", "application/json", "application/javascript", "application/xml", "application/xhtml+xml", "image/svg+xml")
ALLOWED_METHODS = {"GET", "POST", "HEAD", "OPTIONS"}
HOP_HEADERS = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade"}


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def setting(name, default=""):
    try:
        value = ADDON.getSetting(name)
        return value if value not in (None, "") else default
    except Exception:
        return default


def int_setting(name, default, lo=None, hi=None):
    try:
        value = int(setting(name, str(default)))
    except Exception:
        value = default
    if lo is not None:
        value = max(lo, value)
    if hi is not None:
        value = min(hi, value)
    return value


def bool_setting(name, default=False):
    value = setting(name, "true" if default else "false").lower().strip()
    return value in ("1", "true", "yes", "on")


def config():
    return {
        "bridge_host": setting("bridge_host", "127.0.0.1"),
        "bridge_port": int_setting("bridge_port", 8765, 1, 65535),
        "bridge_path": setting("bridge_path", "/"),
        "use_tls": bool_setting("use_tls", False),
        "verify_tls": bool_setting("verify_tls", True),
        "auth_token": setting("auth_token", ""),
        "kodi_host": setting("kodi_host", "127.0.0.1"),
        "kodi_port": int_setting("kodi_port", 8080, 1, 65535),
        "reconnect_min_seconds": int_setting("reconnect_min_seconds", 5, 1, 300),
        "reconnect_max_seconds": int_setting("reconnect_max_seconds", 60, 1, 600),
        "telemetry_interval_seconds": int_setting("telemetry_interval_seconds", 30, 5, 3600),
        "enable_http_proxy": bool_setting("enable_http_proxy", True),
        "enable_management_rpc": bool_setting("enable_management_rpc", True),
        "enable_log_tail": bool_setting("enable_log_tail", True),
        "enable_iphone_bridge": bool_setting("enable_iphone_bridge", False),
        "iphone_bridge_host": setting("iphone_bridge_host", ""),
        "iphone_bridge_port": int_setting("iphone_bridge_port", 9192, 1, 65535),
        "iphone_bridge_token": setting("iphone_bridge_token", ""),
        "iphone_bridge_reconnect_min_seconds": int_setting("iphone_bridge_reconnect_min_seconds", 3, 1, 300),
        "iphone_bridge_reconnect_max_seconds": int_setting("iphone_bridge_reconnect_max_seconds", 30, 1, 600),
    }


if __name__ == "__main__":
    log("Xbox Web Proxy v%s starting" % ADDON_VERSION)
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(60):
            break
    log("Xbox Web Proxy shutting down")
