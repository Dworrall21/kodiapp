# -*- coding: utf-8 -*-
"""Minimal test service for Kodi."""
import xbmc
xbmc.log("[script.xbox.proxy] minimal test loaded", xbmc.LOGINFO)
