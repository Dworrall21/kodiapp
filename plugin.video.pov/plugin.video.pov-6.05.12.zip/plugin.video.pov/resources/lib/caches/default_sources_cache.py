# -*- coding: utf-8 -*-
from modules import kodi_utils
from caches.meta_cache import MetaCache  # Not used but we can import if needed; we'll use our own DB

# We'll create a class to handle default sources
class DefaultSources:
    def __init__(self):
        self.db_path = kodi_utils.default_sources_db

    def _get_connection(self):
        return kodi_utils.database_connect(self.db_path)

    def set_default(self, scope, tmdb_id, season, episode, source):
        """
        Save a source as the default for the given scope (show/season/episode).
        source is a dict containing at least: scrape_provider, provider, debrid, info_hash, package, quality, name, title, size, etc.
        We only store safe fingerprints, no URLs or tokens.
        """
        # Normalize the source to a fingerprint
        fp = self._source_fingerprint(source)
        if not fp:
            return False
        with self._get_connection() as con:
            cur = con.cursor()
            # Use INSERT OR REPLACE to update if exists
            cur.execute("""
                INSERT OR REPLACE INTO default_sources
                (scope, tmdb_id, season, episode, scrape_provider, provider, debrid, info_hash, package, quality, normalized_name, release_title, size, created_at, last_used_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                scope,
                str(tmdb_id),
                str(season) if season else '',
                str(episode) if episode else '',
                fp.get('scrape_provider', ''),
                fp.get('provider', ''),
                fp.get('debrid', ''),
                fp.get('info_hash', ''),
                fp.get('package', ''),
                fp.get('quality', ''),
                fp.get('normalized_name', ''),
                fp.get('release_title', ''),
                fp.get('size', ''),
                int(fp.get('created_at', 0)),
                int(fp.get('last_used_at', 0))
            ))
            con.commit()
        return True

    def clear_default(self, scope, tmdb_id, season=None, episode=None):
        """Remove the default source for the given scope and ids."""
        with self._get_connection() as con:
            cur = con.cursor()
            if scope == 'show':
                cur.execute("DELETE FROM default_sources WHERE scope=? AND tmdb_id=? AND season='' AND episode=''", (scope, str(tmdb_id)))
            elif scope == 'season':
                cur.execute("DELETE FROM default_sources WHERE scope=? AND tmdb_id=? AND season=? AND episode=''", (scope, str(tmdb_id), str(season) if season else ''))
            elif scope == 'episode':
                cur.execute("DELETE FROM default_sources WHERE scope=? AND tmdb_id=? AND season=? AND episode=?",
                            (scope, str(tmdb_id), str(season) if season else '', str(episode) if episode else ''))
            con.commit()
        return True

    def get_candidates(self, tmdb_id, season=None, episode=None):
        """Return a list of fingerprints matching the scope hierarchy (episode, season, show)."""
        candidates = []
        with self._get_connection() as con:
            cur = con.cursor()
            # Episode
            if episode is not None:
                cur.execute("""SELECT * FROM default_sources WHERE tmdb_id=? AND season=? AND episode=? AND scope='episode'""",
                            (str(tmdb_id), str(season) if season else '', str(episode) if episode else ''))
                row = cur.fetchone()
                if row:
                    candidates.append(self._row_to_fingerprint(row))
            # Season
            if season is not None and not candidates:
                cur.execute("""SELECT * FROM default_sources WHERE tmdb_id=? AND season=? AND episode='' AND scope='season'""",
                            (str(tmdb_id), str(season) if season else ''))
                row = cur.fetchone()
                if row:
                    candidates.append(self._row_to_fingerprint(row))
            # Show
            if not candidates:
                cur.execute("""SELECT * FROM default_sources WHERE tmdb_id=? AND season='' AND episode='' AND scope='show'""",
                            (str(tmdb_id),))
                row = cur.fetchone()
                if row:
                    candidates.append(self._row_to_fingerprint(row))
        return candidates

    def best_match(self, tmdb_id, season, episode, results):
        """
        Given a list of result sources, return the one that best matches the default preferences.
        We'll use a simple scoring system: exact hash match is best, then provider/debrid/package/name.
        We'll return the source dict with an added 'default_source_match' field indicating the scope.
        """
        # Get candidates in order: episode, season, show
        candidates = self.get_candidates(tmdb_id, season, episode)
        if not candidates:
            return None

        # We'll score each result against each candidate, but we want the highest scoring result.
        # For simplicity, we'll just look for the first result that matches any candidate with a high enough score.
        # We'll define a match score function.
        best_score = 0
        best_result = None
        best_scope = None

        for result in results:
            result_fp = self._source_fingerprint(result)
            if not result_fp:
                continue
            for cand in candidates:
                score = self._match_score(cand, result_fp)
                if score > best_score:
                    best_score = score
                    best_result = result
                    best_scope = cand.get('scope', 'unknown')

        if best_score >= 80:  # Threshold for considering a match
            # Mark the result as a default source match
            best_result['default_source_match'] = best_scope  # We'll fix this to be the actual scope
            best_result['default_source_label'] = f'DEFAULT: {best_scope.upper()}'
            return best_result
        return None

    def rank_results(self, tmdb_id, season, episode, results):
        """
        Reorder results so that the best matching default source is at the top.
        Returns a new list with the matched result moved to index 0, others in original order.
        """
        matched = self.best_match(tmdb_id, season, episode, results)
        if matched is None:
            return results
        # Create a new list with matched first, then the rest in original order (excluding the matched one)
        new_results = [matched]
        for res in results:
            if res is not matched:
                new_results.append(res)
        return new_results

    # Helper methods
    def _source_fingerprint(self, source):
        """Extract a safe fingerprint from a source dict."""
        # We'll use the info_hash if available, otherwise a combination of other fields.
        info_hash = source.get('info_hash') or source.get('hash')
        if info_hash:
            # We'll still include other fields to avoid collisions, but info_hash is the strongest.
            return {
                'info_hash': info_hash,
                'scrape_provider': source.get('scrape_provider', ''),
                'provider': source.get('provider', ''),
                'debrid': source.get('debrid', ''),
                'package': source.get('package', ''),
                'quality': source.get('quality', ''),
                'normalized_name': self._normalize_release_name(source.get('name', '') or source.get('title', '')),
                'release_title': source.get('title', ''),
                'size': source.get('size', ''),
                'created_at': source.get('created_at', 0),
                'last_used_at': source.get('last_used_at', 0)
            }
        else:
            # Fallback to a combination of fields (less reliable)
            name = self._normalize_release_name(source.get('name', '') or source.get('title', ''))
            if not name:
                return None
            return {
                'info_hash': '',
                'scrape_provider': source.get('scrape_provider', ''),
                'provider': source.get('provider', ''),
                'debrid': source.get('debrid', ''),
                'package': source.get('package', ''),
                'quality': source.get('quality', ''),
                'normalized_name': name,
                'release_title': source.get('title', ''),
                'size': source.get('size', ''),
                'created_at': source.get('created_at', 0),
                'last_used_at': source.get('last_used_at', 0)
            }

    def _normalize_release_name(self, name):
        """Normalize a release name for comparison."""
        if not name:
            return ''
        # Convert to lowercase, remove punctuation, extra spaces.
        import re
        name = name.lower()
        name = re.sub(r'[._\-\[\]()]', ' ', name)
        name = re.sub(r'\s+', ' ', name).strip()
        return name

    def _match_score(self, fp1, fp2):
        """Compute a match score between two fingerprints."""
        score = 0
        # Exact info_hash match
        if fp1.get('info_hash') and fp1.get('info_hash') == fp2.get('info_hash'):
            score += 100
            # We can still add other matches but info_hash is enough.
            return score

        # Provider/debrid/package match
        if fp1.get('provider') and fp1.get('provider') == fp2.get('provider'):
            score += 20
        if fp1.get('debrid') and fp1.get('debrid') == fp2.get('debrid'):
            score += 20
        if fp1.get('package') and fp1.get('package') == fp2.get('package'):
            score += 10

        # Normalized name similarity
        n1 = fp1.get('normalized_name', '')
        n2 = fp2.get('normalized_name', '')
        if n1 and n2:
            if n1 == n2:
                score += 30
            elif n1 in n2 or n2 in n1:
                score += 20
            # We could do a more sophisticated similarity, but this is fine for now.

        # Quality match (less important)
        if fp1.get('quality') and fp1.get('quality') == fp2.get('quality'):
            score += 10

        return score

    def _row_to_fingerprint(self, row):
        """Convert a database row to a fingerprint dict."""
        # Assuming the row order matches the CREATE TABLE statement.
        # We'll map by index for safety.
        return {
            'scope': row[0],
            'tmdb_id': row[1],
            'season': row[2],
            'episode': row[3],
            'scrape_provider': row[4],
            'provider': row[5],
            'debrid': row[6],
            'info_hash': row[7],
            'package': row[8],
            'quality': row[9],
            'normalized_name': row[10],
            'release_title': row[11],
            'size': row[12],
            'created_at': row[13],
            'last_used_at': row[14]
        }