"""Helpers for user-configurable source settings.

Keep this module Kodi-free so URL shaping can be unit-tested outside Kodi.
"""

TORRENTIO_ORIGIN = "https://torrentio.strem.fun"


def _setting(settings_getter, key, fallback=""):
	try:
		value = settings_getter(key, fallback)
	except TypeError:
		value = settings_getter(key)
	except Exception:
		value = fallback
	return fallback if value is None else str(value).strip()


def _enabled(value):
	return str(value).strip().lower() in ("true", "1", "yes", "on")


def _normalize_torrentio_config(raw_config):
	"""Return a safe Torrentio config path, or empty string.

	Accepted forms:
	- providers=alpha,beta
	- /providers=alpha,beta/manifest.json
	- https://torrentio.strem.fun/providers=alpha,beta/manifest.json

	The function intentionally only accepts Torrentio-origin URLs or relative
	config fragments. It does not proxy arbitrary third-party URLs.
	"""
	config = (raw_config or "").strip()
	if not config:
		return ""
	config = config.replace(" ", "")
	origin = TORRENTIO_ORIGIN + "/"
	if config.startswith(origin):
		config = config[len(origin):]
	elif config.startswith("http://") or config.startswith("https://"):
		return ""
	config = config.lstrip("/")
	for suffix in ("/manifest.json", "/stream/movie/", "/stream/series/"):
		if suffix in config:
			config = config.split(suffix, 1)[0]
	config = config.strip("/")
	if not config or any(ch in config for ch in "?#"):
		return ""
	return config


def torrentio_base_url(settings_getter):
	"""Build Torrentio base URL from POV settings.

	When custom sources are disabled or invalid, returns Torrentio's default
	origin so existing behavior is preserved.
	"""
	if not _enabled(_setting(settings_getter, "provider.torrentio.custom.enabled", "false")):
		return TORRENTIO_ORIGIN
	config = _normalize_torrentio_config(_setting(settings_getter, "provider.torrentio.custom.providers", ""))
	if not config:
		return TORRENTIO_ORIGIN
	return "%s/%s" % (TORRENTIO_ORIGIN, config)
