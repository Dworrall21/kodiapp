# -*- coding: utf-8 -*-
"""
router: dispatches ?action=... requests to menu builders / utilities.

Public API:
    dispatch(query_string) -> None
"""
import sys
import os

# Make resources.lib importable from this file
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, os.path.dirname(_HERE))

from .utils import log, parse_query, set_handle, end_of_directory, get_addon
from . import menus
from . import maintenance
from . import backup
from . import speedtest
from . import tools as tools_mod
from . import account_manager
from . import m3u
from . import tmdb
from . import debrid
from . import dashboard
from . import debrid_search
from . import indexers


def dispatch(qs):
    """Parse query string and route to a handler.

    If no 'action' is present, we open the Browse (POV-style) home.
    'action=tools' switches to the Wizard-style home.
    """
    handle = 0
    try:
        if len(sys.argv) > 1 and sys.argv[1].isdigit():
            handle = int(sys.argv[1])
    except Exception:
        pass
    set_handle(handle)
    params = parse_query(qs or "")
    action = params.get("action")

    try:
        log("dispatch action=%r params=%s" % (action, {k: v for k, v in params.items() if k != "action"}))
    except Exception:
        pass

    if action is None or action == "home":
        menus.browse_home(params)
    elif action == "tools":
        menus.tools_home(params)
    elif action == "movies":
        menus.list_movies(params)
    elif action == "tv":
        menus.list_tv(params)
    elif action == "anime":
        menus.list_anime(params)
    elif action == "discover":
        menus.list_discover(params)
    elif action == "search":
        menus.do_search(params)
    elif action == "favorites":
        menus.list_favorites(params)
    elif action == "list_m3u":
        menus.list_m3u(params)
    elif action == "list_m3u_kind":
        menus.list_m3u_kind(params)
    elif action == "list_titles":
        menus.list_titles(params)
    elif action == "list_tmdb_titles":
        menus.list_tmdb_titles(params)
    elif action == "list_tmdb_title":
        menus.list_tmdb_title(params)
    elif action == "play":
        menus.play(params)
    elif action == "add_favorite":
        menus.add_favorite(params)
    elif action == "remove_favorite":
        menus.remove_favorite(params)

    elif action == "account_manager":
        account_manager.menu()
    elif action == "authorize_debrid":
        account_manager.authorize_debrid(params)
    elif action == "check_debrid":
        account_manager.check_debrid(params)
    elif action == "trakt_device":
        account_manager.trakt_device_flow()

    elif action == "maintenance":
        maintenance.menu()
    elif action == "maint_clear_packages":
        maintenance.clear_packages()
    elif action == "maint_clear_thumbnails":
        maintenance.clear_thumbnails()
    elif action == "maint_clear_cache":
        maintenance.clear_cache()
    elif action == "maint_fresh_start":
        maintenance.fresh_start()
    elif action == "maint_cache_settings":
        maintenance.cache_settings()

    elif action == "backup_restore":
        backup.menu()
    elif action == "backup_run":
        backup.run_backup()
    elif action == "restore_run":
        backup.run_restore(params)
    elif action == "backup_set_folder":
        backup.set_folder()
    elif action == "backup_reset_folder":
        backup.reset_folder()

    elif action == "speedtest":
        speedtest.run()
    elif action == "view_logs":
        tools_mod.view_logs()
    elif action == "force_update":
        tools_mod.force_update()
    elif action == "force_close_kodi":
        tools_mod.force_close()
    elif action == "whitelist":
        tools_mod.whitelist_menu()
    elif action == "whitelist_add":
        tools_mod.whitelist_add()
    elif action == "whitelist_remove":
        tools_mod.whitelist_remove()
    elif action == "notifications":
        tools_mod.notifications()
    elif action == "tools_menu":
        menus.tools_submenu()

    elif action == "refresh_m3u":
        m3u.clear_cache_and_refresh()
        menus.browse_home({"refreshed": "1"})

    elif action == "test_tmdb":
        tmdb.test_key()
    elif action == "test_debrid":
        debrid.test_active()
    elif action == "test_indexers":
        indexers.test_indexers()
    elif action == "open_settings":
        try:
            get_addon().openSettings()
        except Exception as e:
            log("open_settings failed: %r" % e, "warn")

    # --- Dashboard (Helix v0.2.0) ---
    elif action == "dashboard":
        dashboard.home(params)
    elif action == "dashboard_debug":
        dashboard.debug(params)
    elif action == "dashboard_logs":
        dashboard.logs_menu(params)
    elif action == "dashboard_log_view":
        dashboard.log_view(params)
    elif action == "dashboard_log_filter":
        dashboard.log_filter_prompt(params)
    elif action == "dashboard_log_export":
        dashboard.log_export(params)
    elif action == "dashboard_log_path":
        dashboard.log_path(params)
    elif action == "dashboard_settings":
        dashboard.settings_list(params)
    elif action == "dashboard_setting_edit":
        dashboard.setting_edit(params)
    elif action == "dashboard_actions":
        dashboard.actions_menu(params)
    elif action == "dashboard_action_clear_cache":
        dashboard.action_clear_cache()
    elif action == "dashboard_action_force_update":
        dashboard.action_force_update()
    elif action == "dashboard_action_refresh_m3u":
        dashboard.action_refresh_m3u()
    elif action == "dashboard_action_speedtest":
        dashboard.action_speedtest()
    elif action == "dashboard_action_test_tmdb":
        dashboard.action_test_tmdb()
    elif action == "dashboard_action_test_debrid":
        dashboard.action_test_debrid()
    elif action == "dashboard_action_restart_service":
        dashboard.action_restart_service()
    elif action == "dashboard_action_save_log":
        dashboard.action_save_log()
    elif action == "dashboard_action_dump_debug":
        dashboard.action_dump_debug()
    elif action == "dashboard_about":
        dashboard.about(params)
    elif action == "dashboard_changelog":
        dashboard.changelog(params)

    else:
        log("unknown action: %r" % action, "warn")
        menus.browse_home({})

    end_of_directory()
