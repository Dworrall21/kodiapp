# -*- coding: utf-8 -*-
"""
menus: builds the on-screen directory listings.

Browse home (POV-style):
    Movies | TV Shows | Anime | Discover | Search | Favorites
    Top bar: "Switch to Tools"

Results architecture — debrid-first, M3U fallback:
    For category browse (Movies/TV/Anime):
        1. Debrid Sources section (TMDB discover categories)
        2. Live TV / M3U section (M3U groups at bottom)

    For search:
        1. TMDB results (link to debrid-cached streams with quality badges)
        2. Live TV / M3U section (M3U match groups at bottom)

    For TMDB title detail:
        1. Quality-grouped debrid streams (with green cached badges)
        2. Live TV / M3U section at bottom
"""
from .utils import (
    add_item, url_for, log, notify, get_setting, get_int_setting, addon_info,
    set_content, add_sort_method, play_url, make_item, resolve_item,
    dialog_input, cache_get, cache_set,
)
from .modules.colors import c, b, i
from . import m3u
from . import tmdb
from . import debrid
from . import debrid_search
import xbmcplugin

SORT_LABEL = xbmcplugin.SORT_METHOD_LABEL
SORT_TITLE = xbmcplugin.SORT_METHOD_TITLE
SORT_DATE = xbmcplugin.SORT_METHOD_DATE

# --- top / bottom bars ---

def _topbar():
    """First item: a non-folder link to switch context."""
    add_item(
        c("gold", b(">>> SWITCH TO TOOLS <<<")),
        url_for("tools"),
        is_folder=True,
        info={"plot": "Open the maintenance toolkit (Account Manager, Maintenance, Backup/Restore, Tools)."},
    )


def _bottombar():
    add_item(
        c("gold", b(">>> SWITCH TO BROWSE <<<")),
        url_for("home"),
        is_folder=True,
        info={"plot": "Open the browse experience (Movies, TV, Anime, Discover, Search, Favorites)."},
    )


def _browse_status():
    """A small status line that shows M3U count + active debrid."""
    src = m3u.get_cached_source()
    n_items = len(src.get("items", [])) if src else 0
    active = debrid.active_provider_name() or "None"
    src_url = get_setting("source.m3u.url") or get_setting("source.m3u.local") or "(no source)"
    add_item(
        c("gray", "[%d items]  [debrid: %s]  [source: %s]" % (n_items, active, _shorten(src_url, 60))),
        url_for("refresh_m3u"),
        is_folder=False,
        info={"plot": "Click to refresh the M3U source."},
    )


def _shorten(s, n):
    s = s or ""
    if len(s) <= n:
        return s
    return s[: n - 1] + "…"


def _fmt_size(size_mb):
    """Format size in MB to a human string."""
    if size_mb >= 1024:
        return "%.1f GB" % (size_mb / 1024.0)
    if size_mb > 0:
        return "%d MB" % size_mb
    return "?"


# --- section separators ---

def _section_header(label):
    """Render a non-interactive section divider."""
    add_item(
        c("dimgray", b("─── %s ───" % label)),
        "",
        is_folder=False,
        info={"plot": ""},
    )


# --- tools / home menus (unchanged) ---

def tools_submenu():
    set_content("files")
    add_sort_method(SORT_LABEL)
    add_item(c("orange", b("Speedtest")),        url_for("speedtest"),       is_folder=False, info={"plot": "Run a quick latency + download check."})
    add_item(c("orange", b("View Logs")),        url_for("view_logs"),       is_folder=False, info={"plot": "Tail the most recent kodi.log."})
    add_item(c("orange", b("Force Update")),     url_for("force_update"),    is_folder=False, info={"plot": "Trigger Kodi's addon repo update."})
    add_item(c("orange", b("Force Close Kodi")), url_for("force_close_kodi"),is_folder=False, info={"plot": "Quit Kodi."})
    add_item(c("orange", b("Whitelist")),        url_for("whitelist"),       is_folder=True,  info={"plot": "Manage the addon-ID whitelist."})


def browse_home(params=None):
    """The Browse home: tabs into Movies / TV / Anime / Discover / Search / Favorites."""
    set_content("files")
    add_sort_method(SORT_LABEL)

    _topbar()
    _browse_status()
    add_item(
        c("deepskyblue", b("Movies")),
        url_for("movies"),
        is_folder=True,
        info={"plot": "Browse movies from TMDB + debrid, with M3U fallback."},
        art={"icon": "DefaultMovies.png"},
    )
    add_item(
        c("deepskyblue", b("TV Shows")),
        url_for("tv"),
        is_folder=True,
        info={"plot": "Browse TV shows from TMDB + debrid, with M3U fallback."},
        art={"icon": "DefaultTVShows.png"},
    )
    add_item(
        c("deepskyblue", b("Anime")),
        url_for("anime"),
        is_folder=True,
        info={"plot": "Browse anime from TMDB + debrid, with M3U fallback."},
        art={"icon": "DefaultAnime.png"},
    )
    add_item(
        c("deepskyblue", b("Discover")),
        url_for("discover"),
        is_folder=True,
        info={"plot": "Trending and recommended content from TMDB."},
        art={"icon": "DefaultStudios.png"},
    )
    add_item(
        c("deepskyblue", b("Search")),
        url_for("search"),
        is_folder=True,
        info={"plot": "Search TMDB for movies and shows."},
        art={"icon": "DefaultAddonsSearch.png"},
    )
    add_item(
        c("deepskyblue", b("Favorites")),
        url_for("favorites"),
        is_folder=True,
        info={"plot": "Your saved items."},
        art={"icon": "DefaultFavourites.png"},
    )
    add_item(
        c("lightgray", "Open Helix Settings…"),
        url_for("open_settings"),
        is_folder=False,
        info={"plot": "Configure M3U source, TMDB, debrid, news, cache."},
    )
    add_item(
        c("orchid", b("Dashboard")),
        url_for("dashboard"),
        is_folder=True,
        info={"plot": "Debug info, logs, settings editor, and quick actions."},
    )


def tools_home(params=None):
    """The Tools home: wizard-style menu of utilities."""
    set_content("files")
    add_sort_method(SORT_LABEL)

    _bottombar()
    add_item(
        c("orange", b("Account Manager")),
        url_for("account_manager"),
        is_folder=True,
        info={"plot": "Authorize Real-Debrid, AllDebrid, Premiumize, TorBox, or Trakt."},
    )
    add_item(
        c("orange", b("Maintenance")),
        url_for("maintenance"),
        is_folder=True,
        info={"plot": "Clear packages, clear thumbnails, clear cache, fresh start, advancedsettings."},
    )
    add_item(
        c("orange", b("Backup / Restore")),
        url_for("backup_restore"),
        is_folder=True,
        info={"plot": "Back up your Kodi userdata; restore from a previous backup."},
    )
    add_item(
        c("orange", b("Tools")),
        url_for("tools_menu"),
        is_folder=True,
        info={"plot": "Speedtest, View Logs, Force Update, Force Close, Whitelist."},
    )
    add_item(
        c("orange", b("Notifications")),
        url_for("notifications"),
        is_folder=True,
        info={"plot": "Read the latest announcement from the maintainer."},
    )
    add_item(
        c("lightgray", "Open Helix Settings…"),
        url_for("open_settings"),
        is_folder=False,
        info={"plot": "Configure M3U source, TMDB, debrid, news, cache."},
    )


# =========================================================================
# Browse: category listings — debrid discover first, M3U fallback
# =========================================================================

def list_movies(params):
    """Movies: debrid discover categories + M3U groups at bottom."""
    set_content("movies")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)

    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    _section_header("Debrid Sources")
    _add_discover_categories("movie")

    _section_header("Live TV / M3U")
    items = m3u.get_filtered_items(kind="movie")
    for it in items:
        _render_title_item(it)


def list_tv(params):
    """TV Shows: debrid discover categories + M3U groups at bottom."""
    set_content("tvshows")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)

    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    _section_header("Debrid Sources")
    _add_discover_categories("tv")

    _section_header("Live TV / M3U")
    items = m3u.get_filtered_items(kind="tv")
    for it in items:
        _render_title_item(it)


def list_anime(params):
    """Anime: debrid discover categories + M3U groups at bottom."""
    set_content("tvshows")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)

    add_item(c("gold", b("[ Refresh M3U ]")), url_for("refresh_m3u"), is_folder=False)
    _section_header("Debrid Sources")
    _add_discover_categories("tv")

    _section_header("Live TV / M3U")
    items = m3u.get_filtered_items(kind="anime")
    for it in items:
        _render_title_item(it)


def _add_discover_categories(media_type="movie"):
    """Add TMDB discover category links that route to list_tmdb_title."""
    categories = [
        ("Trending (week)",   "trending_week"),
        ("Popular (day)",     "popular_day"),
        ("Top Rated",         "top_rated"),
        ("Now Playing",       "now_playing") if media_type == "movie" else ("Airing Today", "airing_today"),
        ("Upcoming",          "upcoming") if media_type == "movie" else ("On The Air", "on_the_air"),
    ]
    for label, kind in categories:
        if label is None:
            continue
        info = {"plot": "Browse %s from TMDB — debrid streams + M3U fallback." % kind.replace("_", " ")}
        add_item(
            c("gold", b(label)),
            url_for("list_tmdb_titles", media_type=media_type, discover_kind=kind),
            is_folder=True,
            info=info,
        )


# =========================================================================
# TMDB result listing — shows quality-grouped debrid streams + M3U at bottom
# =========================================================================

def list_tmdb_titles(params):
    """Show TMDB discover results → each item links to debrid-quality detail view.

    Built as a two-level flow:
        Level 1 (this function): TMDB discover items (posters, title, year)
        Level 2 (via list_tmdb_title): quality-grouped debrid streams + M3U
    """
    media_type = params.get("media_type", "movie")
    discover_kind = params.get("discover_kind")

    if discover_kind:
        results = _get_discover_results(media_type, discover_kind)
    else:
        # If called without discover_kind, show discover categories
        set_content("files")
        add_sort_method(SORT_LABEL)
        _add_discover_categories(media_type)
        return

    if not results:
        notify("Helix", "No results from TMDB.", "warn")
        return

    if media_type == "movie":
        set_content("movies")
    else:
        set_content("tvshows")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)

    for r in results:
        _render_tmdb_result_item(r, media_type)


def _get_discover_results(media_type, discover_kind):
    """Fetch TMDB discover results for the given kind."""
    if media_type == "movie":
        tmdb_kinds = {
            "trending_week": "trending_week",
            "popular_day": "popular_day",
            "top_rated": "top_rated",
            "now_playing": "now_playing",
            "upcoming": "upcoming",
        }
    else:
        tmdb_kinds = {
            "trending_week": "trending_week",
            "popular_day": "popular_day",
            "top_rated": "top_rated",
            "airing_today": "airing_today",
            "on_the_air": "on_the_air",
        }
    kind = tmdb_kinds.get(discover_kind)
    if not kind:
        return []
    return tmdb.discover(kind)


def _render_tmdb_result_item(r, media_type="movie"):
    """Render a single TMDB result as a folder that opens debrid quality view."""
    label = r.get("title") or r.get("name") or "(untitled)"
    tmdb_id = r.get("id")
    year = (r.get("release_date") or r.get("first_air_date") or "0000")[:4]

    info = {
        "title": label,
        "plot": r.get("overview", "") or "",
        "year": int(year) if year.isdigit() else 0,
        "rating": float(r.get("vote_average") or 0),
        "mediatype": "movie" if media_type == "movie" else "tvshow",
    }
    art = None
    if r.get("poster_path"):
        art = {"poster": tmdb.image(r.get("poster_path"))}

    add_item(
        c("white", b(label)) + c("gray", "  %s" % year if year else ""),
        url_for("list_tmdb_title", tmdb_id=str(tmdb_id), media_type=media_type),
        is_folder=True,
        info=info,
        art=art,
    )


# =========================================================================
# Title detail — quality-grouped debrid streams + M3U fallback
# =========================================================================

def list_tmdb_title(params):
    """Show quality-grouped debrid streams for a TMDB title + M3U at bottom.

    URL args:
        tmdb_id: numeric TMDB ID
        media_type: "movie" or "tv"
    """
    tmdb_id = params.get("tmdb_id")
    media_type = params.get("media_type", "movie")
    if not tmdb_id:
        notify("Helix", "Missing TMDB ID.", "error")
        return

    set_content("videos")
    add_sort_method(SORT_LABEL)

    # 1. Fetch TMDB metadata for the title label
    meta = _get_tmdb_metadata(media_type, tmdb_id)

    # 2. Query debrid search provider for cached streams
    grouped = debrid_search.search_by_tmdb(media_type, tmdb_id)

    if grouped:
        _section_header("Debrid Streams")
        # Quality tiers in display order
        for tier in ("4K", "1080p", "720p", "480p", "Other"):
            streams = grouped.get(tier)
            if not streams:
                continue
            cached_count = sum(1 for s in streams if s.get("cached"))
            _render_quality_header(tier, cached_count, len(streams))
            for s in streams:
                _render_debrid_stream(s, meta)

    # 3. M3U matches at bottom
    _render_m3u_matches_section(meta, media_type)

    # 4. If nothing at all, show notice
    if not grouped:
        title = meta.get("title") or "this title"
        add_item(
            c("gray", "(no debrid streams found for \"%s\")" % title),
            "",
            is_folder=False,
            info={"plot": "Try a different search or check your debrid provider."},
        )


def _get_tmdb_metadata(media_type, tmdb_id):
    """Fetch metadata for a single TMDB ID."""
    data = tmdb.details(media_type, tmdb_id)
    if data:
        return {
            "title": data.get("title") or data.get("name") or "",
            "year": (data.get("release_date") or data.get("first_air_date") or "")[:4],
            "plot": data.get("overview", ""),
        }
    return {}


def _render_quality_header(tier, cached_count, total):
    """Quality section header with cached count."""
    badge = c("lime", " [%d cached]" % cached_count) if cached_count else ""
    add_item(
        c("white", b("── %s ──" % tier)) + c("gray", "  (%d streams)" % total) + badge,
        "",
        is_folder=False,
        info={"plot": "%s quality tier — %d streams, %d cached" % (tier, total, cached_count)},
    )


def _render_debrid_stream(stream, meta=None):
    """Render a single debrid stream as a playable item."""
    label = stream.get("name", "(stream)")
    source = stream.get("source", "?")
    size = stream.get("size_mb", 0)
    cached = stream.get("cached", False)

    # Build display label: green badge + quality + source + size
    badge = c("lime", "\u25cf ") if cached else c("gray", "\u25cb ")
    size_str = " | %.1f GB" % (size / 1024.0) if size > 1024 else (" | %d MB" % size) if size > 0 else ""
    display = badge + c("white", label) + c("gray", "  [%s%s]" % (source, size_str))

    # Build URL: infoHash → magnet → debrid resolve, or direct URL
    play_url_val = _build_play_url(stream)
    info = {
        "title": label,
        "size": size * 1024 * 1024 if size else 0,  # MB → bytes
        "plot": "Source: %s | Size: %s | Cached: %s" % (
            source, _fmt_size(size), "yes" if cached else "no"
        ),
    }
    add_item(
        display,
        url_for("play", url=play_url_val, cached="1" if cached else "0"),
        is_folder=False,
        info=info,
        properties={"IsPlayable": "true"},
    )


def _build_play_url(stream):
    """Build a URL for the play action from a debrid stream entry.

    Precedence:
        1. direct URL (already resolved)
        2. infoHash → magnet link
        3. fallback to empty
    """
    url = stream.get("url", "")
    if url:
        return url
    info_hash = stream.get("infoHash", "")
    if info_hash:
        # Construct magnet link
        magnet = "magnet:?xt=urn:btih:%s" % info_hash
        dn = stream.get("name", "").replace(" ", "+")
        if dn:
            magnet += "&dn=" + dn
        return magnet
    return ""


def _render_m3u_matches_section(meta, media_type):
    """Show M3U groups that match the current TMDB title at the bottom."""
    title = (meta.get("title") or "").lower()
    if not title:
        return

    all_items = m3u.get_filtered_items(kind="all")
    # Fuzzy match: M3U group title contains the TMDB title or vice versa
    matches = []
    for g in all_items:
        gt = (g.get("title") or "").lower()
        # Token overlap: any word from title appears in gt (length > 3)
        title_words = set(w for w in title.split() if len(w) > 3)
        if title_words:
            gt_words = set(gt.split())
            if title_words & gt_words:
                matches.append(g)

    if not matches:
        return

    _section_header("Live TV / M3U")
    for g in matches:
        _render_title_item(g)


# =========================================================================
# M3U title / stream helpers (shared with search results)
# =========================================================================

def _render_title_item(it):
    """A title (group) row. Opening it shows the streams under that title."""
    label = it.get("title", "(untitled)")
    n = it.get("count", 0)
    art = {"poster": it.get("poster", ""), "fanart": it.get("backdrop", "")} if it.get("poster") else None
    info = {
        "title": label,
        "plot": it.get("plot", ""),
        "year": it.get("year", 0),
        "rating": float(it.get("rating", 0) or 0),
        "genre": it.get("genres", ""),
        "mediatype": "movie" if it.get("kind") == "movie" else "tvshow",
    }
    add_item(
        c("white", b(label)) + c("gray", "  (" + str(n) + " streams)"),
        url_for("list_titles", group=it.get("id", "")),
        is_folder=True,
        info=info,
        art=art,
        context=[(
            "Add to Favorites",
            "RunPlugin(" + url_for("add_favorite", group=it.get("id", "")) + ")",
        )] if it.get("id") else None,
    )


def list_titles(params):
    """Show all streams in an M3U group, then play the chosen one."""
    group_id = params.get("group")
    items = m3u.get_filtered_items(kind="all")
    group = next((g for g in items if g.get("id") == group_id), None)
    if not group:
        notify("Helix", "Group not found (refresh M3U and try again).", "warn")
        return
    set_content("videos")
    add_sort_method(SORT_LABEL)
    for s in group.get("streams", []):
        label = s.get("name") or s.get("title") or s.get("url", "(stream)")
        info = {
            "title": label,
            "size": int(s.get("size", 0) or 0) * 1024 * 1024,  # MB -> bytes
        }
        add_item(
            c("white", label),
            url_for("play", url=s.get("url", ""), group=group_id),
            is_folder=False,
            info=info,
            properties={"IsPlayable": "true"},
        )


def list_m3u(params):
    """List all M3U groups (no category filter)."""
    set_content("files")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)
    all_items = m3u.get_filtered_items(kind="all")
    for it in all_items:
        _render_title_item(it)


def list_m3u_kind(params):
    """List M3U groups filtered by a specific kind from params."""
    kind = params.get("kind", "all")
    set_content("files")
    add_sort_method(SORT_LABEL)
    add_sort_method(SORT_TITLE)
    items = m3u.get_filtered_items(kind=kind)
    for it in items:
        _render_title_item(it)


def torrentio_search_results(params):
    """Render a flat list of Torrentio-scraped results."""
    # Delegates to the new debrid-search flow via TMDB ID.
    tmdb_id = params.get("tmdb_id")
    media_type = params.get("media_type", "movie")
    if tmdb_id:
        list_tmdb_title(params)
    else:
        notify("Helix", "Missing TMDB ID for torrentio search.", "warn")


# =========================================================================
# Play
# =========================================================================

def play(params):
    """Resolve and play a stream URL through debrid if configured."""
    url = params.get("url")
    if not url:
        notify("Helix", "No URL provided.", "error")
        return
    log("play: %s" % _shorten(url, 100))
    resolved = debrid.resolve(url) or url
    li = make_item("Stream", resolved, is_folder=False, info={"title": "Stream"}, art={"icon": "DefaultVideo.png"})
    li.setProperty("IsPlayable", "true")
    resolve_item(li)
    play_url(resolved, li)


# =========================================================================
# Search / Discover / Favorites
# =========================================================================

def do_search(params):
    """TMDB search + debrid results first, then M3U match groups at bottom."""
    q = params.get("q")
    if not q:
        q = dialog_input("Search TMDB")
    if not q:
        return

    results = tmdb.search(q)
    if not results:
        notify("Helix", "No results (or no TMDB key).", "warn")
        return

    set_content("files")
    add_sort_method(SORT_LABEL)

    _section_header("TMDB Results — Debrid Sources")
    for r in results:
        label = r.get("title") or r.get("name")
        tmdb_id = r.get("id")
        media_type = r.get("media_type", "movie")
        # Normalize media_type for TMDB's response
        if media_type == "person":
            continue
        if media_type == "movie":
            mtype = "movie"
        else:
            mtype = "tv"
        year = (r.get("release_date") or r.get("first_air_date") or "0000")[:4]
        info = {
            "title": label,
            "plot": r.get("overview", ""),
            "year": int(year) if year.isdigit() else 0,
            "rating": float(r.get("vote_average") or 0),
        }
        art = {"poster": tmdb.image(r.get("poster_path"))} if r.get("poster_path") else None
        add_item(
            c("white", b(label or "(untitled)")) + c("gray", "  %s" % year),
            url_for("list_tmdb_title", tmdb_id=str(tmdb_id), media_type=mtype),
            is_folder=True,
            info=info,
            art=art,
        )

    # M3U matches at bottom
    _section_header("Live TV / M3U")
    all_items = m3u.get_filtered_items(kind="all")
    q_lower = q.lower()
    q_words = set(w for w in q_lower.split() if len(w) > 2)
    matched = 0
    for g in all_items:
        gt = (g.get("title") or "").lower()
        if q_lower in gt or (q_words and q_words & set(gt.split())):
            _render_title_item(g)
            matched += 1
    if not matched:
        add_item(c("gray", "(no M3U matches)"), "", is_folder=False, info={"plot": ""})


def list_discover(params):
    """TMDB discover hub + results. Results route to debrid detail view."""
    set_content("movies")
    add_sort_method(SORT_LABEL)

    _section_header("Debrid Sources — Movies")
    _add_discover_categories("movie")

    _section_header("Debrid Sources — TV")
    _add_discover_categories("tv")

    # Check for kind param (legacy direct-discover support)
    kind = params.get("kind")
    if kind:
        results = tmdb.discover(kind)
        for r in results:
            label = r.get("title") or r.get("name")
            tmdb_id = r.get("id")
            year = (r.get("release_date") or r.get("first_air_date") or "0000")[:4]
            info = {
                "title": label,
                "plot": r.get("overview", ""),
                "year": int(year) if year.isdigit() else 0,
                "rating": float(r.get("vote_average") or 0),
            }
            art = {"poster": tmdb.image(r.get("poster_path"))} if r.get("poster_path") else None
            add_item(
                c("white", b(label or "(untitled)")) + c("gray", "  %s" % year),
                url_for("list_tmdb_title", tmdb_id=str(tmdb_id), media_type="movie"),
                is_folder=True,
                info=info,
                art=art,
            )


def list_favorites(params):
    set_content("files")
    add_sort_method(SORT_LABEL)
    favs = _load_favorites()
    if not favs:
        add_item(c("gray", "(no favorites yet — long-press a title to add)"), "", is_folder=False)
        return
    for fav in favs:
        info = {
            "title": fav.get("title"),
            "plot": fav.get("plot", ""),
            "year": fav.get("year", 0),
        }
        add_item(
            c("white", b(fav.get("title") or "(untitled)")),
            url_for("list_titles", group=fav.get("id", "")),
            is_folder=True,
            info=info,
            context=[(
                "Remove from Favorites",
                "RunPlugin(" + url_for("remove_favorite", group=fav.get("id", "")) + ")",
            )],
        )


# --- favorites: stored as JSON in addon profile ---
_FAV_PATH = None
def _fav_path():
    global _FAV_PATH
    if _FAV_PATH is None:
        _FAV_PATH = addon_info("profile")
        if not _FAV_PATH:
            _FAV_PATH = "/tmp/helix_profile"
        import os
        try:
            os.makedirs(_FAV_PATH, exist_ok=True)
        except Exception:
            pass
        _FAV_PATH = os.path.join(_FAV_PATH, "favorites.json")
    return _FAV_PATH


def _load_favorites():
    import os, json
    p = _fav_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:
        return []


def _save_favorites(items):
    import os, json
    with open(_fav_path(), "w", encoding="utf-8") as fh:
        json.dump(items, fh, ensure_ascii=False, indent=2)


def add_favorite(params):
    import json
    group_id = params.get("group")
    if not group_id:
        return
    items = m3u.get_filtered_items(kind="all")
    g = next((g for g in items if g.get("id") == group_id), None)
    if not g:
        notify("Helix", "Could not add favorite (group missing).", "warn")
        return
    favs = _load_favorites()
    if not any(f.get("id") == group_id for f in favs):
        favs.append({
            "id": group_id,
            "title": g.get("title"),
            "plot": g.get("plot", ""),
            "year": g.get("year", 0),
        })
        _save_favorites(favs)
        notify("Helix", "Added: " + (g.get("title") or ""), "info", 2500)


def remove_favorite(params):
    group_id = params.get("group")
    if not group_id:
        return
    favs = _load_favorites()
    favs = [f for f in favs if f.get("id") != group_id]
    _save_favorites(favs)
    notify("Helix", "Removed.", "info", 2000)
