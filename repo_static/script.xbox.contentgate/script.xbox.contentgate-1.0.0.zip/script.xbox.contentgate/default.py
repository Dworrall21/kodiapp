# -*- coding: utf-8 -*-
"""Xbox Content Gate - rating-based PIN gate for Kodi playback.

Monitors Player.OnPlay events, checks the content rating, and prompts
for a passcode when content exceeds the configured rating threshold.
Supports session PIN (one item) and extended PIN (8-hour unlock).
"""
from __future__ import unicode_literals

import json
import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON_ID = "script.xbox.contentgate"
ADDON_VERSION = "1.0.0"

# Rating levels matching settings enum order
RATING_LEVELS = {
    "Off": 0,
    "G": 1,
    "PG": 2,
    "PG-13": 3,
    "R": 4,
    "NC-17": 5,
    "XXX": 6,
}

# TV ratings mapped to equivalent MPAA levels
TV_RATING_MAP = {
    "TV-Y": 1,      # All Children → G
    "TV-Y7": 2,     # Older Children → PG
    "TV-G": 2,      # General → PG
    "TV-PG": 3,     # Parental Guidance → PG-13
    "TV-14": 4,     # Parents Strongly Cautioned → R
    "TV-MA": 5,     # Mature Audience → NC-17
    "MA": 5,        # Mature Audience shorthand
    "MA15+": 5,     # Australian
    "R18+": 5,      # Australian
    "R-18": 5,
    "X18+": 6,      # Adult
    "R-Rated": 4,
    "Rated R": 4,
}

# Reverse lookup
RATING_NAMES = {v: k for k, v in RATING_LEVELS.items()}


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, msg), level)
    except Exception:
        pass


def get_setting(name, default=""):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        value = addon.getSetting(name)
        return value if value not in (None, "") else default
    except Exception:
        return default


def set_setting(name, value):
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        addon.setSetting(name, str(value))
    except Exception as exc:
        log("Failed to set setting %s: %s" % (name, exc), xbmc.LOGWARNING)


def int_setting(name, default=0):
    try:
        return int(get_setting(name, str(default)))
    except Exception:
        return default


def bool_setting(name, default=False):
    return get_setting(name, "true" if default else "false").lower() in ("1", "true", "yes", "on")


def get_rating_from_metadata():
    """Try to extract the content rating (MPAA) from Kodi's current playback metadata.

    Returns a rating level name string (e.g. "R", "PG-13") or empty string.
    """
    # Try multiple InfoLabel sources
    labels_to_try = [
        "ListItem.MPAARating",
        "VideoPlayer.Rating",
        "Player.Filenameandpath",
        "VideoPlayer.Content",
        "ListItem.Rating",
    ]
    for label in labels_to_try:
        value = xbmc.getInfoLabel(label)
        if value:
            log("InfoLabel %s = %s" % (label, value))
    rating = xbmc.getInfoLabel("ListItem.MPAARating")
    if rating:
        # Normalise: "Rated R" -> "R", "PG-13" -> "PG-13", etc.
        rating = rating.replace("Rated ", "").strip()
        for known in RATING_LEVELS:
            if known.lower() in rating.lower():
                return known
        # Try to find any known rating substring
        for known in sorted(RATING_LEVELS, key=len, reverse=True):
            if known.lower() in rating.lower() or rating.lower() in known.lower():
                return known
    return rating


def get_playing_file():
    """Get the currently playing file path."""
    try:
        return xbmc.getInfoLabel("Player.Filenameandpath")
    except Exception:
        return ""


def get_playing_addon():
    """Try to identify which addon initiated playback from the file path."""
    path = get_playing_file()
    if path.startswith("plugin://"):
        parts = path.replace("plugin://", "").split("/")
        if parts:
            return parts[0]
    return ""


def is_gated_addon(addon_id):
    """Check if the given addon ID is in the gated list."""
    raw = get_setting("gated_addons", "plugin.video.redlight")
    gated = [a.strip() for a in raw.split(",") if a.strip()]
    return addon_id in gated


def rating_level(name):
    """Convert a rating name to a numeric level."""
    if not name:
        return 0
    name = name.strip()
    # Check MPAA ratings first
    if name in RATING_LEVELS:
        return RATING_LEVELS[name]
    # Check TV ratings
    if name in TV_RATING_MAP:
        return TV_RATING_MAP[name]
    # Fuzzy match against both maps
    for known, level in list(RATING_LEVELS.items()) + list(TV_RATING_MAP.items()):
        if known.lower().replace("-", "").replace(" ", "") in name.lower().replace("-", "").replace(" ", ""):
            return level
    # Log unrecognized ratings for debugging
    log("Unrecognized rating: '%s' — defaulting to 0" % name, xbmc.LOGWARNING)
    return 0


def is_unlocked_extended():
    """Check if the 8-hour extended unlock is still active."""
    raw = get_setting("unlocked_until", "")
    if not raw:
        return False
    try:
        until = float(raw)
        return time.time() < until
    except Exception:
        return False


def is_unlocked_session(file_path):
    """Check if this specific file was unlocked via session PIN."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
        return file_path in unlocked if isinstance(unlocked, list) else False
    except Exception:
        return False


def mark_session_unlocked(file_path):
    """Record a session unlock for this file."""
    raw = get_setting("session_unlocked", "[]")
    try:
        unlocked = json.loads(raw)
    except Exception:
        unlocked = []
    if not isinstance(unlocked, list):
        unlocked = []
    if file_path and file_path not in unlocked:
        unlocked.append(file_path)
    # Keep max 50 entries to prevent unbounded growth
    if len(unlocked) > 50:
        unlocked = unlocked[-50:]
    set_setting("session_unlocked", json.dumps(unlocked))
    log("Session unlocked: %s" % file_path)


def mark_extended_unlocked(hours=8):
    """Set extended unlock timer."""
    until = time.time() + (hours * 3600)
    set_setting("unlocked_until", str(until))
    log("Extended unlocked until %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(until)))


def clear_unlock_state():
    """Clear all unlock states."""
    set_setting("unlocked_until", "")
    set_setting("session_unlocked", "[]")
    log("All unlock states cleared")


def show_pin_dialog(rating_name, content_title):
    """Show PIN entry dialog and return the result.

    Returns "session", "extended", or None (cancelled).
    """
    session_pin = get_setting("session_pin", "1234")
    extended_pin = get_setting("extended_pin", "5678")

    # Build the dialog message with rating info and content title
    title = content_title or "Unknown content"
    msg = "[COLOR yellow]Content Gate[/COLOR]\n\n"
    msg += "Content: [B]%s[/B]\n" % title
    msg += "Rating:  [B]%s[/B]\n\n" % (rating_name or "Unknown")
    msg += "This content requires a passcode.\n\n"
    msg += "[COLOR FF58A6FF]Enter Session PIN[/COLOR]  — unlock just this item\n"
    msg += "[COLOR FF58A6FF]Enter Extended PIN[/COLOR] — unlock for 8 hours\n"
    msg += "[COLOR FF8B949E][Cancel] to stop playback[/COLOR]"

    dialog = xbmcgui.Dialog()
    # Use numeric input for PIN entry
    pin = dialog.numeric(0, msg, "", True)
    if not pin:
        # User cancelled
        return None

    if pin == session_pin:
        return "session"
    elif pin == extended_pin:
        return "extended"
    else:
        dialog.notification(ADDON_ID, "Incorrect passcode", xbmcgui.NOTIFICATION_ERROR, 3000)
        return show_pin_dialog(rating_name, content_title)  # Retry


STORE_FILE = os.path.join(xbmcvfs.translatePath("special://profile/addon_data/%s" % ADDON_ID), "store.json")


def get_store():
    try:
        with open(STORE_FILE) as f:
            return json.load(f)
    except Exception:
        return {}


def save_store(data):
    try:
        d = os.path.dirname(STORE_FILE)
        if not os.path.isdir(d):
            os.makedirs(d)
        with open(STORE_FILE, "w") as f:
            json.dump(data, f)
    except Exception:
        pass


def lookup_rating_from_proxy(title, media_type="auto"):
    """Call the laptop proxy server to look up a content rating.

    Uses the proxy's rating resolver which checks manual DB → TMDB.
    """
    import urllib.request
    import json as _json
    import urllib.parse

    # The laptop proxy is reachable at 10.0.0.4:8080
    # We read the address from the proxy addon's settings via a stored config
    config = get_store().get("proxy", {})
    proxy_host = config.get("host", "10.0.0.4")
    proxy_port = config.get("port", 8080)

    url = "http://%s:%s/api/contentgate/lookup-rating?title=%s&type=%s" % (
        proxy_host, proxy_port, urllib.parse.quote(title), urllib.parse.quote(media_type))
    req = urllib.request.Request(url, headers={"User-Agent": "XboxContentGate/1.0"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = _json.loads(resp.read())
    return data


def handle_gate_check():
    """Main gate logic - check if current playback needs a PIN."""
    if not bool_setting("enabled", True):
        return

    threshold = int_setting("rating_threshold", 3)  # Default: PG-13
    if threshold == 0:  # Off
        return

    file_path = get_playing_file()
    if not file_path:
        log("No file path, skipping gate")
        return

    # Check extended unlock first (8-hour)
    if is_unlocked_extended():
        log("Extended unlock active, allowing playback")
        return

    # Check if we already unlocked this item (session)
    if is_unlocked_session(file_path):
        log("Session unlock active for this item, allowing playback")
        return

    # Get content info
    rating = get_rating_from_metadata()
    addon_id = get_playing_addon()
    content_title = xbmc.getInfoLabel("ListItem.Title") or xbmc.getInfoLabel("Player.Title") or ""
    media_type = xbmc.getInfoLabel("ListItem.DBType") or "auto"

    level = rating_level(rating)
    log("Playing: %s | Local metadata rating: %s (level %s) | Addon: %s | File: %s" % (
        content_title, rating, level, addon_id, file_path[:80]))

    # If no local rating found and we have a title, try proxy lookup
    if not rating and content_title:
        try:
            proxy_result = lookup_rating_from_proxy(content_title, media_type)
            if proxy_result and proxy_result.get("rating"):
                rating = proxy_result["rating"]
                level = proxy_result.get("level", 0)
                log("Proxy rating lookup: %s → %s (source: %s)" % (
                    content_title, rating, proxy_result.get("source", "unknown")))
        except Exception as exc:
            log("Proxy rating lookup failed: %s" % exc, xbmc.LOGWARNING)

    # Check if we should gate this
    should_gate = False

    # Check if the addon is gated
    if addon_id and is_gated_addon(addon_id):
        should_gate = True
        log("Addon %s is in gated list" % addon_id)

    # Check if rating exceeds threshold
    if level >= threshold:
        should_gate = True
        log("Rating level %s >= threshold %s" % (level, threshold))

    if not should_gate:
        log("No gate trigger, allowing playback")
        return

    # Gate triggered - pause and prompt
    player = xbmc.Player()
    was_playing = player.isPlaying()
    if was_playing:
        player.pause()

    result = None
    try:
        result = show_pin_dialog(rating or RATING_NAMES.get(level, "Unknown"), content_title)

        if result == "session":
            mark_session_unlocked(file_path)
            xbmcgui.Dialog().notification(ADDON_ID, "Session unlocked - playing now", xbmcgui.NOTIFICATION_INFO, 2000)
        elif result == "extended":
            mark_extended_unlocked()
            xbmcgui.Dialog().notification(ADDON_ID, "Unlocked for 8 hours", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            # Cancelled - stop playback
            log("Gate denied, stopping playback")
            if was_playing:
                try:
                    player.stop()
                except Exception:
                    pass
            return
    finally:
        # Resume if we paused and unlock was granted
        if result and was_playing:
            try:
                player.play()
            except Exception:
                pass


class ContentGateMonitor(xbmc.Monitor):
    """Monitors Kodi for playback events and applies content gating."""

    def __init__(self):
        super(ContentGateMonitor, self).__init__()
        self.last_checked = ""
        self._cleanup_old_session_unlocks()

    def _cleanup_old_session_unlocks(self):
        """Clear session unlocks from previous Kodi sessions."""
        raw = get_setting("session_unlocked", "[]")
        try:
            unlocked = json.loads(raw)
            if isinstance(unlocked, list) and len(unlocked) > 50:
                set_setting("session_unlocked", json.dumps(unlocked[-50:]))
        except Exception:
            pass

    def onPlayBackStarted(self):
        """Called when Kodi starts playback."""
        log("Playback started")
        # Small delay to let metadata populate
        xbmc.sleep(1500)
        handle_gate_check()

    def onPlayBackResumed(self):
        """Called when playback resumes."""
        pass


def run_service():
    """Main service entry point."""
    log("Content Gate service started v%s" % ADDON_VERSION)
    monitor = ContentGateMonitor()

    # Also handle already-playing content on service start (Kodi restart)
    xbmc.sleep(3000)
    if xbmc.Player().isPlaying():
        log("Already playing on service start")
        handle_gate_check()

    # Keep service alive
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break

    log("Content Gate service stopped")


if __name__ == "__main__":
    run_service()
