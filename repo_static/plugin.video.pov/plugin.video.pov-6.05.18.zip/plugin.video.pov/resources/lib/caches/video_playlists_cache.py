# -*- coding: utf-8 -*-
import time
from modules import kodi_utils

DB = kodi_utils.video_playlists_db


def _con():
	return kodi_utils.database_connect(DB)


def ensure():
	with _con() as con:
		con.execute("""CREATE TABLE IF NOT EXISTS video_playlists (
					list_name text not null, position integer not null, mediatype text not null,
					tmdb_id text not null, season text, episode text, title text, added_at integer,
					unique (list_name, mediatype, tmdb_id, season, episode))""")
		con.execute("""CREATE INDEX IF NOT EXISTS pov_video_playlists_name_pos ON video_playlists (list_name, position)""")


def list_names():
	ensure()
	try:
		with _con() as con:
			rows = con.execute("""SELECT list_name, COUNT(*) FROM video_playlists GROUP BY list_name ORDER BY lower(list_name)""").fetchall()
		return [{'name': i[0], 'count': i[1]} for i in rows]
	except Exception as e:
		from modules import kodi_utils
		kodi_utils.logger('Video Playlists', f'list_names error: {str(e)}')
		return []


def items(list_name):
	ensure()
	with _con() as con:
		rows = con.execute("""SELECT mediatype, tmdb_id, season, episode, title, position FROM video_playlists
					WHERE list_name=? ORDER BY position, added_at""", (list_name,)).fetchall()
	return [
		{'mediatype': i[0], 'tmdb_id': i[1], 'season': i[2], 'episode': i[3], 'title': i[4], 'position': i[5]}
		for i in rows
	]


def add_item(list_name, mediatype, tmdb_id, title, season='', episode=''):
\tensure()
\tlist_name = (list_name or '').strip()
\tif not list_name or not tmdb_id: return False
\tseason = '' if season in (None, 'None') else str(season)
\tepisode = '' if episode in (None, 'None') else str(episode)
\ttry:
\t\twith _con() as con:
\t\t\tposition = con.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM video_playlists WHERE list_name=?", (list_name,)).fetchone()[0]
\t\t\tcon.execute("""INSERT OR REPLACE INTO video_playlists
\t\t\t\t\t(list_name, position, mediatype, tmdb_id, season, episode, title, added_at)
\t\t\t\t\tVALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
\t\t\t\t\t(list_name, position, mediatype, str(tmdb_id), season, episode, title or '', int(time.time())))
\t\treturn True
\texcept Exception as e:
\t\tfrom modules import kodi_utils
\t\tkodi_utils.logger('Video Playlists', f'add_item error: {str(e)}')
\t\treturn False


def remove_item(list_name, mediatype, tmdb_id, season='', episode=''):
	ensure()
	season = '' if season in (None, 'None') else str(season)
	episode = '' if episode in (None, 'None') else str(episode)
	try:
		with _con() as con:
			con.execute("""DELETE FROM video_playlists WHERE list_name=? AND mediatype=? AND tmdb_id=? AND season=? AND episode=?""",
				(list_name, mediatype, str(tmdb_id), season, episode))
		return True
	except Exception as e:
		from modules import kodi_utils
		kodi_utils.logger('Video Playlists', f'remove_item error: {str(e)}')
		return False


def clear_list(list_name):
	ensure()
	try:
		with _con() as con:
			con.execute("DELETE FROM video_playlists WHERE list_name=?", (list_name,))
		return True
	except Exception as e:
		from modules import kodi_utils
		kodi_utils.logger('Video Playlists', f'clear_list error: {str(e)}')
		return False
