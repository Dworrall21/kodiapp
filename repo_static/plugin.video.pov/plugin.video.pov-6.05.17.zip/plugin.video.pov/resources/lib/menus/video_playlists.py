# -*- coding: utf-8 -*-
import sys
from caches import video_playlists_cache as cache
from modules import kodi_utils

build_url, make_listitem = kodi_utils.build_url, kodi_utils.make_listitem
add_items, set_category, set_content = kodi_utils.add_items, kodi_utils.set_category, kodi_utils.set_content
set_sort_method, end_directory, set_view_mode = kodi_utils.set_sort_method, kodi_utils.end_directory, kodi_utils.set_view_mode
media_path, container_refresh = kodi_utils.media_path, kodi_utils.container_refresh
run_plugin = 'RunPlugin(%s)'


class Menu:
	def __init__(self, params):
		self.params = params

	def lists(self):
		__handle__ = int(sys.argv[1])
		items = []
		for row in cache.list_names():
			li = make_listitem()
			li.setLabel(row['name'])
			li.setArt({'icon': media_path('lists.png'), 'poster': media_path('lists.png')})
			li.setProperty('tikiskins.item_count', str(row['count']))
			li.addContextMenuItems([('Clear Playlist', run_plugin % build_url({'mode': 'video_playlist_clear', 'list_name': row['name']}))])
			items.append((build_url({'mode': 'build_video_playlist', 'list_name': row['name'], 'name': row['name']}), li, True))
		add_items(__handle__, items)
		set_category(__handle__, 'Video Playlists')
		set_content(__handle__, 'files')
		end_directory(__handle__)
		set_view_mode('view.main', 'files')

	def build(self):
		__handle__ = int(sys.argv[1])
		list_name = self.params.get('list_name')
		items = []
		for row in cache.items(list_name):
			li = make_listitem()
			li.setLabel(row['title'])
			li.setArt({'icon': media_path('lists.png')})
			li.addContextMenuItems([('Remove from Playlist', run_plugin % build_url({
				'mode': 'video_playlist_remove', 'list_name': list_name, 'mediatype': row['mediatype'],
				'tmdb_id': row['tmdb_id'], 'season': row['season'], 'episode': row['episode']
			}))])
			url, is_folder = self._url_for(row)
			items.append((url, li, is_folder))
		add_items(__handle__, items)
		set_category(__handle__, list_name)
		set_sort_method(__handle__, 'unsorted')
		set_content(__handle__, 'files')
		end_directory(__handle__)
		set_view_mode('view.main', 'files')

	def _url_for(self, row):
		if row['mediatype'] == 'tvshow':
			return build_url({'mode': 'build_season_list', 'tmdb_id': row['tmdb_id']}), True
		if row['mediatype'] == 'season':
			return build_url({'mode': 'build_episode_list', 'tmdb_id': row['tmdb_id'], 'season': row['season']}), True
		return build_url({'mode': 'play_media', 'mediatype': 'episode', 'tmdb_id': row['tmdb_id'], 'season': row['season'], 'episode': row['episode']}), False


def clear(params):
	cache.clear_list(params.get('list_name'))
	container_refresh()


def remove(params):
	cache.remove_item(params.get('list_name'), params.get('mediatype'), params.get('tmdb_id'), params.get('season'), params.get('episode'))
	container_refresh()
