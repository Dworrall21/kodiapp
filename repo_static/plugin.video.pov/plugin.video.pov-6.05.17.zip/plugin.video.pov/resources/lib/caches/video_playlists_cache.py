# -*- coding: utf-8 -*-
import time
from modules import kodi_utils

DB = kodi_utils.video_playlists_db


def _con():
	return kodi_utils.database_connect(DB)


def ensure():
	with _con() as con:
		con.execute("""CREATE TABLE IF NOT EXISTS video_playlists (
					list_name text not null, position integer not null, mediatype text not null,
					tmdb_id text not null, season text, episode text, title text, added_at integer,
					unique (list_name, mediatype, tmdb_id, season, episode))""")
		con.execute("""CREATE INDEX IF NOT EXISTS pov_video_playlists_name_pos ON video_playlists (list_name, position)""")


def list_names():
	ensure()
	with _con() as con:
		rows = con.execute("""SELECT list_name, COUNT(*) FROM video_playlists GROUP BY list_name ORDER BY lower(list_name)""").fetchall()
	return [{'name': i[0], 'count': i[1]} for i in rows]


def items(list_name):
	ensure()
	with _con() as con:
		rows = con.execute("""SELECT mediatype, tmdb_id, season, episode, title, position FROM video_playlists
					WHERE list_name=? ORDER BY position, added_at""", (list_name,)).fetchall()
	return [
		{'mediatype': i[0], 'tmdb_id': i[1], 'season': i[2], 'episode': i[3], 'title': i[4], 'position': i[5]}
		for i in rows
	]


def add_item(list_name, mediatype, tmdb_id, title, season='', episode=''):
	ensure()
	list_name = (list_name or '').strip()
	if not list_name or not tmdb_id: return False
	season = '' if season in (None, 'None') else str(season)
	episode = '' if episode in (None, 'None') else str(episode)
	with _con() as con:
		position = con.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM video_playlists WHERE list_name=?", (list_name,)).fetchone()[0]
		con.execute("""INSERT OR REPLACE INTO video_playlists
					(list_name, position, mediatype, tmdb_id, season, episode, title, added_at)
					VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
			(list_name, position, mediatype, str(tmdb_id), season, episode, title or '', int(time.time())))
	return True


def remove_item(list_name, mediatype, tmdb_id, season='', episode=''):
	ensure()
	season = '' if season in (None, 'None') else str(season)
	episode = '' if episode in (None, 'None') else str(episode)
	with _con() as con:
		con.execute("""DELETE FROM video_playlists WHERE list_name=? AND mediatype=? AND tmdb_id=? AND season=? AND episode=?""",
			(list_name, mediatype, str(tmdb_id), season, episode))
	return True


def clear_list(list_name):
	ensure()
	with _con() as con:
		con.execute("DELETE FROM video_playlists WHERE list_name=?", (list_name,))
	return True
