# -*- coding: utf-8 -*-
"""
Arctic Zephyr Reloaded skin view compatibility module.

Detects the active skin and provides view ID mappings for Arctic Zephyr Reloaded.
POV uses these to expose the skin's view modes in the "Set View Modes" menu.
"""

# Arctic Zephyr Reloaded skin identifier
ARCTIC_ZEPHYR_MOD_ID = 'skin.arctic.zephyr.mod'

# View map: content_type -> list of (view_id, label)
# Content types: tvshow, season, episode, movie
ARCTIC_ZEPHYR_VIEWS = {
    'tvshow': [
        (50, 'List'),
        (500, 'Thumbnails'),
        (501, 'Modern Fanart'),
        (504, 'Netflix'),
        (507, 'Fanart'),
        (509, 'Shift'),
        (510, 'Minimal'),
        (511, 'Double'),
        (512, 'Double Banner'),
        (513, 'Shifted'),
        (515, 'SideCards'),
        (517, 'WallSmall'),
        (519, 'Shift Modern'),
        (521, 'Minimal V2'),
        (527, 'List V2'),
        (51, 'BigWide'),
        (53, 'Poster'),
        (54, 'Banner'),
        (55, 'Wall'),
        (56, 'MediaInfo'),
        (57, 'ExtraInfo'),
        (58, 'Cards'),
        (59, 'BannerWall'),
    ],
    'season': [
        (50, 'List'),
        (500, 'Thumbnails'),
        (501, 'Modern Fanart'),
        (504, 'Netflix'),
        (507, 'Fanart'),
        (509, 'Shift'),
        (510, 'Minimal'),
        (511, 'Double'),
        (512, 'Double Banner'),
        (513, 'Shifted'),
        (515, 'SideCards'),
        (516, 'SeasonsInfo'),
        (519, 'Shift Modern'),
        (520, 'Minimal'),
        (521, 'Minimal V2'),
        (524, 'Minimal V2 Seasons'),
        (526, 'SeasonsInfo V2'),
        (527, 'List V2'),
        (51, 'BigWide'),
        (53, 'Poster'),
        (54, 'Banner'),
        (55, 'Wall'),
        (56, 'MediaInfo'),
        (57, 'ExtraInfo'),
        (58, 'Cards'),
    ],
    'episode': [
        (50, 'List'),
        (500, 'Thumbnails'),
        (501, 'Modern Fanart'),
        (504, 'Netflix'),
        (507, 'Fanart'),
        (510, 'Minimal'),
        (511, 'Double'),
        (512, 'Double Banner'),
        (513, 'Shifted'),
        (514, 'Albums'),
        (515, 'SideCards'),
        (520, 'Minimal'),
        (521, 'Minimal V2'),
        (522, 'Minimal V2 Episodes'),
        (51, 'BigWide'),
        (54, 'Banner'),
        (55, 'Wall'),
        (56, 'MediaInfo'),
        (57, 'ExtraInfo'),
        (58, 'Cards'),
    ],
    'movie': [
        (50, 'List'),
        (500, 'Thumbnails'),
        (501, 'Modern Fanart'),
        (504, 'Netflix'),
        (507, 'Fanart'),
        (509, 'Shift'),
        (510, 'Minimal'),
        (511, 'Double'),
        (512, 'Double Banner'),
        (513, 'Shifted'),
        (514, 'Albums'),
        (515, 'SideCards'),
        (517, 'WallSmall'),
        (519, 'Shift Modern'),
        (521, 'Minimal V2'),
        (522, 'Minimal V2 Episodes'),
        (527, 'List V2'),
        (51, 'BigWide'),
        (53, 'Poster'),
        (54, 'Banner'),
        (55, 'Wall'),
        (56, 'MediaInfo'),
        (57, 'ExtraInfo'),
        (58, 'Cards'),
    ],
}


def is_arctic_zephyr(skin_id):
    """Check if the given skin ID is Arctic Zephyr Reloaded."""
    return skin_id == ARCTIC_ZEPHYR_MOD_ID


def current_skin_id(get_setting_value=None):
    """
    Get the current skin ID.
    When running inside Kodi, queries lookandfeel.skin via JSON-RPC.
    For testing, accepts an injected get_setting_value callable.
    """
    if get_setting_value is not None:
        return get_setting_value('lookandfeel.skin')
    try:
        from modules import kodi_utils
        result = kodi_utils.execJSONRPC(json.dumps({
            "jsonrpc": "2.0",
            "method": "Settings.GetSettingValue",
            "params": {"setting": "lookandfeel.skin"},
            "id": 1
        }))
        import json as _json
        return _json.loads(result).get('result', {}).get('value', '')
    except Exception:
        return ''


def view_options_for_skin(skin_id, content):
    """
    Return a list of (view_id, label) tuples for the given skin and content type.
    If the skin is not Arctic Zephyr Reloaded, returns an empty list.
    """
    if not is_arctic_zephyr(skin_id):
        return []
    return ARCTIC_ZEPHYR_VIEWS.get(content, [])


def view_choices_for_content(content):
    """
    Return view options for Arctic Zephyr Reloaded for the given content type.
    This is a convenience function that always returns AZR views regardless of
    the active skin (used when the user explicitly wants to pick an AZR view).
    """
    return ARCTIC_ZEPHYR_VIEWS.get(content, [])
