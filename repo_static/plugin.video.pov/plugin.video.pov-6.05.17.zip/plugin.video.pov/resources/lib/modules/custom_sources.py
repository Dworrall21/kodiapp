"""Helpers for user-configurable source settings.

Keep this module Kodi-free so URL shaping can be unit-tested outside Kodi.
"""

TORRENTIO_ORIGIN = "https://torrentio.strem.fun"

# Ordered list of (setting_suffix, torrentio_provider_name).
# Cached providers default to True; uncached default to False.
TORRENTIO_PROVIDERS = [
    ("yts",              "YTS",              True),
    ("eztv",             "EZTV",             True),
    ("rarbg",            "RARBG",            True),
    ("1337x",            "1337x",            True),
    ("thepiratebay",     "ThePirateBay",     True),
    ("kickasstorrents",  "KickassTorrents",  True),
    ("torrentgalaxy",    "TorrentGalaxy",    True),
    ("magnetdl",         "MagnetDL",         True),
    ("horriblesubs",     "HorribleSubs",     True),
    ("nyaasi",           "NyaaSi",           True),
    ("nyaapantsu",       "NyaaPantsu",       True),
    ("rutor",            "Rutor",            True),
    ("comando",          "Comando",          True),
    ("comoeubaixo",      "ComoEuBaixo",      True),
    ("lapumia",          "Lapumia",          True),
    ("ondebaixa",        "OndeBaixa",        True),
    ("torrent9",         "Torrent9",         True),
    # Uncached providers
    ("ilcorsarnero",     "ilCorSaRoNeRo",    False),
    ("mejortorrent",     "MejorTorrent",     False),
    ("wolfmax4k",        "Wolfmax4k",        False),
    ("cinecalidad",      "Cinecalidad",      False),
    ("besttorrents",     "BestTorrents",     False),
]


def _setting(settings_getter, key, fallback=""):
    try:
        value = settings_getter(key, fallback)
    except TypeError:
        value = settings_getter(key)
    except Exception:
        value = fallback
    return fallback if value is None else str(value).strip()


def _enabled(value):
    return str(value).strip().lower() in ("true", "1", "yes", "on")


def _build_providers_string(settings_getter):
    """Build a Torrentio-compatible providers string from individual toggles.

    Returns a string like 'YTS,EZTV,RARBG,...' or empty string if none enabled.
    """
    enabled = []
    for suffix, provider_name, default in TORRENTIO_PROVIDERS:
        setting_key = "provider.torrentio.%s" % suffix
        raw = _setting(settings_getter, setting_key, str(default).lower())
        if _enabled(raw):
            enabled.append(provider_name)
    return ",".join(enabled)


def torrentio_base_url(settings_getter):
    """Build Torrentio base URL from POV settings.

    When torrentio is disabled, returns empty string (caller should skip).
    When enabled, builds URL from individual provider toggles.
    """
    providers = _build_providers_string(settings_getter)
    if not providers:
        return TORRENTIO_ORIGIN
    return "%s/providers=%s" % (TORRENTIO_ORIGIN, providers)
