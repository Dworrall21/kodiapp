import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
xbmc.log("[%s] Safe diagnostic package imported" % ADDON_ID, xbmc.LOGINFO)

if __name__ == "__main__":
    xbmc.log("[%s] Safe diagnostic package launched" % ADDON_ID, xbmc.LOGINFO)
